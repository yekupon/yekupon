// Bu dosya, Yemeksepeti restoran listeleme sayfas�nda �r�nleri
// g�steren mant��� i�erir.

'use strict';

function initYsProductLister() {
    if (window.location.href.startsWith('https://www.yemeksepeti.com/restaurants/new') && false) {
        // Store the response data globally
        let responseData = null;

        // Intercept XMLHttpRequest
        const originalXHROpen = XMLHttpRequest.prototype.open;
        const originalXHRSend = XMLHttpRequest.prototype.send;
        const originalXHRSetRequestHeader = XMLHttpRequest.prototype.setRequestHeader;

        XMLHttpRequest.prototype.open = function(method, url) {
            this._url = url;
            this._method = method;
            this._requestHeaders = {};

            // Check if this is the search API request
            if (typeof url === 'string' && url.includes('/vendors-gateway/api/v1/pandora/search')) {
                this._isSearchRequest = true;
            }

            return originalXHROpen.apply(this, arguments);
        };

        XMLHttpRequest.prototype.setRequestHeader = function(header, value) {
            this._requestHeaders[header] = value;
            return originalXHRSetRequestHeader.apply(this, arguments);
        };

        XMLHttpRequest.prototype.send = function(body) {
            if (this._isSearchRequest) {
                const originalOnReadyStateChange = this.onreadystatechange;

                this.onreadystatechange = function() {
                    if (this.readyState === 4) {
                        try {
                            // Store the response data
                            if (this.status === 200) {
                                responseData = JSON.parse(this.responseText);
                                // Save response to localStorage for debugging
                                try {
                                    localStorage.setItem('ys_product_lister_response', JSON.stringify(responseData));
                                } catch (e) {
                                }

                                // If DOM is already loaded, try to add product lists immediately
                                if (document.readyState === 'complete' || document.readyState === 'interactive') {
                                    setTimeout(addProductListsToVendors, 500); // Small delay to ensure DOM is updated
                                }
                            }
                        } catch (e) {
                            console.error('YS Product Lister: Error parsing response', e);
                        }
                    }

                    if (originalOnReadyStateChange) {
                        originalOnReadyStateChange.apply(this, arguments);
                    }
                };
            }

            return originalXHRSend.apply(this, arguments);
        };

        // Function to create product list HTML
        function createProductList(products) {
            if (!products || products.length === 0) {
                return ''; // Return empty string instead of no products message
            }

            // Only use products with valid prices and names
            const validProducts = products.filter(p => p.price && p.name);
            if (validProducts.length === 0) {
                return '';
            }

            // Show only the first 3 products to avoid clutter
            const displayProducts = validProducts.slice(0, 3);

            let html = '<div class="ys-product-lister-container">';
            html += '<div class="ys-product-lister-items">';

            for (const product of displayProducts) {
                const priceFormatted = product.price.toFixed(2);

                html += `
                    <div class="ys-product-lister-item">
                        <span class="ys-product-lister-item-name">${product.name}</span>
                        <span class="ys-product-lister-item-price">${priceFormatted} TL</span>
                    </div>
                `;
            }

            html += '</div></div>';
            return html;
        }

        // Function to add product lists to vendor tiles
        function addProductListsToVendors() {
            if (!responseData || !responseData.data || !responseData.data.items) {
                // Try to load from localStorage if available
                try {
                    const savedData = localStorage.getItem('ys_product_lister_response');
                    if (savedData) {
                        responseData = JSON.parse(savedData);
                    }
                } catch (e) {
                    return;
                }

                if (!responseData || !responseData.data || !responseData.data.items) {
                    return;
                }
            }

            const vendorItems = responseData.data.items;

            // Try both selectors - the vendor-list-revamp for standard display and vendor-tile-new-l as fallback
            const vendorListSelector = '.vendor-list-revamp li, .vendor-tile-new-l';
            const vendorElements = document.querySelectorAll(vendorListSelector);
            vendorElements.forEach(vendorElement => {
                // Check if products are already added to this vendor using a data attribute
                if (vendorElement.dataset.ysProductListAdded) {
                    return;
                }

                const vendorId = vendorElement.getAttribute('data-testid');

                if (!vendorId) {
                    return;
                }

                // Find vendor data in the response
                const vendorData = vendorItems.find(item => item.code === vendorId);

                // Skip if vendor has no products or products array is empty
                if (!vendorData || !vendorData.products || !Array.isArray(vendorData.products) || vendorData.products.length === 0) {
                    return;
                }

                const productListHTML = createProductList(vendorData.products);

                // Skip if no product HTML was generated
                if (!productListHTML) {
                    return;
                }

                // Find the right container to append to
                const infoContainer = vendorElement.querySelector('.box-flex.vendor-tile-new-info.fd-column');

                if (infoContainer) {
                    // Use requestAnimationFrame to avoid layout thrashing and conflicts with React's render cycle
                    requestAnimationFrame(() => {
                        // Try to insert after the last vendor-info-row
                        const infoRows = infoContainer.querySelectorAll('.vendor-info-row');

                        if (infoRows && infoRows.length > 0) {
                            const lastInfoRow = infoRows[infoRows.length - 1];
                            lastInfoRow.insertAdjacentHTML('afterend', productListHTML);
                        } else {
                            // Fallback to appending at the end
                            infoContainer.insertAdjacentHTML('beforeend', productListHTML);
                        }

                        // Add a click handler to stop event propagation when clicking on the product list
                        const productContainer = infoContainer.querySelector('.ys-product-lister-container');
                        if (productContainer) {
                            productContainer.addEventListener('click', function(e) {
                                e.stopPropagation();
                            });
                        }
                        
                        // Mark this element as processed
                        vendorElement.dataset.ysProductListAdded = 'true';
                    });
                } else {
                }
            });
        }

        // Set up a more efficient mutation observer
        function setupObserver() {
            let debounceTimer;

            const observer = new MutationObserver((mutations) => {
                // Check if any of the mutations include the vendor list or relevant content
                const isRelevantChange = mutations.some(mutation => {
                    if (mutation.type !== 'childList' || mutation.addedNodes.length === 0) return false;
                    for (const node of mutation.addedNodes) {
                        if (node.nodeType === Node.ELEMENT_NODE) {
                            // Check for vendor list containers or individual vendor items
                            if (node.matches && (
                                node.matches('.vendor-list-revamp, .vendor-list-section, .organic-list, .vendor-tile-new-l') ||
                                node.querySelector('.vendor-list-revamp, .vendor-list-section, .organic-list, .vendor-tile-new-l')
                            )) {
                                return true;
                            }
                        }
                    }
                    return false;
                });

                if (isRelevantChange) {
                    // Use debounce to avoid rapid-fire execution
                    clearTimeout(debounceTimer);
                    debounceTimer = setTimeout(addProductListsToVendors, 300); // Wait for DOM to settle
                }
            });

            // Start observing once the document body is available
            const startObserving = () => {
                if (document.body) {
                    observer.observe(document.body, {
                        childList: true,
                        subtree: true
                    });
                    addStyles(); // Inject styles
                } else {
                    // If body is not ready, wait for DOMContentLoaded
                    document.addEventListener('DOMContentLoaded', () => startObserving(), { once: true });
                }
            };
            
            startObserving();
        }

        // Initialize when document is loaded
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', setupObserver);
        } else {
            setupObserver();
        }
    }
}
