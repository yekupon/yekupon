(function() {
  var _oF = window.fetch,
      _oO = XMLHttpRequest.prototype.open,
      _oS = XMLHttpRequest.prototype.send;

  // localStorage'dan delivery fee map'ini erken yükle
  try {
    var _savedFees = localStorage.getItem('ysVendorDeliveryFeeMap');
    if (_savedFees) {
      var _parsedFees = JSON.parse(_savedFees);
      if (_parsedFees && typeof _parsedFees === 'object') {
        window.__ysVendorDeliveryFees = Object.assign(window.__ysVendorDeliveryFees || {}, _parsedFees);
      }
    }
  } catch(e) {}

  // --- Helper: process GraphQL incentives response ---
  function _processIncentives(json, requestBody) {
    if (!json || !json.data || !json.data.incentivesCartWallet || !Array.isArray(json.data.incentivesCartWallet.incentives)) return false;

    var vertical = '';
    try {
      var reqBody = typeof requestBody === 'string' ? JSON.parse(requestBody) : (requestBody || {});
      vertical = (reqBody && reqBody.variables && reqBody.variables.input && reqBody.variables.input.verticalType) || '';
    } catch(e) {}
    if (!vertical) vertical = window.__ysCurrentVertical || '';

    var RESTAURANT_VERTICALS = ['restaurants', 'caterers', 'home_based_kitchen', 'street_food', 'mahallenin_favorileri', 'super_isletmeler'];
    var DARKSTORE_VERTICALS = ['darkstores', 'supermarket', 'groceries', 'mini_market', 'convenience', 'hypermarket', 'discounter', 'carrefoursa'];
    var isRestaurant = RESTAURANT_VERTICALS.indexOf(vertical) !== -1;
    var isDarkstore = DARKSTORE_VERTICALS.indexOf(vertical) !== -1;
    var APPLICABLE_CODES = isRestaurant ? ['kazan', 'merhaba'] : isDarkstore ? ['marketler'] : [];

    // Always build voucherMap
    var voucherMap = window.__ysVoucherMap || {};
    json.data.incentivesCartWallet.incentives.forEach(function(incentive) {
      var code = incentive && incentive.voucherMetaData && incentive.voucherMetaData.code;
      if (code) {
        voucherMap[code.toLowerCase()] = {
          discount: incentive.value || 0,
          minimumOrderValue: incentive.minimumOrderValue || 0,
          constructId: (incentive.voucherMetaData && incentive.voucherMetaData.constructID) || ''
        };
      }
    });
    window.__ysVoucherMap = voucherMap;

    if (APPLICABLE_CODES.length === 0) return false;

    var modified = false;
    json.data.incentivesCartWallet.incentives = json.data.incentivesCartWallet.incentives.map(function(incentive) {
      var code = incentive && incentive.voucherMetaData && incentive.voucherMetaData.code;
      if (code && APPLICABLE_CODES.indexOf(code) !== -1 && incentive.voucherMetaData.status === 'NOT_APPLICABLE') {
        incentive = JSON.parse(JSON.stringify(incentive));
        incentive.voucherMetaData.status = 'APPLICABLE';
        if (incentive.voucherMetaData.quantity === 0) incentive.voucherMetaData.quantity = 1;
        incentive.voucherMetaData.platforms = null;
        modified = true;
      }
      return incentive;
    });
    return modified;
  }

  // --- Helper: extract delivery fees from vendorListingPage ---
  function _processVendorListing(json) {
    if (!json || !json.data || !json.data.vendorListingPage) return;
    try {
      var comps = json.data.vendorListingPage.components;
      if (!Array.isArray(comps)) return;
      var feeMap = {};
      comps.forEach(function(comp) {
        if (!Array.isArray(comp.entities)) return;
        comp.entities.forEach(function(entity) {
          if (entity.__typename !== 'VendorData') return;
          var code = (entity.code || '').toLowerCase();
          var dp = entity.dynamicPricing;
          var fee = dp && dp.deliveryFee != null ? dp.deliveryFee.total : null;
          if (code && fee != null) { feeMap[code] = parseFloat(fee) || 0; }
        });
      });
      if (Object.keys(feeMap).length > 0) {
        window.__ysVendorDeliveryFees = Object.assign(window.__ysVendorDeliveryFees || {}, feeMap);
        try {
          var existing = JSON.parse(localStorage.getItem('ysVendorDeliveryFeeMap') || '{}');
          localStorage.setItem('ysVendorDeliveryFeeMap', JSON.stringify(Object.assign(existing, feeMap)));
        } catch(le) {}
      }
    } catch(e) {}
  }

  // --- XHR intercept ---
  XMLHttpRequest.prototype.open = function(m, u) {
    this.__ycU = u;
    this.__ycM = m;
    return _oO.apply(this, arguments);
  };

  XMLHttpRequest.prototype.send = function(b) {
    if (this.__ycU && this.__ycU.includes('tr.fd-api.com/graphql')) {
      this.__ycBody = (typeof b === 'string') ? b : (b ? String(b) : '');
      var _x = this;
      _x.addEventListener('load', function() {
        try {
          var json = JSON.parse(_x.responseText);
          var modified = _processIncentives(json, _x.__ycBody);
          _processVendorListing(json);
          if (modified) {
            var modifiedText = JSON.stringify(json);
            Object.defineProperty(_x, 'responseText', { get: function() { return modifiedText; }, configurable: true });
            Object.defineProperty(_x, 'response', { get: function() { return modifiedText; }, configurable: true });
          }
        } catch(e) {}
      }, true);
    }
    return _oS.apply(this, arguments);
  };

  // --- Fetch intercept ---
  window.fetch = function(inp, init) {
    var u = typeof inp === 'string' ? inp : (inp && inp.url);

    if (u && u.includes('tr.fd-api.com/graphql') && init && init.method === 'POST') {
      var bodyStr = init.body;
      return _oF.apply(this, arguments).then(function(resp) {
        return resp.clone().json().then(function(json) {
          var modified = _processIncentives(json, bodyStr);
          _processVendorListing(json);
          return new Response(JSON.stringify(json), {
            status: resp.status,
            statusText: resp.statusText,
            headers: { 'Content-Type': 'application/json' }
          });
        }).catch(function() { return resp; });
      });
    }

    return _oF.apply(this, arguments);
  };
})();
