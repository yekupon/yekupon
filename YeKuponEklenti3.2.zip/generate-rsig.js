(function(window) {
    'use strict';

    /**
     * YemekSepeti API Security Headers Generator
     */

    const PEK = {
        "abc": "!xXhPM1zp8aV6Zr7RGBft7B1z6m^7%!#",
        "aaa": "M&KlANewqa9xnISqDwYOxMs@aY6cpvS6",
        "cvc": "^RRTAYyQqfzwvzbbXLWh!_NLxdJbcxk@",
        "cbc": "^U_!#0nDLJYQ)Sj7qDSWjSq*SKXuO#xz",
        "csc": "vGp%xdxTS)XUh8gEgO_b_M%#hmeRrhH4",
        "asd": "kzzcWT1ZFqCi4&)Gig#O^*m4Ya5$FDjP",
        "amg": "7kK*f0KXK9Ipk2Grcl7GPp%m)xv%xb@i",
        "aq3": "f7a11#XKHvP$!nCBPvB$6*HpV(5BVnAJ",
        "mnp": "yBbzhv*VETh)FlaY16U!ydUyOO&ujG^5",
        "gig": "N&g$ZLu9*n0aOUc(GK(6o^Cu*c*yLoTj"
    };

    const PES = {
        "abc": "|{T}_{C}|{U}_{V}|{P}_{K}_{B}|{R}|{D}_",
        "aaa": "|{D}_{B}|{K}|{U}_{V}_{R}|{C}_{T}_{P}|",
        "cvc": "|{V}_{T}|{C}|{P}|{U}|{D}|{K}_{B}_{R}_",
        "cbc": "_{T}_{C}|{R}_{B}_{P}|{U}|{D}|{V}|{K}_",
        "csc": "_{P}|{C}_{R}|{T}|{V}|{K}|{U}|{D}_{B}_",
        "asd": "_{C}|{R}_{P}|{B}|{K}|{V}_{T}|{U}_{D}|",
        "amg": "_{T}|{V}_{B}|{K}|{P}|{R}_{C}|{D}|{U}_",
        "aq3": "|{U}_{C}_{P}_{B}|{T}|{V}|{D}|{R}_{K}_",
        "mnp": "|{V}|{U}_{R}|{T}_{B}_{K}|{D}_{C}|{P}|",
        "gig": "|{T}_{V}|{U}|{B}_{K}|{P}|{D}_{R}|{C}_"
    };

    /**
     * Timestamp'i formatla
     * @param {Date} date - Formatlanacak tarih
     * @returns {string} - Formatlanmış timestamp (ISO 8601 with timezone)
     */
    function formatTimestamp(date) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');
        const seconds = String(date.getSeconds()).padStart(2, '0');

        const offset = -date.getTimezoneOffset();
        const offsetHours = String(Math.floor(Math.abs(offset) / 60)).padStart(2, '0');
        const offsetMinutes = String(Math.abs(offset) % 60).padStart(2, '0');
        const offsetSign = offset >= 0 ? '+' : '-';
        const timezone = `${offsetSign}${offsetHours}${offsetMinutes}`;

        return `${year}-${month}-${day}T${hours}:${minutes}:${seconds}${timezone}`;
    }

    /**
     * Security header'larını generate et
     * 
     * @param {string} url - Tam URL (örn: https://tr.fd-api.com/api/v5/oauth2/token?language_id=2)
     * @param {string} method - HTTP method (GET, POST, PUT, DELETE)
     * @param {string} appBuild - App build number (örn: "255050434")
     * @param {string} appVersion - App version (örn: "25.50.5")
     * @param {string} body - Request body (POST/PUT için, GET ise boş string)
     * @param {string} custCode - Customer code (giriş yapılmışsa, yoksa boş string)
     * @param {string} eksValue - EKS değeri (örn: "aq3asd")
     * @param {Date} [timestamp] - Timestamp (opsiyonel)
     * @param {number} [randomValue] - Random value (opsiyonel)
     * @returns {Object} Header objesini döndürür
     */
    function generateSecurityHeaders(url, method, appBuild, appVersion, body, custCode, eksValue, timestamp, randomValue) {
        try {
            // Varsayılan değerler
            timestamp = timestamp || new Date();
            randomValue = randomValue !== undefined ? randomValue : Math.random();

            console.log('🔐 R-Sig Üretim Başlıyor:', {
                url: url,
                method: method,
                eksValue: eksValue,
                appBuild: appBuild,
                appVersion: appVersion,
                custCode: custCode || '',
                bodyLength: body ? body.length : 0,
                timestamp: timestamp,
                randomValue: randomValue
            });

            // Timestamp formatla
            const rts = formatTimestamp(timestamp);
            const ruid = randomValue;

            // EKS'ten decoder ve encoder çıkar
            // ÖNEMLİ: EKS formatı "decoder+encoder" şeklinde, ortadan ikiye bölünür
            const halfLen = Math.floor(eksValue.length / 2);
            const decoder = eksValue.substring(0, halfLen);
            const encoder = eksValue.substring(halfLen);

            const eks = decoder + encoder;

            console.log('🔑 EKS Parçaları:', {
                eksValue: eksValue,
                decoder: decoder,
                encoder: encoder,
                combinedEks: eks
            });

            // Decoder ve Encoder kontrolü
            const hmacKey = PEK[decoder];
            if (!hmacKey) {
                throw new Error(`PEK decoder key bulunamadı: ${decoder}`);
            }

            let template = PES[encoder];
            if (!template) {
                throw new Error(`PES encoder key bulunamadı: ${encoder}`);
            }

            console.log('🔨 HMAC Key ve Template:', {
                hmacKey: hmacKey.substring(0, 10) + '...',
                template: template.substring(0, 50) + '...'
            });

            // Payload oluştur
            const payload = `${appBuild}|${custCode}|${randomValue}|${rts}|${appVersion}|`;

            console.log('📦 Payload:', payload);

            // {K} placeholder'ını değiştir
            template = template.replace('{K}', hmacKey);

            // Diğer placeholder'ları değiştir
            const replacements = {
                'T': rts,
                'R': randomValue.toString(),
                'B': appBuild,
                'V': appVersion,
                'C': custCode,
                'P': payload,
                'U': url,
                'D': (method === 'POST' || method === 'PUT') ? body : ''
            };

            console.log('🔄 Replacements:', {
                T: rts,
                R: randomValue.toString(),
                B: appBuild,
                V: appVersion,
                C: custCode || '(boş)',
                P: payload.substring(0, 50) + '...',
                U: url.substring(0, 50) + '...',
                D_length: replacements.D.length
            });

            for (const [key, value] of Object.entries(replacements)) {
                const placeholder = `{${key}}`;
                template = template.replace(new RegExp(placeholder.replace(/[{}]/g, '\\$&'), 'g'), value);
            }

            console.log('📝 Final Template:', template.substring(0, 100) + '...');

            // HMAC-SHA256 hesapla (CryptoJS kullanarak)
            const rSig = CryptoJS.HmacSHA256(template, hmacKey).toString(CryptoJS.enc.Base64);

            console.log('✅ R-Sig Üretildi:', {
                'R-Sig': rSig,
                'Rts': rts,
                'Ruid': ruid.toString(),
                'Eks': eks
            });

            return {
                success: true,
                'Rts': rts,
                'Ruid': ruid.toString(),
                'Eks': eks,
                'R-Sig': rSig,
                signature: rSig, // background.js uyumluluğu için eklendi
                'App-Build': appBuild,
                'App-Version': appVersion,
                'Cust-Code': custCode,
                templateString: template,
                decoder: decoder,
                encoder: encoder
            };

        } catch (error) {
            console.error("❌ R-Sig oluşturulurken hata:", error);
            return { 
                success: false, 
                error: error.message 
            };
        }
    }

    /**
     * Eski API ile uyumluluk için wrapper fonksiyon
     * 
     * @param {object} requestData - İstek detaylarını içeren nesne
     * @param {string} requestData.url - Tam istek URL'si
     * @param {string} requestData.method - HTTP method (GET, POST, PUT, DELETE)
     * @param {string} requestData.eks - EKS başlığı değeri (örn: 'aq3asd', 'asdcvc')
     * @param {string} [requestData.body=""] - İstek gövdesi
     * @param {string} [requestData.timestamp] - Timestamp (opsiyonel)
     * @param {string} [requestData.random] - Random value (opsiyonel)
     * @param {string} [requestData.build="255050434"] - App build numarası
     * @param {string} [requestData.version="25.50.5"] - App versiyonu
     * @param {string} [requestData.custCode=""] - Müşteri kodu
     * @returns {object|null} İmza ve detayları içeren bir nesne veya hata durumunda null
     */
    function generateYemeksepetiRSig(requestData) {
        const data = {
            build: "255050434",
            version: "25.50.5",
            custCode: "",
            body: "",
            method: "GET",
            ...requestData
        };

        const timestamp = data.timestamp ? new Date(data.timestamp) : undefined;
        const random = data.random ? parseFloat(data.random) : undefined;

        return generateSecurityHeaders(
            data.url,
            data.method,
            data.build,
            data.version,
            data.body,
            data.custCode || "",
            data.eks,
            timestamp,
            random
        );
    }

    // Fonksiyonları global context'e ekle
    if (typeof window !== 'undefined') {
        // Browser context (inject.js için)
        window.generateYemeksepetiRSig = generateYemeksepetiRSig;
        window.generateSecurityHeaders = generateSecurityHeaders;
    } else {
        // Service Worker context (background.js için)
        self.generateYemeksepetiRSig = generateYemeksepetiRSig;
        self.generateSecurityHeaders = generateSecurityHeaders;
    }

})(typeof window !== 'undefined' ? window : self);
