// ===== ZORUNLU GÜNCELLEME KONTROL BLOĞU (En üste eklendi) =====
// Tek JSON dosyası ile versiyon kontrolü - https://yekupon.com/version.json
(function forcedUpdateInit(){
  const VERSION_JSON_URL = 'https://yekupon.com/version.json';
  const LOCAL_VERSION = chrome?.runtime?.getManifest ? (chrome.runtime.getManifest().version || '0.0.0') : '0.0.0';
  let applied = false;

  function semverOutdated(curr, latest){
    const toArr=v=>String(v).split('.').map(n=>parseInt(n.replace(/[^0-9]/g,''))||0);
    const a=toArr(curr), b=toArr(latest); const len=Math.max(a.length,b.length);
    for(let i=0;i<len;i++){ if((a[i]||0)<(b[i]||0)) return true; if((a[i]||0)>(b[i]||0)) return false; }
    return false;
  }

  async function fetchVersionData(){
    const ctrl=new AbortController(); const t=setTimeout(()=>ctrl.abort(),8000);
    const res=await fetch(VERSION_JSON_URL+'?t=' + Date.now(), {cache:'no-store', signal:ctrl.signal});
    clearTimeout(t);
    if(!res.ok) throw new Error('HTTP '+res.status);
    return res.json();
  }

  function escapeHtml(str){return str.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;','\'':'&#39;'}[c]));}

  async function buildAndShow(versionData){
    if(applied) return; applied=true;
    const notes = versionData.notes || ['Güncelleme mevcut'];
    const downloadUrl = versionData.downloadUrl || 'https://rebrand.ly/YmkEklenti';
    
    const overlay=document.createElement('div');
    overlay.id='yekupon-force-update-overlay';
    overlay.style.cssText='position:fixed;inset:0;z-index:2147483647;display:flex;align-items:center;justify-content:center;background:#0a0e1a;font-family:Inter,system-ui,-apple-system,sans-serif;color:#f1f5f9;';
    overlay.innerHTML=`
    <style>
      @keyframes yk-fadeUp{from{opacity:0;transform:translateY(16px) scale(.97)}to{opacity:1;transform:translateY(0) scale(1)}}
      @keyframes yk-glow{0%,100%{opacity:.6}50%{opacity:1}}
      #yk-upd-card{max-width:460px;width:92%;padding:36px 32px;background:linear-gradient(165deg,rgba(26,31,46,.95),rgba(15,20,35,.98));border:1px solid rgba(148,163,184,.1);border-radius:24px;box-shadow:0 32px 64px rgba(0,0,0,.5),0 0 0 1px rgba(255,255,255,.03);position:relative;overflow:hidden;animation:yk-fadeUp .4s cubic-bezier(.16,1,.3,1)}
      #yk-upd-card::before{content:'';position:absolute;top:0;left:0;right:0;height:2px;background:linear-gradient(90deg,transparent,#ff4757,#ff6b81,transparent);animation:yk-glow 3s ease-in-out infinite}
      #yk-upd-card::after{content:'';position:absolute;top:-50px;right:-50px;width:160px;height:160px;background:radial-gradient(circle,rgba(255,71,87,.1),transparent 70%);pointer-events:none}
      .yk-badge{display:inline-flex;align-items:center;gap:6px;padding:6px 14px;border-radius:8px;background:rgba(255,71,87,.1);border:1px solid rgba(255,71,87,.15);color:#ff6b81;font-size:12px;font-weight:700;letter-spacing:.05em;text-transform:uppercase;margin-bottom:16px}
      .yk-badge::before{content:'';width:6px;height:6px;border-radius:50%;background:#ff4757;animation:yk-glow 2s ease infinite}
      .yk-title{font-size:22px;font-weight:800;letter-spacing:-.02em;margin:0 0 6px;background:linear-gradient(135deg,#fff,#ff4757);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}
      .yk-sub{font-size:13px;color:#64748b;margin:0 0 24px}
      .yk-notes-wrap{border:1px solid rgba(148,163,184,.08);border-radius:14px;background:rgba(255,255,255,.02);margin-bottom:24px;overflow:hidden}
      .yk-notes-head{display:flex;align-items:center;gap:8px;padding:12px 16px;border-bottom:1px solid rgba(148,163,184,.06);font-size:13px;font-weight:700;color:#cbd5e1}
      .yk-notes-head span{font-size:16px}
      .yk-notes ul{margin:0;padding:14px 20px;list-style:none;max-height:160px;overflow-y:auto;font-size:13px;line-height:1.7;color:#94a3b8}
      .yk-notes li{position:relative;padding-left:16px;margin-bottom:6px}
      .yk-notes li::before{content:'';position:absolute;left:0;top:9px;width:5px;height:5px;border-radius:50%;background:#ff4757}
      .yk-notes li:last-child{margin-bottom:0}
      .yk-dl{display:inline-flex;align-items:center;gap:10px;padding:14px 24px;border-radius:12px;background:#ff4757;color:#fff;text-decoration:none;font-weight:700;font-size:14px;box-shadow:0 4px 20px rgba(255,71,87,.3),inset 0 1px 0 rgba(255,255,255,.15);transition:all .2s ease;border:none;cursor:pointer}
      .yk-dl:hover{background:#ff6b81;transform:translateY(-1px);box-shadow:0 8px 30px rgba(255,71,87,.4)}
      .yk-footer{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap}
      .yk-hint{font-size:11px;color:#475569;max-width:200px;line-height:1.5}
    </style>
    <div id="yk-upd-card">
      <div class="yk-badge">Güncelleme Gerekli</div>
      <h1 class="yk-title">Yeni Sürüm Mevcut</h1>
      <p class="yk-sub">Bu sürüm artık desteklenmiyor. (v${LOCAL_VERSION} → v${versionData.version})</p>
      <div class="yk-notes-wrap">
        <div class="yk-notes-head"><span>📋</span> Güncelleme Notları</div>
        <div class="yk-notes">
          <ul>${notes.map(n=>`<li>${escapeHtml(n)}</li>`).join('')}</ul>
        </div>
      </div>
      <div class="yk-footer">
        <a href="${escapeHtml(downloadUrl)}" target="_blank" rel="noopener" class="yk-dl">
          <span class="material-icons-round" style="font-size:18px;">download</span> Güncel Eklentiyi İndir
        </a>
      </div>
    </div>`;
    document.body.appendChild(overlay);
    try{document.documentElement.style.pointerEvents='none';}catch{};
    overlay.style.pointerEvents='auto';
  }

  async function run(){
    try {
      const versionData = await fetchVersionData();
      const latest = versionData.version || '0.0.0';
      const forceUpdate = versionData.forceUpdate !== false; // varsayılan true
      
      // Güncelleme gerekli mi?
      const needsUpdate = semverOutdated(LOCAL_VERSION, latest);
      
      if(!needsUpdate) {
        return;
      }
      
      // forceUpdate false ise bloklama yapma
      if(!forceUpdate) {
        return;
      }
      
      await buildAndShow(versionData);
      
    } catch(e) {
      // Hata durumunda bloklama yapma - kullanıcı çalışmaya devam edebilsin
    }
  }

  // Body henüz yoksa bekle
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', run); else run();
  // Periyodik tekrar (5 dk) – sadece blok uygulanmadıysa
  setInterval(()=>{ if(!applied) run(); }, 300000);
})();
// ===== ZORUNLU GÜNCELLEME KONTROL BLOĞU SONU =====

document.body.classList.add('preload');

function hydrateMaterialIcons() {
    
    document.querySelectorAll('.material-icons-round[data-icon]').forEach(el => {
        const iconName = el.getAttribute('data-icon');
        if (iconName && el.textContent !== iconName) {
            el.textContent = iconName;
        }
    });
}

function checkMaterialIconsLoaded() {
    hydrateMaterialIcons();
    const testIcon = document.createElement('span');
    testIcon.className = 'material-icons-round';
    testIcon.textContent = 'home';
    testIcon.style.position = 'absolute';
    testIcon.style.top = '-1000px';
    testIcon.style.left = '-1000px';
    document.body.appendChild(testIcon);
    
    setTimeout(() => {
        const isLoaded = testIcon.offsetWidth > 20;
        document.body.removeChild(testIcon);
        
        if (isLoaded) {
            document.querySelectorAll('.material-icons-round').forEach(el => {
                el.setAttribute('data-loaded', 'true');
            });
        } else {
            hydrateMaterialIcons();
        }
        
        return isLoaded;
    }, 500);
}

window.addEventListener('load', () => {
    setTimeout(() => {
        document.body.classList.remove('preload');
        checkMaterialIconsLoaded();
    }, 100);
});

(function() {
    let savedTheme = localStorage.getItem('yekupon-theme');
    
    if (!savedTheme || !['dark', 'red', 'orange', 'blue', 'green', 'purple'].includes(savedTheme)) {
        savedTheme = 'dark';
        localStorage.setItem('yekupon-theme', 'dark');
    }
    
    document.documentElement.setAttribute('data-theme', savedTheme);
})();

let selectedAddress = null;
let savedAddresses = JSON.parse(localStorage.getItem('yekupon_saved_addresses')) || [];

const turkishProvinces = [
    'Adana', 'Adıyaman', 'Afyonkarahisar', 'Ağrı', 'Amasya', 'Ankara', 'Antalya', 'Artvin',
    'Aydın', 'Balıkesir', 'Bilecik', 'Bingöl', 'Bitlis', 'Bolu', 'Burdur', 'Bursa',
    'Çanakkale', 'Çankırı', 'Çorum', 'Denizli', 'Diyarbakır', 'Edirne', 'Elazığ', 'Erzincan',
    'Erzurum', 'Eskişehir', 'Gaziantep', 'Giresun', 'Gümüşhane', 'Hakkari', 'Hatay', 'Isparta',
    'Mersin', 'İstanbul', 'İzmir', 'Kars', 'Kastamonu', 'Kayseri', 'Kırklareli', 'Kırşehir',
    'Kocaeli', 'Konya', 'Kütahya', 'Malatya', 'Manisa', 'Kahramanmaraş', 'Mardin', 'Muğla',
    'Muş', 'Nevşehir', 'Niğde', 'Ordu', 'Rize', 'Sakarya', 'Samsun', 'Siirt',
    'Sinop', 'Sivas', 'Tekirdağ', 'Tokat', 'Trabzon', 'Tunceli', 'Şanlıurfa', 'Uşak',
    'Van', 'Yozgat', 'Zonguldak', 'Aksaray', 'Bayburt', 'Karaman', 'Kırıkkale', 'Batman',
    'Şırnak', 'Bartın', 'Ardahan', 'Iğdır', 'Yalova', 'Karabük', 'Kilis', 'Osmaniye', 'Düzce'
];

const districtsData = {
    'İstanbul': [
        'Adalar', 'Arnavutköy', 'Ataşehir', 'Avcılar', 'Bağcılar', 'Bahçelievler', 'Bakırköy',
        'Başakşehir', 'Bayrampaşa', 'Beşiktaş', 'Beykoz', 'Beylikdüzü', 'Beyoğlu', 'Büyükçekmece',
        'Çatalca', 'Çekmeköy', 'Esenler', 'Esenyurt', 'Eyüpsultan', 'Fatih', 'Gaziosmanpaşa',
        'Güngören', 'Kadıköy', 'Kağıthane', 'Kartal', 'Küçükçekmece', 'Maltepe', 'Pendik',
        'Sancaktepe', 'Sarıyer', 'Silivri', 'Sultanbeyli', 'Sultangazi', 'Şile', 'Şişli',
        'Tuzla', 'Ümraniye', 'Üsküdar', 'Zeytinburnu'
    ],
    'Ankara': [
        'Akyurt', 'Altındağ', 'Ayaş', 'Bala', 'Beypazarı', 'Çamlıdere', 'Çankaya', 'Çubuk',
        'Elmadağ', 'Etimesgut', 'Evren', 'Gölbaşı', 'Güdül', 'Haymana', 'Kalecik', 'Kazan',
        'Keçiören', 'Kızılcahamam', 'Mamak', 'Nallıhan', 'Polatlı', 'Pursaklar', 'Sincan',
        'Şereflikoçhisar', 'Yenimahalle'
    ]
};

const neighborhoodsData = {
    'Bağcılar': [
        'Bağlar Mahallesi', 'Barbaros Mahallesi', 'Çınar Mahallesi', 'Demirkapı Mahallesi',
        'Evren Mahallesi', 'Fatih Mahallesi', 'Göztepe Mahallesi', 'Güneşli Mahallesi',
        'Hürriyet Mahallesi', 'İnönü Mahallesi', 'Kemalpaşa Mahallesi', 'Kirazlı Mahallesi',
        'Mahmutbey Mahallesi', 'Merkez Mahallesi', 'Şirinevler Mahallesi', 'Yenigün Mahallesi',
        'Yıldıztepe Mahallesi', 'Yüzyıl Mahallesi'
    ],
    'Kadıköy': [
        'Acıbadem Mahallesi', 'Bostancı Mahallesi', 'Caferağa Mahallesi', 'Caddebostan Mahallesi',
        'Erenköy Mahallesi', 'Fenerbahçe Mahallesi', 'Göztepe Mahallesi', 'Hasanpaşa Mahallesi',
        'Kozyatağı Mahallesi', 'Moda Mahallesi', 'Örnektepe Mahallesi', 'Rasimpaşa Mahallesi',
        'Sahrayıcedit Mahallesi', 'Suadiye Mahallesi'
    ],
    'Beşiktaş': [
        'Abbasağa Mahallesi', 'Akatlar Mahallesi', 'Arnavutköy Mahallesi', 'Bebek Mahallesi',
        'Dikilitaş Mahallesi', 'Etiler Mahallesi', 'Gayrettepe Mahallesi', 'Konaklar Mahallesi',
        'Kuruçeşme Mahallesi', 'Levent Mahallesi', 'Muradiye Mahallesi', 'Nisbetiye Mahallesi',
        'Ortaköy Mahallesi', 'Sinanpaşa Mahallesi', 'Türkali Mahallesi', 'Ulus Mahallesi',
        'Vişnezade Mahallesi', 'Yıldız Mahallesi'
    ],
    'Sincan': [
        'Akpınar Mahallesi', 'Akyurt Mahallesi', 'Batıkent Mahallesi', 'Belediye Mahallesi',
        'Fatih Mahallesi', 'Fevzi Çakmak Mahallesi', 'İsmet İnönü Mahallesi', 'Kasım Halife Mahallesi',
        'Kayalar Mahallesi', 'Konya Yolu Mahallesi', 'Mimar Sinan Mahallesi', 'Mustafa Kemal Mahallesi',
        'Necip Fazıl Mahallesi', 'Osman Gazi Mahallesi', 'Ömer Halisdemir Mahallesi', 'Pazar Mahallesi',
        'Saray Mahallesi', 'Şehit Cengiz Topel Mahallesi', 'Şehit Kubilay Mahallesi', 'Tevfik İleri Mahallesi',
        'Topepe Mahallesi', 'Ulus Mahallesi', 'Ulubey Mahallesi', 'Yenikent Mahallesi'
    ],
    'Çankaya': [
        'Ahlatlıbel Mahallesi', 'Alacaatlı Mahallesi', 'Aşağı Öveçler Mahallesi', 'Bahçelievler Mahallesi',
        'Balgat Mahallesi', 'Birlik Mahallesi', 'Çamlıdere Mahallesi', 'Çukurambar Mahallesi',
        'Dikmen Mahallesi', 'Emek Mahallesi', 'Gaziosmanpaşa Mahallesi', 'Hilal Mahallesi',
        'Işıklar Mahallesi', 'Kavaklıdere Mahallesi', 'Kızılay Mahallesi', 'Öveçler Mahallesi',
        'Sokullu Mahallesi', 'Yıldız Mahallesi', 'Yukarı Bahçelievler Mahallesi'
    ]
};

async function initializeProvinceSelect() {
    const provinceSelect = document.getElementById('province');
    if (!provinceSelect) return;
    
    provinceSelect.innerHTML = '<option value="">Şehirler yükleniyor...</option>';
    provinceSelect.disabled = true;
    
    try {
        const cities = await fetchMigrosCities();
        
        provinceSelect.innerHTML = '<option value="">İl seçiniz</option>';
        
        const sortedCities = cities.sort((a, b) => a.name.localeCompare(b.name, 'tr'));
        
        sortedCities.forEach(city => {
            const option = document.createElement('option');
            option.value = city.name;
            option.dataset.cityId = city.id;
            option.textContent = city.name;
            provinceSelect.appendChild(option);
        });
        
        provinceSelect.disabled = false;
        
    } catch (error) {
        
        provinceSelect.innerHTML = '<option value="">İl seçiniz</option>';
        turkishProvinces.sort().forEach(province => {
            const option = document.createElement('option');
            option.value = province;
            option.textContent = province;
            provinceSelect.appendChild(option);
        });
        
        provinceSelect.disabled = false;
    }
}

async function updateDistrictSelect(selectedProvince) {
    const districtSelect = document.getElementById('district');
    if (!districtSelect) return;
    
    districtSelect.innerHTML = '<option value="">İlçe seçiniz</option>';
    districtSelect.disabled = true;
    
    updateNeighborhoodSelect('');
    
    if (!selectedProvince) {
        districtSelect.disabled = false;
        return;
    }
    
    try {
        const provinceSelect = document.getElementById('province');
        const selectedOption = provinceSelect.querySelector(`option[value="${selectedProvince}"]`);
        const cityId = selectedOption ? selectedOption.dataset.cityId : null;
        
        if (!cityId) {
            if (districtsData[selectedProvince]) {
                districtsData[selectedProvince].forEach(district => {
                    const option = document.createElement('option');
                    option.value = district;
                    option.textContent = district;
                    districtSelect.appendChild(option);
                });
            }
            districtSelect.disabled = false;
            return;
        }
        
        districtSelect.innerHTML = '<option value="">İlçeler yükleniyor...</option>';
        
        const towns = await fetchMigrosTowns(cityId);
        
        districtSelect.innerHTML = '<option value="">İlçe seçiniz</option>';
        
        const sortedTowns = towns.sort((a, b) => a.name.localeCompare(b.name, 'tr'));
        
        sortedTowns.forEach(town => {
            const option = document.createElement('option');
            option.value = town.name;
            option.dataset.townId = town.id;
            option.textContent = town.name;
            districtSelect.appendChild(option);
        });
        
        districtSelect.disabled = false;
        
    } catch (error) {
        
        districtSelect.innerHTML = '<option value="">İlçe seçiniz</option>';
        if (districtsData[selectedProvince]) {
            districtsData[selectedProvince].forEach(district => {
                const option = document.createElement('option');
                option.value = district;
                option.textContent = district;
                districtSelect.appendChild(option);
            });
        }
        districtSelect.disabled = false;
    }
}

async function updateNeighborhoodSelect(selectedDistrict) {
    const neighborhoodSelect = document.getElementById('neighborhood');
    if (!neighborhoodSelect) return;
    
    neighborhoodSelect.innerHTML = '<option value="">Mahalle seçiniz</option>';
    neighborhoodSelect.disabled = true;
    
    if (!selectedDistrict) {
        neighborhoodSelect.disabled = false;
        return;
    }
    
    try {
        const districtSelect = document.getElementById('district');
        const selectedOption = districtSelect.querySelector(`option[value="${selectedDistrict}"]`);
        const townId = selectedOption ? selectedOption.dataset.townId : null;
        
        if (!townId) {
            if (neighborhoodsData[selectedDistrict]) {
                neighborhoodsData[selectedDistrict].forEach(neighborhood => {
                    const option = document.createElement('option');
                    option.value = neighborhood;
                    option.textContent = neighborhood;
                    neighborhoodSelect.appendChild(option);
                });
            }
            neighborhoodSelect.disabled = false;
            return;
        }
        
        neighborhoodSelect.innerHTML = '<option value="">Mahalleler yükleniyor...</option>';
        
        const districts = await fetchMigrosDistricts(townId);
        
        neighborhoodSelect.innerHTML = '<option value="">Mahalle seçiniz</option>';
        
        const sortedDistricts = districts.sort((a, b) => a.name.localeCompare(b.name, 'tr'));
        
        sortedDistricts.forEach(district => {
            const option = document.createElement('option');
            option.value = district.name;
            option.dataset.districtId = district.id;
            option.textContent = district.name;
            neighborhoodSelect.appendChild(option);
        });
        
        neighborhoodSelect.disabled = false;
        
    } catch (error) {
        
        neighborhoodSelect.innerHTML = '<option value="">Mahalle seçiniz</option>';
        if (neighborhoodsData[selectedDistrict]) {
            neighborhoodsData[selectedDistrict].forEach(neighborhood => {
                const option = document.createElement('option');
                option.value = neighborhood;
                option.textContent = neighborhood;
                neighborhoodSelect.appendChild(option);
            });
        }
        neighborhoodSelect.disabled = false;
    }
}

function handleMapAddressSelection(addressData) {
    selectedAddress = addressData;
    
    const addressInput = document.getElementById('address-input');
    if (addressInput) {
        addressInput.value = addressData.address;
    }
    
    updateActiveAddressLabel(addressData.label, addressData.district, addressData.province);
    fillAddressForm(addressData);
    
    const mapIframeContainer = document.getElementById('mapIframeContainer');
    const toggleMapButton = document.getElementById('toggleMapButton');
    const confirmMapSelection = document.getElementById('confirmMapSelection');
    
    if (mapIframeContainer && toggleMapButton) {
        mapIframeContainer.classList.remove('visible');
        toggleMapButton.innerHTML = '<span class="material-icons-round">map</span> Haritayı Göster';
    }
    
    if (confirmMapSelection) {
        confirmMapSelection.style.display = 'none';
    }
    
    showNotification('Adres başarıyla seçildi!', 'success');

    
    try {
        const formSection = document.getElementById('addressFormSection');
        if (formSection) {
            formSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    } catch {}
}

// Global değişkenler - adres arama sistemi için
let addressInput = null;
let suggestionsContainer = null;
let mapIframe = null;
let suggestionTimeout = null;

window.addEventListener('message', function(event) {
    
    // suggestions action - adres önerileri
    if (event.data && event.data.action === 'suggestions') {
        
        if (!suggestionsContainer) {
            suggestionsContainer = document.getElementById('suggestions-container');
        }
        
        if (suggestionsContainer) {
            // Önerileri temizle
            suggestionsContainer.innerHTML = '';
            
            // Hata veya boş sonuç
            if (!event.data.predictions || event.data.status !== 'OK' || event.data.predictions.length === 0) {
                suggestionsContainer.innerHTML = '<div class="suggestion-item">Sonuç bulunamadı</div>';
                suggestionsContainer.style.display = 'block';
                return;
            }
            
            // Önerileri göster
            event.data.predictions.forEach(prediction => {
                const item = document.createElement('div');
                item.className = 'suggestion-item';
                item.textContent = prediction.description;
                
                item.addEventListener('click', function() {
                    
                    // Input'u güncelle
                    if (!addressInput) addressInput = document.getElementById('address-input');
                    if (addressInput) addressInput.value = prediction.description;
                    
                    // Önerileri gizle
                    suggestionsContainer.style.display = 'none';
                    
                    // Haritada ara
                    if (!mapIframe) mapIframe = document.getElementById('map-iframe');
                    if (mapIframe && mapIframe.contentWindow) {
                        mapIframe.contentWindow.postMessage({
                            action: 'searchByPlaceId',
                            placeId: prediction.place_id
                        }, '*');
                    }
                });
                
                suggestionsContainer.appendChild(item);
            });
            
            suggestionsContainer.style.display = 'block';
        }
    }
    
    // Local map.html'den gelen mesajları dinle (addressDetails action)
    if (event.data && event.data.action === 'addressDetails') {
        const addressData = event.data.addressData;
        const formattedAddress = event.data.formattedAddress;
        
        // Form alanlarını doldur
        handleMapAddressSelection({
            lat: event.data.latitude,
            lng: event.data.longitude,
            address: formattedAddress,
            details: {
                province: addressData.province,
                district: addressData.district,
                neighborhood: addressData.neighborhood,
                street: addressData.street,
                building: addressData.building,
                postcode: addressData.postcode
            }
        });
    }
    
    // mapReady mesajı
    if (event.data && event.data.action === 'mapReady') {
        hideMapLoader();
    }
    
    if (event.origin === 'https://map1.m2destek.net') {
        
        if (event.data && event.data.type === 'addressSelected') {
            const addressData = event.data.data || event.data;
            
            // Koordinatlardan detaylı adres bilgisi al
            fetchAddressDetails(addressData.lat, addressData.lng).then(details => {
                handleMapAddressSelection({
                    lat: addressData.lat,
                    lng: addressData.lng,
                    address: addressData.address,
                    details: { ...addressData.details, ...details }
                });
            }).catch(err => {
                handleMapAddressSelection({
                    lat: addressData.lat,
                    lng: addressData.lng,
                    address: addressData.address,
                    details: addressData.details || {}
                });
            });
        }
        
        if (event.data && event.data.type === 'mapReady') {
            hideMapLoader();
        }
    }
    
    if (event.source === window && event.data && event.data.type === 'testAddressSelection') {
        handleMapAddressSelection(event.data.address);
    }
    
    if (event.data.type === 'mapReady') {
        hideMapLoader();
    }
});

/**
 * Koordinatlardan detaylı adres bilgisi alır (Nominatim reverse geocode)
 */
async function fetchAddressDetails(lat, lng) {
    try {
        const response = await fetch(
            `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json&addressdetails=1&accept-language=tr`,
            {
                headers: {
                    'User-Agent': 'YeKupon Extension/1.0'
                }
            }
        );
        
        if (!response.ok) {
            throw new Error('Nominatim API hatası');
        }
        
        const data = await response.json();
        
        const addr = data.address || {};
        
        return {
            province: addr.province || addr.state || addr.city || '',
            district: addr.town || addr.county || addr.suburb || addr.city_district || '',
            neighbourhood: addr.neighbourhood || addr.suburb || addr.quarter || '',
            road: addr.road || addr.street || '',
            house_number: addr.house_number || '',
            postcode: addr.postcode || '',
            country: addr.country || ''
        };
    } catch (error) {
        return {};
    }
}

function hideMapLoader() {
    const mapLoader = document.getElementById('mapLoader');
    if (mapLoader) {
        mapLoader.style.display = 'none';
    }
}

/**
 * Harita adres verisini parse eder ve tüm form alanlarını otomatik doldurur
 * @param {Object} addressData - Haritadan gelen adres verisi
 */
async function fillAddressForm(addressData) {
    if (!addressData || !addressData.address) return;
    
    const address = addressData.address;
    
    // Adres stringini parçala
    const addressParts = address.split(', ').map(part => part.trim());
    
    // Harita detaylarından bilgi çıkar (varsa)
    const details = addressData.details || {};
    
    // Posta kodunu bul (5 haneli sayı)
    let postalCode = '';
    const postalCodeMatch = address.match(/\b(\d{5})\b/);
    if (postalCodeMatch) {
        postalCode = postalCodeMatch[1];
    }
    
    // İl bul
    const provinceSelect = document.getElementById('province');
    let foundProvince = null;
    let foundProvinceId = null;
    
    if (provinceSelect) {
        // Önce details'dan bak
        if (details.province || details.city || details.state) {
            const detailProvince = details.province || details.city || details.state;
            foundProvince = turkishProvinces.find(p => 
                p.toLowerCase() === detailProvince.toLowerCase() ||
                detailProvince.toLowerCase().includes(p.toLowerCase())
            );
        }
        
        // Detailsda yoksa adres stringinden bul
        if (!foundProvince) {
            for (const province of turkishProvinces) {
                if (address.toLowerCase().includes(province.toLowerCase())) {
                    foundProvince = province;
                    break;
                }
            }
        }
        
        // İstanbul için özel kontrol
        if (!foundProvince && (address.toLowerCase().includes('istanbul') || address.toLowerCase().includes('İstanbul'))) {
            foundProvince = 'İstanbul';
        }
        
        if (foundProvince) {
            // Dropdown'dan değeri seç
            const options = Array.from(provinceSelect.options);
            const matchingOption = options.find(opt => 
                opt.value.toLowerCase() === foundProvince.toLowerCase() ||
                opt.textContent.toLowerCase() === foundProvince.toLowerCase()
            );
            
            if (matchingOption) {
                provinceSelect.value = matchingOption.value;
                foundProvinceId = matchingOption.dataset.cityId;
            }
        }
    }
    
    // İlçe ve mahalle için bekle ve doldur
    if (foundProvince) {
        await updateDistrictSelect(foundProvince);
        
        // İlçe bul - retry loop ile dropdown'un dolmasını bekle
        const districtSelect = document.getElementById('district');
        let foundDistrict = null;
        let foundDistrictId = null;
        
        if (districtSelect) {
            for (let retry = 0; retry < 5; retry++) {
                await new Promise(resolve => setTimeout(resolve, 200));
                const districtOptions = Array.from(districtSelect.options).filter(opt => opt.value);
                if (districtOptions.length > 0) {
                    // Details'dan ilçe bul
                    if (details.district || details.town || details.suburb) {
                        const detailDistrict = details.district || details.town || details.suburb;
                        const matchingDistrict = districtOptions.find(opt =>
                            opt.value.toLowerCase() === detailDistrict.toLowerCase() ||
                            opt.textContent.toLowerCase().includes(detailDistrict.toLowerCase()) ||
                            detailDistrict.toLowerCase().includes(opt.textContent.toLowerCase())
                        );
                        if (matchingDistrict) {
                            foundDistrict = matchingDistrict.value;
                            foundDistrictId = matchingDistrict.dataset.townId;
                        }
                    }
                    
                    // Adres stringinden ilçe bul
                    if (!foundDistrict) {
                        for (const opt of districtOptions) {
                            if (address.toLowerCase().includes(opt.textContent.toLowerCase())) {
                                foundDistrict = opt.value;
                                foundDistrictId = opt.dataset.townId;
                                break;
                            }
                        }
                    }
                    break;
                }
            }
            
            if (foundDistrict) {
                districtSelect.value = foundDistrict;
                
                // Mahalle listesini yükle
                await updateNeighborhoodSelect(foundDistrict);
                
                // Mahalle bul - retry loop ile dropdown'un dolmasını bekle
                const neighborhoodSelect = document.getElementById('neighborhood');
                if (neighborhoodSelect) {
                    let foundNeighborhood = null;
                    
                    for (let retry = 0; retry < 5; retry++) {
                        await new Promise(resolve => setTimeout(resolve, 200));
                        const neighborhoodOptions = Array.from(neighborhoodSelect.options).filter(opt => opt.value);
                        if (neighborhoodOptions.length > 0) {
                    
                    // Details'dan mahalle bul
                    if (details.neighbourhood || details.neighborhood || details.quarter) {
                        const detailNeighborhood = details.neighbourhood || details.neighborhood || details.quarter;
                        const matchingNeighborhood = neighborhoodOptions.find(opt =>
                            opt.value.toLowerCase().includes(detailNeighborhood.toLowerCase()) ||
                            detailNeighborhood.toLowerCase().includes(opt.textContent.toLowerCase().replace(' mahallesi', '').replace(' mah.', ''))
                        );
                        if (matchingNeighborhood) {
                            foundNeighborhood = matchingNeighborhood.value;
                        }
                    }
                    
                    // Adres stringinden mahalle bul
                    if (!foundNeighborhood) {
                        // "Mahallesi" veya "Mah." içeren parçaları ara
                        const neighborhoodPart = addressParts.find(part => 
                            part.toLowerCase().includes('mahallesi') || 
                            part.toLowerCase().includes('mah.')
                        );
                        
                        if (neighborhoodPart) {
                            const cleanNeighborhood = neighborhoodPart
                                .toLowerCase()
                                .replace(' mahallesi', '')
                                .replace(' mah.', '')
                                .trim();
                            
                            const matchingNeighborhood = neighborhoodOptions.find(opt =>
                                opt.textContent.toLowerCase().includes(cleanNeighborhood) ||
                                cleanNeighborhood.includes(opt.textContent.toLowerCase().replace(' mahallesi', '').replace(' mah.', ''))
                            );
                            
                            if (matchingNeighborhood) {
                                foundNeighborhood = matchingNeighborhood.value;
                            }
                        }
                        
                        // Hala bulamadıysa tüm parçalarda ara
                        if (!foundNeighborhood) {
                            for (const part of addressParts) {
                                const matchingNeighborhood = neighborhoodOptions.find(opt =>
                                    opt.textContent.toLowerCase().includes(part.toLowerCase()) ||
                                    part.toLowerCase().includes(opt.textContent.toLowerCase().replace(' mahallesi', ''))
                                );
                                if (matchingNeighborhood) {
                                    foundNeighborhood = matchingNeighborhood.value;
                                    break;
                                }
                            }
                        }
                    }
                    
                            break;
                        }
                    }
                    
                    if (foundNeighborhood) {
                        neighborhoodSelect.value = foundNeighborhood;
                    }
                }
            }
        }
    }
    
    // Posta kodunu doldur (önce details'dan, sonra adres stringinden)
    const postalCodeInput = document.getElementById('postalCode');
    if (postalCodeInput) {
        let finalPostalCode = details.postcode || postalCode;
        if (finalPostalCode) {
            postalCodeInput.value = finalPostalCode;
        }
    }
    
    // Sokak bilgisini doldur (varsa)
    const streetInput = document.getElementById('street');
    if (streetInput && (details.road || details.street)) {
        streetInput.value = details.road || details.street;
    }
    
    // Bina numarasını doldur (varsa)
    const buildingNoInput = document.getElementById('buildingNo');
    if (buildingNoInput && details.house_number) {
        buildingNoInput.value = details.house_number;
    }
    
    showNotification('Adres bilgileri forma aktarıldı!', 'success');
}

function updateActiveAddressLabel(label, district, province) {
    const activeAddressLabel = document.getElementById('activeAddressLabel');
    if (activeAddressLabel) {
        const addressText = activeAddressLabel.querySelector('.active-address-text');
        if (addressText) {
            if (label && district && province) {
                addressText.textContent = `${label}: ${district}/${province}`;
            } else if (label) {
                addressText.textContent = label;
            } else {
                addressText.textContent = 'Aktif adres seçilmedi';
            }
        }
    }
}

let cityDataCache = null;
let cityDataCacheTime = 0;
const CACHE_DURATION = 5 * 60 * 1000;

async function fetchMigrosCities() {
    const now = Date.now();
    if (cityDataCache && (now - cityDataCacheTime) < CACHE_DURATION) {
        return cityDataCache;
    }
    
    try {
        const requestId = Date.now().toString() + Math.floor(Math.random() * 1000000000).toString();
        const apiUrl = `https://www.migros.com.tr/rest/delivery-bff/locations/cities/deliverable?reid=${requestId}`;
        
        const response = await new Promise((resolve, reject) => {
            chrome.runtime.sendMessage({
                action: 'fetchMigrosAPI',
                url: apiUrl
            }, (response) => {
                if (chrome.runtime.lastError) {
                    reject(new Error(chrome.runtime.lastError.message));
                } else {
                    resolve(response);
                }
            });
        });
        
        if (!response.success) {
            throw new Error(response.error || 'API yanıt hatası');
        }
        
        const data = response.data;
        
        cityDataCache = data;
        cityDataCacheTime = now;
        
        return data;
    } catch (error) {
        
        try {
            return [
                { id: 34, name: "İstanbul", latitude: 41.0082, longitude: 28.9784 },
                { id: 6, name: "Ankara", latitude: 39.9334, longitude: 32.8597 },
                { id: 35, name: "İzmir", latitude: 38.4192, longitude: 27.1287 },
                { id: 16, name: "Bursa", latitude: 40.1885, longitude: 29.0610 },
                { id: 1, name: "Adana", latitude: 37.0000, longitude: 35.3213 },
                { id: 7, name: "Antalya", latitude: 36.8841, longitude: 30.7056 },
                { id: 41, name: "Kocaeli", latitude: 40.7654, longitude: 29.9408 }
            ];
        } catch (alternativeError) {
            return [];
        }
    }
}

async function fetchMigrosTowns(cityId) {
    try {
        const requestId = Date.now().toString() + Math.floor(Math.random() * 1000000000).toString();
        const apiUrl = `https://www.migros.com.tr/rest/delivery-bff/locations/towns/${cityId}/deliverable?reid=${requestId}`;
        
        const response = await new Promise((resolve, reject) => {
            chrome.runtime.sendMessage({
                action: 'fetchMigrosAPI',
                url: apiUrl
            }, (response) => {
                if (chrome.runtime.lastError) {
                    reject(new Error(chrome.runtime.lastError.message));
                } else {
                    resolve(response);
                }
            });
        });
        
        if (!response.success) {
            throw new Error(response.error || 'API yanıt hatası');
        }
        
        const data = response.data;
        
        return data;
    } catch (error) {
        return [];
    }
}

async function fetchMigrosDistricts(townId) {
    try {
        const requestId = Date.now().toString() + Math.floor(Math.random() * 1000000000).toString();
        const apiUrl = `https://www.migros.com.tr/rest/delivery-bff/locations/districts/${townId}/deliverable?reid=${requestId}`;
        
        const response = await new Promise((resolve, reject) => {
            chrome.runtime.sendMessage({
                action: 'fetchMigrosAPI',
                url: apiUrl
            }, (response) => {
                if (chrome.runtime.lastError) {
                    reject(new Error(chrome.runtime.lastError.message));
                } else {
                    resolve(response);
                }
            });
        });
        
        if (!response.success) {
            throw new Error(response.error || 'API yanıt hatası');
        }
        
        const data = response.data;
        
        return data;
    } catch (error) {
        
        if (townId && townId.toString().length >= 4) {
            try {
                const townIdPrefix = townId.toString().substring(0, townId.toString().length - 2);
                const altRequestId = Date.now().toString() + Math.floor(Math.random() * 1000000000).toString();
                const altApiUrl = `https://www.migros.com.tr/rest/delivery-bff/locations/districts/${townIdPrefix}00/deliverable?reid=${altRequestId}`;
                
                const altResponse = await new Promise((resolve, reject) => {
                    chrome.runtime.sendMessage({
                        action: 'fetchMigrosAPI',
                        url: altApiUrl
                    }, (response) => {
                        if (chrome.runtime.lastError) {
                            reject(new Error(chrome.runtime.lastError.message));
                        } else {
                            resolve(response);
                        }
                    });
                });
                
                if (altResponse.success) {
                    const altData = altResponse.data;
                    return altData;
                }
            } catch (altError) {
            }
        }
        
        return [];
    }
}

function showNotification(message, type = 'info') {
    const existingNotification = document.querySelector('.notification');
    if (existingNotification) {
        existingNotification.remove();
    }

    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <span class="material-icons-round">${type === 'success' ? 'check_circle' : type === 'error' ? 'error' : 'info'}</span>
        <span>${message}</span>
    `;

    document.body.appendChild(notification);

    setTimeout(() => notification.classList.add('show'), 100);

    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            if (document.body.contains(notification)) {
                document.body.removeChild(notification);
            }
        }, 300);
    }, 3000);
}

function openModal(modal) {
    if (modal) {
        modal.classList.add('show');
        document.body.style.overflow = 'hidden';
    }
}

function closeModal(modal) {
    if (modal) {
        modal.classList.remove('show');
        document.body.style.overflow = '';
    }
}

function setTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('yekupon-theme', theme);
    
    document.querySelectorAll('.theme-option').forEach(option => {
        option.classList.remove('active');
        if (option.dataset.theme === theme) {
            option.classList.add('active');
        }
    });
}

let addressListenerAdded = false;

function addAddressCardEventListeners() {
    const savedAddressesList = document.getElementById('savedAddressesList');
    if (!savedAddressesList) {
        return;
    }
    
    // Listener zaten eklendiyse tekrar ekleme
    if (addressListenerAdded) {
        return;
    }
    
    addressListenerAdded = true;
    
    savedAddressesList.addEventListener('click', function(e) {
        
        const button = e.target.closest('.address-action-button');
        if (!button) {
            return;
        }
        
        
        e.preventDefault();
        e.stopPropagation();
        
        const action = button.getAttribute('data-action');
        const addressId = parseInt(button.getAttribute('data-address-id'));
        
        if (!action || !addressId) {
            return;
        }
        
        if (button.disabled) {
            return;
        }
        
        switch (action) {
            case 'use':
                useAddress(addressId);
                break;
            case 'edit':
                editAddress(addressId);
                break;
            case 'delete':
                confirmDeleteAddress(addressId);
                break;
            default:
                break;
        }
    });
}

function loadSavedAddresses() {
    const savedAddressesList = document.getElementById('savedAddressesList');
    if (!savedAddressesList) return;
    
    if (savedAddresses.length === 0) {
        savedAddressesList.innerHTML = `
            <div class="empty-addresses">
                <span class="material-icons-round">location_off</span>
                <p>Henüz kayıtlı adres bulunmuyor</p>
            </div>
        `;
        return;
    }
    
    savedAddressesList.innerHTML = savedAddresses.map(address => `
        <div class="address-card" data-id="${address.id}">
            <div class="address-card-header">
                <div class="address-label">
                    <span class="material-icons-round" data-icon="location_on">location_on</span>
                    <span>${address.label}</span>
                    ${address.isActive ? '<span class="address-card-badge active">Aktif</span>' : ''}
                </div>
                <div class="address-card-actions">
                    ${!address.isActive ? `
                        <button class="address-action-button use" data-action="use" data-address-id="${address.id}" title="Bu adresi aktif yap">
                            <span class="material-icons-round" data-icon="radio_button_unchecked">radio_button_unchecked</span>
                        </button>
                    ` : `
                        <button class="address-action-button active" disabled title="Aktif adres">
                            <span class="material-icons-round" data-icon="radio_button_checked">radio_button_checked</span>
                        </button>
                    `}
                    <button class="address-action-button edit" data-action="edit" data-address-id="${address.id}" title="Adresi düzenle">
                        <span class="material-icons-round" data-icon="edit">edit</span>
                    </button>
                    <button class="address-action-button delete" data-action="delete" data-address-id="${address.id}" title="Adresi sil">
                        <span class="material-icons-round" data-icon="delete">delete</span>
                    </button>
                </div>
            </div>
            <div class="address-card-content">
                <p class="address-full">${address.fullAddress || address.address}</p>
                ${address.description ? `<p class="address-description">"${address.description}"</p>` : ''}
                <div class="address-meta">
                    <small class="creation-date"><span class="material-icons-round" data-icon="date_range">date_range</span> ${new Date(address.createdAt).toLocaleDateString('tr-TR')}</small>
                    ${address.phone ? `<small class="phone-number"><span class="material-icons-round" data-icon="phone">phone</span> ${address.phone}</small>` : ''}
                </div>
            </div>
        </div>
    `).join('');
    
    addAddressCardEventListeners();
}

function saveAddress() {
    
    if (!selectedAddress) {
        showNotification('Lütfen önce haritadan bir adres seçin!', 'error');
        return;
    }
    
    const form = document.getElementById('address-form');
    const formData = new FormData(form);
    
    const addressLabelSelect = document.getElementById('addressLabelSelect');
    const customLabelInput = document.getElementById('customAddressLabel');
    
    let label = 'Yeni Adres';
    if (addressLabelSelect && addressLabelSelect.value === 'ozel' && customLabelInput && customLabelInput.value) {
        label = customLabelInput.value;
    } else if (addressLabelSelect) {
        const selectedOption = addressLabelSelect.options[addressLabelSelect.selectedIndex];
        label = selectedOption.text;
    }
    
    // Dropdown'lardan Migros API ID'lerini al
    const provinceSelect = document.getElementById('province');
    const districtSelect = document.getElementById('district');
    const neighborhoodSelect = document.getElementById('neighborhood');
    
    // ID'leri al - seçili option'un dataset'inden
    let cityId = null;
    let townId = null;
    let districtId = null;
    
    if (provinceSelect && provinceSelect.selectedOptions[0]) {
        cityId = parseInt(provinceSelect.selectedOptions[0].dataset.cityId) || null;
    }
    
    if (districtSelect && districtSelect.selectedOptions[0]) {
        townId = parseInt(districtSelect.selectedOptions[0].dataset.townId) || null;
    }
    
    if (neighborhoodSelect && neighborhoodSelect.selectedOptions[0]) {
        districtId = parseInt(neighborhoodSelect.selectedOptions[0].dataset.districtId) || null;
    }
    
    // Check if we're editing an existing address
    const addressIdInput = document.getElementById('addressId');
    const editingId = addressIdInput && addressIdInput.value ? parseInt(addressIdInput.value) : null;
    const existingIndex = editingId ? savedAddresses.findIndex(addr => addr.id === editingId) : -1;

    const newAddress = {
        id: existingIndex >= 0 ? editingId : Date.now(),
        label: label,
        address: selectedAddress.address,
        fullAddress: buildFullAddress(formData),
        lat: selectedAddress.lat,
        lng: selectedAddress.lng,
        latitude: selectedAddress.lat,   // Alternatif alan adı
        longitude: selectedAddress.lng,  // Alternatif alan adı
        province: formData.get('province'),
        district: formData.get('district'),
        neighborhood: formData.get('neighborhood'),
        street: formData.get('street'),
        buildingNo: formData.get('buildingNo'),
        floor: formData.get('floor'),
        apartmentNo: formData.get('apartmentNo'),
        postalCode: formData.get('postalCode'),
        phone: formData.get('phone'),
        description: formData.get('description'),
        fullName: formData.get('fullName'),
        // Migros API için gerekli ID'ler
        cityId: cityId,
        townId: townId,
        districtId: districtId,
        // Alternatif alan adları (background.js uyumluluğu için)
        city_id: cityId,
        town_id: townId,
        district_id: districtId,
        // İl/İlçe/Mahalle isimleri (background.js uyumluluğu için)
        cityName: formData.get('province'),
        townName: formData.get('district'),
        districtName: formData.get('neighborhood'),
        autoFillAddress: formData.get('autoFillAddress') === 'on',
        randomSpaces: formData.get('randomSpaces') === 'on',
        cleanAddress: formData.get('cleanAddress') === 'on',
        useCleanAddress: formData.get('cleanAddress') === 'on',
        createdAt: new Date().toISOString(),
        isActive: savedAddresses.length === 0
    };
    
    if (existingIndex >= 0) {
        // Editing: preserve isActive and createdAt from existing
        newAddress.isActive = savedAddresses[existingIndex].isActive;
        newAddress.createdAt = savedAddresses[existingIndex].createdAt;
        savedAddresses[existingIndex] = newAddress;
    } else {
        savedAddresses.push(newAddress);
    }
    localStorage.setItem('yekupon_saved_addresses', JSON.stringify(savedAddresses));
    
    if (typeof chrome !== 'undefined' && chrome.storage) {
        chrome.storage.local.set({
            'yekupon_saved_addresses': savedAddresses
        });
    }
    
    showNotification('Adres başarıyla kaydedildi!', 'success');
    
    if (form) form.reset();
    
    const autoFillCheckbox = document.getElementById('autoFillAddress');
    if (autoFillCheckbox) autoFillCheckbox.checked = true;
    
    
    if (newAddress.isActive || savedAddresses.length === 1) {
        selectedAddress = newAddress;
        updateActiveAddressLabel(newAddress.label, newAddress.district, newAddress.province);
    } else {
        selectedAddress = null;
        updateActiveAddressLabel(null);
    }
    
    loadSavedAddresses();
    
    showSavedAddresses();
}

function buildFullAddress(formData) {
    const parts = [];
    
    if (formData.get('neighborhood')) parts.push(formData.get('neighborhood'));
    if (formData.get('street')) parts.push(formData.get('street'));
    if (formData.get('buildingNo')) parts.push('No:' + formData.get('buildingNo'));
    if (formData.get('floor')) parts.push('Kat:' + formData.get('floor'));
    if (formData.get('apartmentNo')) parts.push('D:' + formData.get('apartmentNo'));
    if (formData.get('district')) parts.push(formData.get('district'));
    if (formData.get('province')) parts.push(formData.get('province'));
    if (formData.get('postalCode')) parts.push(formData.get('postalCode'));
    
    return parts.join(', ');
}

function getActiveAddress() {
    // localStorage'dan güncel veriyi oku
    const storedAddresses = localStorage.getItem('yekupon_saved_addresses');
    if (storedAddresses) {
        try {
            savedAddresses = JSON.parse(storedAddresses);
        } catch (e) {
            console.error('getActiveAddress: JSON parse hatası:', e);
        }
    }
    
    if (!savedAddresses || savedAddresses.length === 0) {
        return null;
    }
    
    const activeAddress = savedAddresses.find(addr => addr.isActive === true);
    
    if (activeAddress) {
        return activeAddress;
    }
    
    return savedAddresses[0];
}

function useAddress(addressId) {
    
    savedAddresses.forEach(addr => addr.isActive = false);
    
    const address = savedAddresses.find(addr => addr.id === addressId);
    if (address) {
        address.isActive = true;
        updateActiveAddressLabel(address.label, address.district, address.province);
        
        localStorage.setItem('yekupon_saved_addresses', JSON.stringify(savedAddresses));
        
        if (typeof chrome !== 'undefined' && chrome.storage) {
            chrome.storage.local.set({
                'yekupon_saved_addresses': savedAddresses
            }).catch(err => {});
        }
        
        loadSavedAddresses();
        showNotification(`"${address.label}" aktif adres olarak ayarlandı!`, 'success');
    }
}

function editAddress(addressId) {
    const address = savedAddresses.find(addr => addr.id === addressId);
    if (!address) return;
    
    const addressIdInput = document.getElementById('addressId');
    const addressInput = document.getElementById('address-input');
    
    if (addressIdInput) addressIdInput.value = address.id;
    if (addressInput) addressInput.value = address.address;
    
    const provinceSelect = document.getElementById('province');
    const districtSelect = document.getElementById('district');
    const neighborhoodSelect = document.getElementById('neighborhood');
    
    if (provinceSelect && address.province) provinceSelect.value = address.province;
    if (districtSelect && address.district) districtSelect.value = address.district;
    if (neighborhoodSelect && address.neighborhood) neighborhoodSelect.value = address.neighborhood;
    
    const fields = ['street', 'buildingNo', 'floor', 'apartmentNo', 'postalCode', 'phone', 'description', 'fullName'];
    fields.forEach(field => {
        const input = document.getElementById(field);
        if (input && address[field]) input.value = address[field];
    });
    
    const checkboxes = ['autoFillAddress', 'randomSpaces', 'cleanAddress'];
    checkboxes.forEach(checkbox => {
        const input = document.getElementById(checkbox);
        if (input) input.checked = address[checkbox] || false;
    });
    
    showAddressForm(true);
    
    const deleteButton = document.getElementById('deleteAddressButton');
    if (deleteButton) deleteButton.style.display = 'block';
    
    selectedAddress = {
        lat: address.lat,
        lng: address.lng,
        address: address.address
    };
}

function confirmDeleteAddress(addressId) {
    const address = savedAddresses.find(addr => addr.id === addressId);
    if (!address) return;
    
    const confirmModal = document.createElement('div');
    confirmModal.className = 'confirm-modal-overlay';
    confirmModal.innerHTML = `
        <div class="confirm-modal">
            <div class="confirm-modal-header">
                <span class="material-icons-round confirm-icon" data-icon="warning">warning</span>
                <h3>Adresi Sil</h3>
            </div>
            <div class="confirm-modal-body">
                <p><strong>"${address.label}"</strong> adresini silmek istediğinize emin misiniz?</p>
                <div class="address-preview">
                    <small>${address.fullAddress || address.address}</small>
                </div>
                ${address.isActive ? '<p class="warning-text"><span class="material-icons-round" data-icon="priority_high">priority_high</span> Bu aktif adresiniz, silinirse başka bir adres seçmeniz gerekecek.</p>' : ''}
            </div>
            <div class="confirm-modal-actions">
                <button class="confirm-button cancel" data-action="cancel">
                    <span class="material-icons-round" data-icon="close">close</span> İptal
                </button>
                <button class="confirm-button delete" data-action="delete" data-address-id="${addressId}">
                    <span class="material-icons-round" data-icon="delete">delete</span> Sil
                </button>
            </div>
        </div>
    `;
    
    document.body.appendChild(confirmModal);
    
    const modalButtons = confirmModal.querySelectorAll('.confirm-button');
    modalButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const action = this.getAttribute('data-action');
            
            if (action === 'cancel') {
                closeConfirmModal();
            } else if (action === 'delete') {
                const deleteAddressId = parseInt(this.getAttribute('data-address-id'));
                deleteAddress(deleteAddressId);
                closeConfirmModal();
            }
        });
    });
    
    setTimeout(() => confirmModal.classList.add('show'), 100);
}

function closeConfirmModal() {
    const confirmModal = document.querySelector('.confirm-modal-overlay');
    if (confirmModal) {
        confirmModal.classList.remove('show');
        setTimeout(() => {
            if (document.body.contains(confirmModal)) {
                document.body.removeChild(confirmModal);
            }
        }, 300);
    }
}

function deleteAddress(addressId) {
    const address = savedAddresses.find(addr => addr.id === addressId);
    if (!address) {
        return;
    }
    
    // NOT: Migros API'sine silme isteği GÖNDERİLMEZ
    // Migros adresleri sadece token kullanımı sırasında yönetilir
    // Bu fonksiyon sadece yerel (eklenti içi) adresleri siler
    
    // Yerel listeden sil
    savedAddresses = savedAddresses.filter(addr => addr.id !== addressId);
    localStorage.setItem('yekupon_saved_addresses', JSON.stringify(savedAddresses));
    
    if (typeof chrome !== 'undefined' && chrome.storage) {
        chrome.storage.local.set({
            'yekupon_saved_addresses': savedAddresses
        }).catch(err => {});
    }
    
    loadSavedAddresses();
    showNotification(`"${address.label}" adresi silindi!`, 'success');
    
    if (address.isActive) {
        updateActiveAddressLabel(null);
        
        if (savedAddresses.length > 0) {
            const firstAddress = savedAddresses[0];
            firstAddress.isActive = true;
            localStorage.setItem('yekupon_saved_addresses', JSON.stringify(savedAddresses));
            
            if (typeof chrome !== 'undefined' && chrome.storage) {
                chrome.storage.local.set({
                    'yekupon_saved_addresses': savedAddresses
                }).catch(err => {});
            }
            
            updateActiveAddressLabel(firstAddress.label, firstAddress.district, firstAddress.province);
            loadSavedAddresses();
            showNotification(`"${firstAddress.label}" otomatik olarak aktif adres yapıldı.`, 'info');
        }
    }
}

function showAddressForm(isEdit = false) {
    const savedSection = document.getElementById('savedAddressesSection');
    const formSection = document.getElementById('addressFormSection');
    
    if (savedSection) savedSection.style.display = 'none';
    if (formSection) formSection.style.display = 'block';
    
    const formTitle = document.getElementById('formTitle');
    if (formTitle) {
        if (isEdit) {
            formTitle.textContent = 'Adresi Düzenle';
        } else {
            formTitle.textContent = 'Yeni Adres Ekle';
        }
    }
}

function showSavedAddresses() {
    const formSection = document.getElementById('addressFormSection');
    const savedSection = document.getElementById('savedAddressesSection');
    
    if (formSection) formSection.style.display = 'none';
    if (savedSection) savedSection.style.display = 'block';
    
    const form = document.getElementById('address-form');
    if (form) {
        form.reset();
        
        const autoFillCheckbox = document.getElementById('autoFillAddress');
        if (autoFillCheckbox) autoFillCheckbox.checked = true;
        
        const addressIdInput = document.getElementById('addressId');
        if (addressIdInput) addressIdInput.value = '';
        
        const deleteButton = document.getElementById('deleteAddressButton');
        if (deleteButton) deleteButton.style.display = 'none';
    }
    
    selectedAddress = null;
    loadSavedAddresses();
}

document.addEventListener('DOMContentLoaded', function() {
    
    // Phone help modal setup
    const phoneHelpIcon = document.getElementById('phoneHelpIcon');
    const phoneInfoModal = document.getElementById('phoneInfoModal');
    const closePhoneInfoModal = document.getElementById('closePhoneInfoModal');
    
    if (phoneHelpIcon && phoneInfoModal) {
        phoneHelpIcon.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            phoneInfoModal.classList.add('show');
        });
        
        closePhoneInfoModal.addEventListener('click', function() {
            phoneInfoModal.classList.remove('show');
        });
        
        phoneInfoModal.addEventListener('click', function(e) {
            if (e.target === phoneInfoModal) {
                phoneInfoModal.classList.remove('show');
            }
        });
    }
    
    // Adres arama sistemi kurulumu
    addressInput = document.getElementById('address-input');
    suggestionsContainer = document.getElementById('suggestions-container');
    mapIframe = document.getElementById('map-iframe');
    
    // Adres arama input'u olayları
    if (addressInput && suggestionsContainer && mapIframe) {
        addressInput.addEventListener('input', function() {
            const query = this.value.trim();
            
            clearTimeout(suggestionTimeout);
            
            if (query.length < 3) {
                suggestionsContainer.style.display = 'none';
                return;
            }
            
            // Loading göster
            suggestionsContainer.innerHTML = '<div class="suggestion-item">Aranıyor...</div>';
            suggestionsContainer.style.display = 'block';
            
            // Debounce ile arama
            suggestionTimeout = setTimeout(() => {
                if (mapIframe && mapIframe.contentWindow) {
                    mapIframe.contentWindow.postMessage({
                        action: 'getSuggestions',
                        query: query
                    }, '*');
                } else {
                    console.error('[YeKupon] iframe hazır değil');
                    suggestionsContainer.innerHTML = '<div class="suggestion-item">Harita yükleniyor...</div>';
                }
            }, 500);
        });
        
        // Enter ile arama
        addressInput.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                const query = this.value.trim();
                if (query.length > 2 && mapIframe && mapIframe.contentWindow) {
                    suggestionsContainer.style.display = 'none';
                    mapIframe.contentWindow.postMessage({
                        action: 'searchAddress',
                        address: query
                    }, '*');
                }
            }
        });
        
        // Dışarı tıkla önerileri kapat
        document.addEventListener('click', function(e) {
            if (!e.target.closest('.search-section')) {
                suggestionsContainer.style.display = 'none';
            }
        });
    }
    
    const autoFillCheckbox = document.getElementById('autoFillAddress');
    if (autoFillCheckbox) autoFillCheckbox.checked = true;
    
    initializeProvinceSelect();
    
    const provinceSelect = document.getElementById('province');
    const districtSelect = document.getElementById('district');
    
    if (provinceSelect) {
        provinceSelect.addEventListener('change', function() {
            const selectedProvince = this.value;
            updateDistrictSelect(selectedProvince);
        });
    }
    
    if (districtSelect) {
        districtSelect.addEventListener('change', function() {
            const selectedDistrict = this.value;
            updateNeighborhoodSelect(selectedDistrict);
        });
    }
    
    const phoneInput = document.getElementById('phone');
    if (phoneInput) {
        phoneInput.addEventListener('input', function(e) {
            let value = e.target.value.replace(/[^0-9]/g, '');
            
            if (value.length > 10) {
                value = value.substring(0, 10);
            }
            
            e.target.value = value;
        });
        
        phoneInput.addEventListener('paste', function(e) {
            e.preventDefault();
            const paste = (e.clipboardData || window.clipboardData).getData('text');
            const numbersOnly = paste.replace(/[^0-9]/g, '').substring(0, 10);
            this.value = numbersOnly;
        });
        
        phoneInput.addEventListener('keypress', function(e) {
            if (!/[0-9]/.test(e.key) && !['Backspace', 'Delete', 'ArrowLeft', 'ArrowRight', 'Tab'].includes(e.key)) {
                e.preventDefault();
            }
        });
    }
    
    const addAddressButton = document.getElementById('addAddressButton');
    const savedAddressesButton = document.getElementById('savedAddressesButton');
    const addressModal = document.getElementById('addressModal');
    const closeAddressModal = document.getElementById('closeAddressModal');
    const newAddressButton = document.getElementById('newAddressButton');
    const backToListButton = document.getElementById('backToListButton');
    const addressForm = document.getElementById('address-form');
    const openMapButton = document.getElementById('openMapButton');
    
    const tgoYemekTokenInput = document.getElementById('tgoYemekTokenInput');
    const tgoYemekLoginConfirm = document.getElementById('tgoYemekLoginConfirm');
    const tgoYemekLoginCancel = document.getElementById('tgoYemekLoginCancel');
    
    const addressLabelSelect = document.getElementById('addressLabelSelect');
    const customLabelGroup = document.getElementById('customLabelGroup');
    
    if (addAddressButton) {
        addAddressButton.addEventListener('click', () => {
            openModal(addressModal);
            showAddressForm(false);
        });
    }
    
    if (savedAddressesButton) {
        savedAddressesButton.addEventListener('click', () => {
            openModal(addressModal);
            showSavedAddresses();
        });
    }
    
    if (closeAddressModal) {
        closeAddressModal.addEventListener('click', () => {
            closeModal(addressModal);
        });
    }
    
    if (newAddressButton) {
        newAddressButton.addEventListener('click', () => {
            showAddressForm(false);
        });
    }
    
    if (backToListButton) {
        backToListButton.addEventListener('click', () => {
            showSavedAddresses();
        });
    }
    
    if (tgoYemekLoginConfirm && tgoYemekTokenInput) {
        tgoYemekLoginConfirm.addEventListener('click', () => {
            handleTgoYemekLogin();
        });
        
        tgoYemekTokenInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                handleTgoYemekLogin();
            }
        });
    }
    
    if (tgoYemekLoginCancel) {
        tgoYemekLoginCancel.addEventListener('click', () => {
            tgoYemekTokenInput.value = '';
        });
    }
    
    const toggleMapButton = document.getElementById('toggleMapButton');
    const confirmMapSelection = document.getElementById('confirmMapSelection');
    const mapIframeContainer = document.getElementById('mapIframeContainer');
    const yekuponMapFrame = document.getElementById('yekuponMapFrame');
    const mapLoader = document.getElementById('mapLoader');
    
    if (toggleMapButton && mapIframeContainer && yekuponMapFrame) {
        toggleMapButton.addEventListener('click', () => {
            const isVisible = mapIframeContainer.classList.contains('visible');
            
            if (!isVisible) {
                mapIframeContainer.classList.add('visible');
                toggleMapButton.innerHTML = '<span class="material-icons-round">close</span> Haritayı Gizle';
                
                setTimeout(() => {
                    if (mapLoader) mapLoader.style.display = 'none';
                    yekuponMapFrame.style.display = 'block';
                    
                    if (confirmMapSelection) {
                        confirmMapSelection.style.display = 'inline-flex';
                    }
                }, 2000);
                
                showNotification('M2Destek haritası yüklendi. Adresinizi seçin.', 'info');
            } else {
                mapIframeContainer.classList.remove('visible');
                toggleMapButton.innerHTML = '<span class="material-icons-round">map</span> Haritayı Göster';
                
                if (confirmMapSelection) {
                    confirmMapSelection.style.display = 'none';
                }
                
                if (mapLoader) mapLoader.style.display = 'block';
                yekuponMapFrame.style.display = 'none';
            }
        });
    }
    
    if (confirmMapSelection) {
        confirmMapSelection.addEventListener('click', () => {
            
            try {
                const iframe = document.getElementById('yekuponMapFrame');
                if (iframe && iframe.contentWindow) {
                    iframe.contentWindow.postMessage({ action: 'getSelectedAddress' }, '*');
                }
            } catch (error) {
                
                const demoAddress = {
                    lat: 41.0055,
                    lng: 28.9769,
                    address: 'Cankurtaran, Alemdar Cd., 34110 Fatih/İstanbul, Türkiye'
                };
                
                handleMapAddressSelection(demoAddress);
                showNotification('Demo adres seçildi. Form doldurabilirsiniz.', 'success');
            }
        });
    }
    
    window.addEventListener('message', (event) => {
        if (event.data && event.data.action === 'addressSelected') {
            handleMapAddressSelection(event.data.address);
            showNotification('Adres seçildi. Form doldurabilirsiniz.', 'success');
        }
    });
    
    if (addressForm) {
        addressForm.addEventListener('submit', (e) => {
            e.preventDefault();
            saveAddress();
        });
    }
    
    if (addressLabelSelect && customLabelGroup) {
        addressLabelSelect.addEventListener('change', () => {
            if (addressLabelSelect.value === 'ozel') {
                customLabelGroup.style.display = 'block';
            } else {
                customLabelGroup.style.display = 'none';
            }
        });
    }
    
    document.addEventListener('click', (e) => {
        
        if (e.target.classList.contains('overlay')) {
            const modal = document.getElementById('addressModal');
            closeModal(modal);
        }
    });
    
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            const openModalEl = document.querySelector('.modal.show');
            if (openModalEl) {
                closeModal(openModalEl);
            }
            const themeDropdown = document.getElementById('themeDropdown');
            if (themeDropdown) {
                themeDropdown.classList.remove('show');
            }
        }
    });
    
    
    loadSavedAddresses();
    const activeAddress = savedAddresses.find(addr => addr.isActive);
    if (activeAddress) {
        selectedAddress = activeAddress;
        updateActiveAddressLabel(activeAddress.label, activeAddress.district, activeAddress.province);
    } else if (savedAddresses.length > 0) {
        
        const firstAddress = savedAddresses[0];
        firstAddress.isActive = true;
        selectedAddress = firstAddress;
        updateActiveAddressLabel(firstAddress.label, firstAddress.district, firstAddress.province);
        
        
        localStorage.setItem('yekupon_saved_addresses', JSON.stringify(savedAddresses));
        if (typeof chrome !== 'undefined' && chrome.storage) {
            chrome.storage.local.set({
                'yekupon_saved_addresses': savedAddresses
            }).catch(err => {});
        }
        
    } else {
        updateActiveAddressLabel(null);
    }
    
    
    window.testAddressSelection = function(addressData) {
        // Test address selection - empty body for compatibility
    };
});

function handleTgoYemekLogin() {
    const tokenInput = document.getElementById('tgoYemekTokenInput');
    const token = tokenInput.value.trim();
    
    if (!token) {
        showNotification('Lütfen token giriniz!', 'error');
        return;
    }
    
    const tokenInputSection = document.getElementById('tokenInputSection');
    if (tokenInputSection) {
        tokenInputSection.style.display = 'none';
    }
    
    const activeAddress = getActiveAddress();
    let userData = null;
    
    if (activeAddress) {
        userData = {
            address: {
                province: activeAddress.province,
                district: activeAddress.district,
                neighborhood: activeAddress.neighborhood,
                street: activeAddress.street,
                building: activeAddress.buildingNo,
                floor: activeAddress.floor,
                apartment: activeAddress.apartmentNo,
                postcode: activeAddress.postalCode,
                phone: activeAddress.phone,
                description: activeAddress.description,
                latitude: activeAddress.lat,
                longitude: activeAddress.lng
            }
        };
    }
    
    if (token.startsWith('mg')) {
        showNotification('Migros girişi başlatılıyor...', 'info');
        
        chrome.runtime.sendMessage({
            action: 'handleMigrosLogin',
            token: token,
            userData: userData,
            tabId: null
        }, (response) => {
            if (chrome.runtime.lastError) {
                showNotification('Migros giriş hatası: ' + chrome.runtime.lastError.message, 'error');
            } else if (response && response.success) {
                showNotification('Migros giriş işlemi başlatıldı!', 'success');
                tokenInput.value = '';
            } else {
                showNotification('Migros giriş başarısız!', 'error');
            }
        });
    } else if (token.startsWith('ty')) {
        showNotification('TgoYemek girişi başlatılıyor...', 'info');
        
        chrome.runtime.sendMessage({
            action: 'handleTgoYemekLogin',
            token: token,
            userData: userData,
            tabId: null
        }, (response) => {
            if (chrome.runtime.lastError) {
                showNotification('TgoYemek giriş hatası: ' + chrome.runtime.lastError.message, 'error');
            } else if (response && response.success) {
                showNotification('TgoYemek giriş işlemi başlatıldı!', 'success');
                tokenInput.value = '';
            } else {
                showNotification('TgoYemek giriş başarısız!', 'error');
            }
        });
    } else if (token.startsWith('ys') || token.startsWith('yx')) {
        showNotification('YemekSepeti girişi başlatılıyor...', 'info');
        
        chrome.runtime.sendMessage({
            action: 'handleYemekSepetiLogin',
            token: token,
            userData: userData,
            tabId: null
        }, (response) => {
            if (chrome.runtime.lastError) {
                showNotification('YemekSepeti giriş hatası: ' + chrome.runtime.lastError.message, 'error');
            } else if (response && response.success) {
                showNotification('YemekSepeti giriş işlemi başlatıldı!', 'success');
                tokenInput.value = '';
            } else {
                showNotification('YemekSepeti giriş başarısız!', 'error');
            }
        });
    } else if (token.startsWith('ub-')) {
        showNotification('Uber girişi başlatılıyor...', 'info');
        
        chrome.runtime.sendMessage({
            action: 'handleUberLogin',
            token: token,
            userData: userData,
            tabId: null
        }, (response) => {
            if (chrome.runtime.lastError) {
                showNotification('Uber giriş hatası: ' + chrome.runtime.lastError.message, 'error');
            } else if (response && response.success) {
                showNotification('Uber giriş işlemi başlatıldı!', 'success');
                tokenInput.value = '';
            } else {
                showNotification('Uber giriş başarısız!', 'error');
            }
        });
    } else {
        showNotification('YemekSepeti girişi başlatılıyor... (default)', 'info');
        
        chrome.runtime.sendMessage({
            action: 'handleYemekSepetiLogin',
            token: token,
            userData: userData,
            tabId: null
        }, (response) => {
            if (chrome.runtime.lastError) {
                showNotification('YemekSepeti giriş hatası: ' + chrome.runtime.lastError.message, 'error');
            } else if (response && response.success) {
                showNotification('YemekSepeti giriş işlemi başlatıldı!', 'success');
                tokenInput.value = '';
            } else {
                showNotification('YemekSepeti giriş başarısız!', 'error');
            }
        });
    }
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    
    if (request.action === 'updateLog') {
        showNotification(request.message, request.type);
        sendResponse({ received: true });
        return true;
    }
    
    // Alt kısımda şeffaf uyarı göster
    if (request.action === 'showBottomWarning') {
        showBottomWarning(request.message);
        // Aynı zamanda notification da göster
        showNotification(request.message, 'warning');
        sendResponse({ received: true });
        return true;
    }
    
    // logMessage action'ı için de notification göster (Migros hataları için)
    if (request.action === 'logMessage' && request.platform === 'migros') {
        if (request.type === 'error') {
            showNotification(request.message, 'error');
            showBottomWarning(request.message);
        } else if (request.type === 'warning') {
            showNotification(request.message, 'warning');
        }
        sendResponse({ received: true });
        return true;
    }
    
    if (request.action === 'getStoredAddresses') {
        
        try {
            const addresses = JSON.parse(localStorage.getItem('yekupon_saved_addresses') || '[]');
            
            sendResponse({
                success: true,
                addresses: addresses
            });
        } catch (error) {
            sendResponse({
                success: false,
                addresses: []
            });
        }
        
        return true;
    }
});

// Alt kısımda şeffaf uyarı gösterme fonksiyonu
function showBottomWarning(message) {
    // CSS stillerini ekle (sadece bir kez)
    if (!document.getElementById('bottom-warning-styles')) {
        const style = document.createElement('style');
        style.id = 'bottom-warning-styles';
        style.textContent = `
            .bottom-warning {
                position: fixed;
                bottom: 24px;
                left: 50%;
                transform: translateX(-50%) translateY(100px);
                z-index: 999999;
                padding: 14px 20px;
                background: linear-gradient(135deg, rgba(26, 31, 46, .95), rgba(15, 20, 35, .97));
                backdrop-filter: blur(12px);
                -webkit-backdrop-filter: blur(12px);
                color: #e2e8f0;
                font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
                font-size: 14px;
                font-weight: 500;
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 16px;
                max-width: 600px;
                width: calc(100% - 48px);
                border-radius: 14px;
                border: 1px solid rgba(255, 71, 87, .15);
                transition: transform 0.4s cubic-bezier(.16, 1, .3, 1), opacity 0.3s ease;
                box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4), 0 0 0 1px rgba(255, 255, 255, .03);
                opacity: 0;
            }
            .bottom-warning::before {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 2px;
                background: linear-gradient(90deg, transparent, #ff4757, #ff6b81, transparent);
                border-radius: 14px 14px 0 0;
            }
            .bottom-warning.show {
                transform: translateX(-50%) translateY(0);
                opacity: 1;
            }
            .bottom-warning-content {
                display: flex;
                align-items: center;
                gap: 12px;
                flex: 1;
            }
            .bottom-warning-content .material-icons-round {
                font-size: 22px;
                color: #ff4757;
            }
            .bottom-warning-message {
                flex: 1;
                line-height: 1.4;
                color: #94a3b8;
            }
            .bottom-warning-close {
                background: rgba(255, 255, 255, .05);
                border: 1px solid rgba(148, 163, 184, .1);
                color: #64748b;
                width: 32px;
                height: 32px;
                border-radius: 10px;
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                transition: all 0.2s ease;
                flex-shrink: 0;
            }
            .bottom-warning-close:hover {
                background: rgba(255, 71, 87, .1);
                color: #ff4757;
                border-color: rgba(255, 71, 87, .2);
            }
            .bottom-warning-close .material-icons-round {
                font-size: 20px;
            }
        `;
        document.head.appendChild(style);
    }
    
    // Mevcut uyarıyı kaldır
    const existingWarning = document.querySelector('.bottom-warning');
    if (existingWarning) {
        existingWarning.remove();
    }
    
    // Yeni uyarı oluştur
    const warning = document.createElement('div');
    warning.className = 'bottom-warning';
    warning.innerHTML = `
        <div class="bottom-warning-content">
            <span class="material-icons-round">warning</span>
            <span class="bottom-warning-message">${message}</span>
        </div>
        <button class="bottom-warning-close" title="Kapat">
            <span class="material-icons-round">close</span>
        </button>
    `;
    
    document.body.appendChild(warning);
    
    // Animasyonla göster
    requestAnimationFrame(() => {
        warning.classList.add('show');
    });
    
    // Kapatma butonu
    const closeBtn = warning.querySelector('.bottom-warning-close');
    closeBtn.addEventListener('click', () => {
        warning.classList.remove('show');
        setTimeout(() => {
            if (document.body.contains(warning)) {
                warning.remove();
            }
        }, 400);
    });
    
    // 10 saniye sonra otomatik kapat
    setTimeout(() => {
        if (document.body.contains(warning)) {
            warning.classList.remove('show');
            setTimeout(() => {
                if (document.body.contains(warning)) {
                    warning.remove();
                }
            }, 400);
        }
    }, 10000);
}

function checkUrlHashForAddressWarning() {
    const currentHash = window.location.hash;
    
    if (currentHash === '#addresses') {
        window.history.replaceState(null, null, window.location.pathname);
        
        const addressModal = document.getElementById('addressModal');
        if (addressModal) {
            openModal(addressModal);
            showSavedAddresses();
        }
        
        setTimeout(() => {
            showNotification('TgoYemek\'e sipariş vermek için kayıtlı bir adrese ihtiyacınız var!', 'error');
        }, 500);
    }
}

window.addEventListener('load', function() {
    checkUrlHashForAddressWarning();
});

window.addEventListener('hashchange', function() {
    checkUrlHashForAddressWarning();
});

// Adres Dışa Aktarma
function exportAddresses() {
    if (!savedAddresses || savedAddresses.length === 0) {
        showNotification("Dışa aktarılacak adres bulunamadı", 'warning');
        return;
    }
    
    const exportData = {
        addresses: savedAddresses,
        version: '1.0',
        exportDate: new Date().toISOString()
    };
    
    const jsonData = JSON.stringify(exportData, null, 2);
    const blob = new Blob([jsonData], { type: 'application/json' });
    
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `yekupon-adresler-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    
    setTimeout(() => {
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }, 100);
    
    showNotification(`${savedAddresses.length} adres başarıyla dışa aktarıldı`, 'success');
}

// Adres İçe Aktarma
function importAddresses(file) {
    
    if (!file) {
        showNotification("Dosya seçilmedi", 'error');
        return;
    }
    
    if (file.type !== 'application/json' && !file.name.endsWith('.json')) {
        showNotification("Yalnızca JSON dosyaları içe aktarılabilir", 'error');
        return;
    }
    
    const reader = new FileReader();
    
    reader.onload = function(e) {
        try {
            const importData = JSON.parse(e.target.result);
            
            if (!importData.addresses || !Array.isArray(importData.addresses)) {
                showNotification("Geçersiz adres dosyası formatı", 'error');
                return;
            }
            
            const existingAddressMap = new Map();
            savedAddresses.forEach(addr => {
                if (addr && addr.id) {
                    existingAddressMap.set(addr.id, addr);
                }
            });
            
            let importedCount = 0;
            let updatedCount = 0;
            
            importData.addresses.forEach(address => {
                if (!address || !address.id) return;
                
                if (existingAddressMap.has(address.id)) {
                    address.updatedAt = new Date().toISOString();
                    address.createdAt = existingAddressMap.get(address.id).createdAt || new Date().toISOString();
                    existingAddressMap.set(address.id, address);
                    updatedCount++;
                } else {
                    address.createdAt = address.createdAt || new Date().toISOString();
                    address.updatedAt = address.updatedAt || new Date().toISOString();
                    existingAddressMap.set(address.id, address);
                    importedCount++;
                }
            });
            
            savedAddresses = Array.from(existingAddressMap.values());
            
            // localStorage'a kaydet
            localStorage.setItem('yekupon_saved_addresses', JSON.stringify(savedAddresses));
            
            // Chrome storage'a kaydet
            if (typeof chrome !== 'undefined' && chrome.storage) {
                chrome.storage.local.set({
                    'yekupon_saved_addresses': savedAddresses
                }).then(() => {
                }).catch(err => {});
                
                // Aktif adresi de kaydet (ilk aktif olan veya ilk adres)
                const activeAddr = savedAddresses.find(a => a.isActive) || savedAddresses[0];
                if (activeAddr) {
                    chrome.storage.local.set({
                        'savedAddress': JSON.stringify(activeAddr)
                    }).catch(err => {});
                }
            }
            
            showNotification(`${importedCount} yeni adres içe aktarıldı, ${updatedCount} adres güncellendi`, 'success');
            
            // UI'ı güncelle
            loadSavedAddresses();
            showSavedAddresses();
            
        } catch (error) {
            showNotification("Dosya okunamadı veya geçersiz JSON formatı", 'error');
        }
    };
    
    reader.onerror = function() {
        showNotification("Dosya okuma hatası", 'error');
    };
    
    reader.readAsText(file);
}

// Export/Import butonları için event listener'lar
// Event delegation ile - butonlar modal içinde olsa bile çalışır
document.addEventListener('click', function(e) {
    // Export butonu
    if (e.target.closest('#exportAddressesButton')) {
        exportAddresses();
        return;
    }
    
    // Import butonu
    if (e.target.closest('#importAddressesButton')) {
        const fileInput = document.getElementById('addressImportInput');
        if (fileInput) {
            fileInput.click();
        }
        return;
    }
});

// Dosya seçildiğinde içe aktarma işlemini başlat (HTML'deki mevcut input için)
document.addEventListener('DOMContentLoaded', function() {
    const importInput = document.getElementById('addressImportInput');
    if (importInput) {
        importInput.addEventListener('change', function(e) {
            if (e.target.files && e.target.files.length > 0) {
                importAddresses(e.target.files[0]);
                e.target.value = ''; // Aynı dosyayı tekrar seçebilmek için temizle
            }
        });
    }
});

window.useAddress = useAddress;
window.editAddress = editAddress;
window.deleteAddress = deleteAddress;
window.confirmDeleteAddress = confirmDeleteAddress;
window.closeConfirmModal = closeConfirmModal;
window.handleTgoYemekLogin = handleTgoYemekLogin;
window.exportAddresses = exportAddresses;
window.importAddresses = importAddresses;
