/**
 * YeKupon - Migros Ödeme Sayfası Kupon Sistemi
 *
 * Migros ödeme sayfasında kupon giriş alanı, kupon listesi,
 * kart algılama ve kupon uygulama/kaldırma işlevlerini sağlar.
 *
 * Proxy akışı: inject (page) → content.js (bridge) → background.js (fetch)
 */
(function () {
  'use strict';

  if (!location.hostname.includes('migros.com.tr')) return;

  // ===== GLOBAL STATE =====
  window.ykMigrosCoupon = {
    validDiscountId: null,
    originalCouponId: null,
    couponUIContainer: null,
    originalPrice: null,
    fetchCallbacks: {},
    appliedCouponData: null
  };

  const PAGE_SOURCE = 'YK_MIGROS_COUPON_PAGE';
  const CONTENT_SOURCE = 'YK_MIGROS_COUPON_CONTENT';

  // =============================================
  // ===== CSS =====
  // =============================================
  const couponCSS = `
    /* Gereksiz elemanları gizle */
    .top-slot, .allow-new-wallet-content, fe-masterpass-link-user,
    .activate-wallet-wrapper, fe-card-provision-info, sm-mobile-app-popup,
    .popover.ng-star-inserted, #ai-wrapper, sm-money-discount-banner,
    .smart-life-wrapper, sm-download-hemen-app, sm-download-yemek-app,
    sm-download-app, sm-business-request-section, sm-download-application,
    .quick-filters {
      display: none !important;
    }

    #yk-coupon-box {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      background: #1a1f2e;
      border-radius: 10px;
      padding: 16px;
      margin: 12px 0;
      border: 1px solid #2d3548;
    }

    .yk-coupon-title {
      display: flex;
      align-items: center;
      gap: 7px;
      color: #d1d5db;
      font-size: 13.5px;
      font-weight: 600;
      margin-bottom: 10px;
    }

    .yk-coupon-form {
      display: flex;
      gap: 8px;
      margin-bottom: 10px;
    }
    .yk-coupon-form input {
      flex: 1;
      height: 38px;
      padding: 0 12px;
      border: 1px solid #3b4252;
      border-radius: 8px;
      background: #131720;
      color: #e5e7eb;
      font-size: 13.5px;
      outline: none;
    }
    .yk-coupon-form input::placeholder { color: #6b7280; }
    .yk-coupon-form input:focus { border-color: #6366f1; }
    .yk-coupon-form input:disabled { opacity: 0.4; cursor: not-allowed; }

    .yk-coupon-apply-btn {
      height: 38px;
      padding: 0 18px;
      border: none;
      border-radius: 8px;
      background: #6366f1;
      color: #fff;
      font-size: 13px;
      font-weight: 600;
      cursor: pointer;
      white-space: nowrap;
    }
    .yk-coupon-apply-btn:hover { background: #5558e6; }
    .yk-coupon-apply-btn:disabled { opacity: 0.4; cursor: not-allowed; }

    .yk-card-warning {
      display: none;
      background: rgba(251,191,36,0.08);
      border: 1px solid rgba(251,191,36,0.2);
      border-radius: 8px;
      padding: 8px 12px;
      margin-bottom: 10px;
      gap: 8px;
      align-items: center;
    }
    .yk-card-warning.yk-visible { display: flex; }
    .yk-card-warning-icon { font-size: 14px; }
    .yk-card-warning-text { color: #d4a017; font-size: 12px; font-weight: 500; }

    .yk-form-disabled { opacity: 0.4; pointer-events: none; }

    .yk-applied-coupon {
      display: none;
      background: rgba(34,197,94,0.08);
      border: 1px solid rgba(34,197,94,0.2);
      border-radius: 8px;
      padding: 10px 12px;
      margin-bottom: 10px;
      align-items: center;
      gap: 10px;
    }
    .yk-applied-coupon.yk-visible { display: flex; }
    .yk-applied-info { flex: 1; }
    .yk-applied-name { color: #4ade80; font-size: 12.5px; font-weight: 600; }
    .yk-applied-code { color: #86efac; font-size: 11px; margin-top: 2px; }
    .yk-applied-value { color: #4ade80; font-size: 14px; font-weight: 700; white-space: nowrap; }
    .yk-remove-btn {
      width: 26px; height: 26px;
      border: 1px solid rgba(34,197,94,0.2);
      background: transparent;
      color: #4ade80;
      border-radius: 6px;
      font-size: 14px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 0; line-height: 1;
    }
    .yk-remove-btn:hover { background: rgba(34,197,94,0.1); }

    .yk-coupons-heading {
      color: #6b7280;
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.4px;
      margin-bottom: 6px;
    }

    .yk-coupon-list {
      display: flex;
      flex-direction: column;
      gap: 4px;
      max-height: 220px;
      overflow-y: auto;
      scrollbar-width: thin;
      scrollbar-color: #3b4252 transparent;
    }
    .yk-coupon-list::-webkit-scrollbar { width: 4px; }
    .yk-coupon-list::-webkit-scrollbar-thumb { background: #3b4252; border-radius: 3px; }

    .yk-coupon-item {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 9px 10px;
      border-radius: 8px;
      background: rgba(255,255,255,0.03);
      border: 1px solid #2d3548;
      cursor: pointer;
    }
    .yk-coupon-item:hover { background: rgba(99,102,241,0.06); border-color: #3d4560; }
    .yk-coupon-item-info { flex: 1; min-width: 0; }
    .yk-coupon-item-name {
      color: #d1d5db;
      font-size: 12.5px;
      font-weight: 600;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .yk-coupon-item-desc {
      color: #6b7280;
      font-size: 11px;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      margin-top: 1px;
    }
    .yk-coupon-item-min {
      display: inline-block;
      color: #d4a017;
      font-size: 10px;
      font-weight: 600;
      margin-top: 3px;
    }
    .yk-coupon-item-value {
      color: #a5b4fc;
      font-size: 12.5px;
      font-weight: 700;
      white-space: nowrap;
      margin-left: 10px;
    }
    .yk-no-coupons {
      color: #4b5563;
      font-size: 12px;
      text-align: center;
      padding: 14px 0;
    }

    .yk-popup-overlay {
      position: fixed;
      inset: 0;
      z-index: 2147483647;
      background: rgba(0,0,0,0.55);
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 16px;
    }
    .yk-popup-card {
      background: #1a1f2e;
      border: 1px solid #2d3548;
      border-radius: 12px;
      padding: 20px;
      max-width: 380px;
      width: 100%;
    }
    .yk-popup-title { color: #e5e7eb; font-size: 15px; font-weight: 600; margin-bottom: 8px; }
    .yk-popup-msg { color: #9ca3af; font-size: 13px; line-height: 1.5; margin-bottom: 16px; }
    .yk-popup-btns { display: flex; gap: 8px; }
    .yk-popup-btn {
      flex: 1;
      height: 38px;
      border: none;
      border-radius: 8px;
      font-size: 13px;
      font-weight: 600;
      cursor: pointer;
    }
    .yk-popup-btn-primary { background: #6366f1; color: #fff; }
    .yk-popup-btn-primary:hover { background: #5558e6; }
    .yk-popup-btn-secondary { background: transparent; color: #9ca3af; border: 1px solid #2d3548; }
    .yk-popup-btn-secondary:hover { background: rgba(255,255,255,0.04); }

    .yk-spinner {
      display: inline-block;
      width: 14px; height: 14px;
      border: 2px solid rgba(255,255,255,0.2);
      border-top-color: #fff;
      border-radius: 50%;
      animation: ykSpin 0.6s linear infinite;
      vertical-align: middle;
      margin-right: 6px;
    }
    @keyframes ykSpin { to { transform: rotate(360deg); } }

    @media (max-width: 768px) {
      #yk-coupon-box { padding: 12px; }
      .yk-coupon-form input { height: 36px; font-size: 13px; }
      .yk-coupon-apply-btn { height: 36px; padding: 0 14px; }
    }
  `;

  // =============================================
  // ===== PROXY İLETİŞİM =====
  // =============================================
  function proxyFetch(url, method, headers, body) {
    return new Promise((resolve, reject) => {
      const requestId = Date.now().toString() + Math.random().toString(36).substring(2, 8);
      window.ykMigrosCoupon.fetchCallbacks[requestId] = (response) => {
        if (response && response.success) {
          resolve(response);
        } else {
          reject(new Error(response ? response.error : 'Proxy yanıtı alınamadı'));
        }
        delete window.ykMigrosCoupon.fetchCallbacks[requestId];
      };
      window.postMessage({
        source: PAGE_SOURCE,
        action: 'proxyRequest',
        requestId,
        url,
        method: method || 'GET',
        headers: headers || {},
        body: body || null
      }, '*');

      // Timeout 15s
      setTimeout(() => {
        if (window.ykMigrosCoupon.fetchCallbacks[requestId]) {
          delete window.ykMigrosCoupon.fetchCallbacks[requestId];
          reject(new Error('İstek zaman aşımına uğradı'));
        }
      }, 15000);
    });
  }

  // Proxy yanıtlarını dinle
  window.addEventListener('message', (event) => {
    if (event.source !== window || !event.data || event.data.source !== CONTENT_SOURCE) return;
    if (event.data.action !== 'proxyResponse') return;
    const cb = window.ykMigrosCoupon.fetchCallbacks[event.data.requestId];
    if (cb) cb(event.data.response);
  });

  // =============================================
  // ===== YARDIMCI FONKSİYONLAR =====
  // =============================================
  function detectService() {
    const main = document.querySelector('main');
    if (!main) return 'sanalmarket';
    if (main.classList.contains('yemek')) return 'yemek';
    if (main.classList.contains('hemen')) return 'hemen';
    return 'sanalmarket';
  }

  function getApiBase(service) {
    switch (service) {
      case 'yemek': return '/rest/yemek';
      case 'hemen': return '/rest/hemen';
      default: return '/rest';
    }
  }

  function getCheckoutId() {
    const m = location.pathname.match(/\/odeme(?:\/[\w-]+)*\/(\d+)/);
    return m ? m[1] : null;
  }

  function reidParam() {
    return Date.now().toString() + Math.floor(Math.random() * 1000000).toString().padStart(6, '0');
  }

  // =============================================
  // ===== KART ALGILAMA =====
  // =============================================
  const cardSelectors = {
    number: [
      'input[name="cardNumber"]', 'input[data-testid="card-number"]',
      'input[placeholder*="Kart Numarası"]', 'input[placeholder*="kart numarası"]',
      'input[formcontrolname="cardNumber"]', '.card-number input',
      'input[id*="cardNumber"]', 'input[name*="cardNo"]', 'input[autocomplete="cc-number"]'
    ],
    expiry: [
      'input[name="expiry"]', 'input[name="expiryDate"]',
      'input[data-testid="expiry-date"]', 'input[placeholder*="AA/YY"]',
      'input[placeholder*="ay/yıl"]', 'input[formcontrolname="expiryDate"]',
      '.expiry-date input', 'input[id*="expiry"]', 'input[autocomplete="cc-exp"]'
    ],
    cvv: [
      'input[name="cvv"]', 'input[name="cvc"]',
      'input[data-testid="cvv"]', 'input[placeholder*="CVV"]',
      'input[placeholder*="CVC"]', 'input[formcontrolname="cvv"]',
      '.cvv input', 'input[id*="cvv"]', 'input[autocomplete="cc-csc"]'
    ]
  };

  function findInput(selectors) {
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el) return el;
    }
    return null;
  }

  function isCardInfoFilled() {
    const cardNum = findInput(cardSelectors.number);
    const expiry = findInput(cardSelectors.expiry);
    const cvv = findInput(cardSelectors.cvv);

    if (cardNum && expiry && cvv) {
      const num = (cardNum.value || '').replace(/\s/g, '');
      return num.length >= 15 && (expiry.value || '').length >= 4 && (cvv.value || '').length >= 3;
    }

    // Fallback - tüm payment inputlarını tara
    const allInputs = document.querySelectorAll(
      'fe-line-checkout-payment input, sm-delivery-payment input, .payment-method input, .credit-card-form input'
    );
    let filledCount = 0;
    allInputs.forEach(inp => {
      if ((inp.value || '').trim().length >= 3) filledCount++;
    });
    return filledCount >= 3;
  }

  function updateCardState() {
    const box = document.getElementById('yk-coupon-box');
    if (!box) return;

    const warn = box.querySelector('.yk-card-warning');
    const form = box.querySelector('.yk-coupon-form');
    const list = box.querySelector('.yk-coupon-list');
    const filled = isCardInfoFilled();

    if (filled) {
      warn && warn.classList.remove('yk-visible');
      form && form.classList.remove('yk-form-disabled');
      list && list.classList.remove('yk-form-disabled');
      const inp = box.querySelector('.yk-coupon-form input');
      const btn = box.querySelector('.yk-coupon-apply-btn');
      if (inp) inp.disabled = false;
      if (btn) btn.disabled = false;
    } else {
      warn && warn.classList.add('yk-visible');
      form && form.classList.add('yk-form-disabled');
      list && list.classList.add('yk-form-disabled');
      const inp = box.querySelector('.yk-coupon-form input');
      const btn = box.querySelector('.yk-coupon-apply-btn');
      if (inp) inp.disabled = true;
      if (btn) btn.disabled = true;
    }
  }

  let cardObserver = null;
  function startCardFieldObserver() {
    if (cardObserver) return;
    let debounce = null;
    const handler = () => {
      clearTimeout(debounce);
      debounce = setTimeout(updateCardState, 300);
    };
    document.addEventListener('input', handler, true);
    document.addEventListener('change', handler, true);

    cardObserver = new MutationObserver(() => {
      clearTimeout(debounce);
      debounce = setTimeout(updateCardState, 500);
    });
    const target = document.querySelector('fe-line-checkout-payment, sm-delivery-payment, .payment-method') || document.body;
    cardObserver.observe(target, { childList: true, subtree: true });

    setInterval(updateCardState, 2000);
  }

  // =============================================
  // ===== KUPON API =====
  // =============================================
  async function fetchCoupons(service) {
    try {
      const checkoutId = getCheckoutId();
      if (!checkoutId) { console.error('[YeKupon] Migros checkoutId bulunamadı'); return []; }

      const reid = reidParam();
      const base = getApiBase(service);
      const endpoint = `${base}/checkouts/${checkoutId}/discounts/applicable?reid=${reid}`;

      const resp = await proxyFetch(
        `https://rest.migros.com.tr${endpoint}`,
        'POST',
        { 'accept': 'application/json', 'content-type': 'application/json', 'x-forwarded-rest': 'true' },
        JSON.stringify({ bagSelected: true })
      );

      const data = typeof resp.data === 'string' ? JSON.parse(resp.data) : resp.data;
      let coupons = [];
      if (data && data.successful && Array.isArray(data.data)) coupons = data.data;
      else if (data && Array.isArray(data.discounts)) coupons = data.discounts;
      else if (data && Array.isArray(data.availableDiscounts)) coupons = data.availableDiscounts;
      else if (data && Array.isArray(data.discountResults)) coupons = data.discountResults;
      else if (data && data.data && Array.isArray(data.data.availableDiscounts)) coupons = data.data.availableDiscounts;

      const now = Date.now();
      return coupons.filter(c => {
        if (!c.id && !c.discountId && !c.name) return false;
        if (c.beginDate && now < new Date(c.beginDate).getTime()) return false;
        if (c.endDate && now > new Date(c.endDate).getTime()) return false;
        return true;
      });
    } catch (err) {
      console.error('[YeKupon] Migros kupon listesi hatası:', err);
      return [];
    }
  }

  async function validateCoupon(service, couponCode, checkoutId, couponId) {
    const base = getApiBase(service);
    const url = `https://rest.migros.com.tr${base}/checkouts/${checkoutId}/discounts/checks`;

    const body = {
      campaignType: 'COUPON',
      bagSelected: true,
      deliveryProvider: 'NONE',
      paymentType: 'CREDIT_CARD'
    };
    if (couponId) body.discountId = couponId;
    else body.couponCode = couponCode;

    const resp = await proxyFetch(url, 'POST',
      { 'accept': 'application/json', 'content-type': 'application/json', 'x-forwarded-rest': 'true' },
      JSON.stringify(body)
    );

    const data = typeof resp.data === 'string' ? JSON.parse(resp.data) : resp.data;
    return data;
  }

  async function resolveConflict(service, checkoutId, discountId) {
    const base = getApiBase(service);
    const reid = reidParam();
    const url = `https://rest.migros.com.tr${base}/checkouts/${checkoutId}/discounts/resolve-conflict?reid=${reid}`;

    const body = {
      campaignType: 'COUPON',
      bagSelected: true,
      deliveryProvider: 'NONE',
      paymentType: 'CREDIT_CARD',
      discountId: discountId
    };

    const resp = await proxyFetch(url, 'POST',
      { 'accept': 'application/json', 'content-type': 'application/json', 'x-forwarded-rest': 'true' },
      JSON.stringify(body)
    );

    return typeof resp.data === 'string' ? JSON.parse(resp.data) : resp.data;
  }

  // =============================================
  // ===== KUPON UYGULAMA =====
  // =============================================
  async function applyCouponAction(couponCode, couponId) {
    const checkoutId = getCheckoutId();
    if (!checkoutId) { showPopup('Hata', 'Sipariş ID bulunamadı. Sayfanın doğru yüklendiğinden emin olun.', 'error'); return; }
    if (!isCardInfoFilled()) { showPopup('Kart Bilgisi Gerekli', 'Kuponu uygulayabilmek için önce kart bilgilerinizi eksiksiz girin.', 'warning'); return; }

    const btn = document.querySelector('.yk-coupon-apply-btn');
    if (btn) { btn.disabled = true; btn.innerHTML = '<span class="yk-spinner"></span>Uygulanıyor...'; }

    try {
      const service = detectService();
      const data = await validateCoupon(service, couponCode, checkoutId, couponId);

      if (!data.successful) {
        const msg = data.errorDetail?.detailMessage || data.errorDetail?.message || data.message || 'Kupon uygulanamadı.';
        showPopup('Kupon Hatası', msg, 'error');
        return;
      }

      const resultData = data.data || data;

      // Çakışma kontrolü
      if (resultData.hasConflict === true) {
        const userChoice = await showConflictPopup(resultData);
        if (userChoice === 'keep') {
          clearAppliedCouponUI();
          return;
        }
        const resolveData = await resolveConflict(service, checkoutId, resultData.discountId);
        if (resolveData.successful || resolveData.data) {
          const dr = resolveData.data?.discountResult || resolveData.discountResult || resolveData.data || resolveData;
          handleSuccessfulApply(dr, couponCode, couponId);
        } else {
          showPopup('Hata', resolveData.errorDetail?.detailMessage || 'Çakışma çözülemedi.', 'error');
        }
        return;
      }

      // Koşul hatası kontrolü
      const actionDetails = resultData.actionDetails;
      if (actionDetails && actionDetails.actionTitle === 'Kupon Uygulanamadı') {
        const msgs = actionDetails.actionMessages?.join('\n') || 'Kupon koşulları sağlanmıyor.';
        showPopup('Kupon Uygulanamadı', msgs, 'warning');
        return;
      }

      // Başarılı
      const discountResult = resultData.discountResult || resultData;
      handleSuccessfulApply(discountResult, couponCode, couponId);

    } catch (err) {
      console.error('[YeKupon] Kupon uygulama hatası:', err);
      showPopup('Hata', err.message || 'Beklenmeyen bir hata oluştu.', 'error');
    } finally {
      if (btn) { btn.disabled = false; btn.textContent = 'Uygula'; }
    }
  }

  function handleSuccessfulApply(discountResult, couponCode, couponId) {
    const name = discountResult.name || discountResult.discountName || couponCode || 'Kupon';
    const value = discountResult.discountValue || discountResult.discountAmount || discountResult.discount || 0;
    const displayValue = value >= 100 ? (value / 100) : value;
    const id = discountResult.id || discountResult.discountId || couponId;

    window.ykMigrosCoupon.validDiscountId = id;
    window.ykMigrosCoupon.originalCouponId = couponId;
    window.ykMigrosCoupon.appliedCouponData = { name, value: displayValue, code: couponCode, id };

    const applied = document.querySelector('.yk-applied-coupon');
    if (applied) {
      applied.querySelector('.yk-applied-name').textContent = 'Kupon Uygulandı: ' + name;
      applied.querySelector('.yk-applied-code').textContent = couponCode || ('ID: ' + id);
      applied.querySelector('.yk-applied-value').textContent = '-' + displayValue + ' TL';
      applied.classList.add('yk-visible');
    }

    updatePriceSummary(value);
    showPopup('Başarılı', 'Kupon başarıyla uygulandı!', 'success');
  }

  // =============================================
  // ===== FİYAT ÖZETİ GÜNCELLEME =====
  // =============================================
  function updatePriceSummary(discountValue) {
    const displayVal = discountValue >= 100 ? (discountValue / 100) : discountValue;

    // Desktop
    const desktopSummary = document.querySelector('fe-line-checkout-price-summary .summary-content')
      || document.querySelector('fe-line-checkout-summary-desktop fe-line-checkout-price-summary .summary');
    if (desktopSummary) {
      const existing = document.getElementById('yk-discount-row');
      if (existing) existing.remove();

      const row = document.createElement('div');
      row.id = 'yk-discount-row';
      row.className = 'discount';
      row.style.cssText = 'display:flex;justify-content:space-between;align-items:center;padding:4px 0;color:#22c55e;font-weight:600;font-size:14px;';
      row.innerHTML = '<span>Kupon İndirimi</span><span>-' + displayVal.toFixed(2) + ' TL</span>';

      const totalEl = desktopSummary.querySelector('.subtitle-1.text-align-right')
        || desktopSummary.querySelector('[class*="total"]');
      if (totalEl) {
        totalEl.parentElement.insertBefore(row, totalEl);
        const currentText = totalEl.textContent.replace(/[^\d.,]/g, '').replace(',', '.');
        const current = parseFloat(currentText);
        if (!isNaN(current)) {
          if (!window.ykMigrosCoupon.originalPrice) window.ykMigrosCoupon.originalPrice = current;
          const newTotal = window.ykMigrosCoupon.originalPrice - displayVal;
          totalEl.textContent = Math.max(0, newTotal).toFixed(2) + ' TL';
        }
      }
    }

    // Mobile
    const mobileContent = document.querySelector('.checkout-summary-mobile__content');
    if (mobileContent) {
      const existingM = document.getElementById('yk-discount-row-m');
      if (existingM) existingM.remove();

      const rowM = document.createElement('div');
      rowM.id = 'yk-discount-row-m';
      rowM.style.cssText = 'display:flex;justify-content:space-between;align-items:center;padding:4px 0;color:#22c55e;font-weight:600;font-size:13px;';
      rowM.innerHTML = '<span>Kupon İndirimi</span><span>-' + displayVal.toFixed(2) + ' TL</span>';

      const revEl = mobileContent.querySelector('.revenue');
      if (revEl) revEl.parentElement.insertBefore(rowM, revEl);
    }
  }

  function clearAppliedCouponUI() {
    const applied = document.querySelector('.yk-applied-coupon');
    if (applied) applied.classList.remove('yk-visible');

    const dr = document.getElementById('yk-discount-row');
    if (dr) dr.remove();
    const drm = document.getElementById('yk-discount-row-m');
    if (drm) drm.remove();

    if (window.ykMigrosCoupon.originalPrice !== null) {
      const totalEls = document.querySelectorAll(
        'fe-line-checkout-price-summary .summary .subtitle-1.text-align-right, .checkout-summary-mobile__content .revenue'
      );
      totalEls.forEach(el => {
        el.textContent = window.ykMigrosCoupon.originalPrice.toFixed(2) + ' TL';
      });
    }

    window.ykMigrosCoupon.validDiscountId = null;
    window.ykMigrosCoupon.originalCouponId = null;
    window.ykMigrosCoupon.appliedCouponData = null;
    window.ykMigrosCoupon.originalPrice = null;
  }

  // =============================================
  // ===== POPUP SİSTEMİ =====
  // =============================================
  function showPopup(title, message, type) {
    const existing = document.querySelector('.yk-popup-overlay');
    if (existing) existing.remove();

    const colors = { error: '#ef4444', success: '#22c55e', warning: '#f59e0b' };
    const icons = { error: '✕', success: '✓', warning: '!' };

    const overlay = document.createElement('div');
    overlay.className = 'yk-popup-overlay';
    overlay.innerHTML =
      '<div class="yk-popup-card">' +
        '<div style="width:40px;height:40px;border-radius:12px;background:' + (colors[type] || colors.error) + '22;display:flex;align-items:center;justify-content:center;margin-bottom:14px;">' +
          '<span style="color:' + (colors[type] || colors.error) + ';font-size:18px;font-weight:800;">' + (icons[type] || '!') + '</span>' +
        '</div>' +
        '<div class="yk-popup-title">' + title + '</div>' +
        '<div class="yk-popup-msg">' + message + '</div>' +
        '<div class="yk-popup-btns">' +
          '<button class="yk-popup-btn yk-popup-btn-primary" id="yk-popup-ok">Tamam</button>' +
        '</div>' +
      '</div>';
    document.body.appendChild(overlay);

    overlay.querySelector('#yk-popup-ok').addEventListener('click', () => overlay.remove());
    overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
  }

  function showConflictPopup(resultData) {
    return new Promise((resolve) => {
      const existing = document.querySelector('.yk-popup-overlay');
      if (existing) existing.remove();

      const overlay = document.createElement('div');
      overlay.className = 'yk-popup-overlay';
      overlay.innerHTML =
        '<div class="yk-popup-card">' +
          '<div style="width:40px;height:40px;border-radius:12px;background:rgba(251,191,36,0.15);display:flex;align-items:center;justify-content:center;margin-bottom:14px;">' +
            '<span style="color:#f59e0b;font-size:18px;font-weight:800;">⚡</span>' +
          '</div>' +
          '<div class="yk-popup-title">İndirim Çakışması</div>' +
          '<div class="yk-popup-msg">Yeni kupon uygulamak için mevcut indirimi kaldırmanız gerekiyor.</div>' +
          '<div class="yk-popup-btns">' +
            '<button class="yk-popup-btn yk-popup-btn-secondary" id="yk-conflict-keep">Mevcut İndirimi Koru</button>' +
            '<button class="yk-popup-btn yk-popup-btn-primary" id="yk-conflict-apply">Yeni Kuponu Uygula</button>' +
          '</div>' +
        '</div>';
      document.body.appendChild(overlay);

      overlay.querySelector('#yk-conflict-keep').addEventListener('click', () => { overlay.remove(); resolve('keep'); });
      overlay.querySelector('#yk-conflict-apply').addEventListener('click', () => { overlay.remove(); resolve('apply'); });
    });
  }

  // =============================================
  // ===== ANA UI OLUŞTURMA =====
  // =============================================
  async function buildCouponUI() {
    if (document.getElementById('yk-coupon-box')) return;

    // Stil ekle
    if (!document.getElementById('yk-coupon-css')) {
      const style = document.createElement('style');
      style.id = 'yk-coupon-css';
      style.textContent = couponCSS;
      (document.head || document.documentElement).appendChild(style);
    }

    const service = detectService();
    const coupons = await fetchCoupons(service);

    const box = document.createElement('div');
    box.id = 'yk-coupon-box';

    // Başlık
    let html =
      '<div class="yk-coupon-title">' +
        '🏷️ Kupon Uygulama' +
      '</div>';

    // Input + Buton
    html +=
      '<div class="yk-coupon-form">' +
        '<input type="text" placeholder="Kupon kodunu girin" id="yk-coupon-input" />' +
        '<button class="yk-coupon-apply-btn" id="yk-coupon-apply-btn">Uygula</button>' +
      '</div>';

    // Kart uyarısı
    html +=
      '<div class="yk-card-warning">' +
        '<span class="yk-card-warning-icon">⚠️</span>' +
        '<span class="yk-card-warning-text">Kupon uygulayabilmek için önce kart bilgilerinizi eksiksiz girin.</span>' +
      '</div>';

    // Uygulanan kupon (gizli)
    html +=
      '<div class="yk-applied-coupon">' +
        '<div class="yk-applied-info">' +
          '<div class="yk-applied-name"></div>' +
          '<div class="yk-applied-code"></div>' +
        '</div>' +
        '<div class="yk-applied-value"></div>' +
        '<button class="yk-remove-btn" title="Kuponu kaldır">✕</button>' +
      '</div>';

    // Kupon listesi
    if (coupons.length > 0) {
      html += '<div class="yk-coupons-heading">Kullanılabilir Kuponlar</div><div class="yk-coupon-list">';
      for (const c of coupons) {
        const name = c.name || c.discountName || 'Kupon';
        const desc = c.shortDescription || c.userDescription || c.description || '';
        const val = c.discountValue || c.discountAmount || 0;
        const displayVal = val >= 100 ? (val / 100) : val;
        const id = c.id || c.discountId || '';
        const code = c.couponCode || '';
        const minRev = c.cartMinimumRevenue;

        html +=
          '<div class="yk-coupon-item" data-coupon-id="' + id + '" data-coupon-code="' + code + '">' +
            '<div class="yk-coupon-item-info">' +
              '<div class="yk-coupon-item-name">' + name + '</div>' +
              (desc ? '<div class="yk-coupon-item-desc">' + desc + '</div>' : '') +
              (minRev ? '<div class="yk-coupon-item-min">Min: ' + minRev + ' TL</div>' : '') +
            '</div>' +
            '<div class="yk-coupon-item-value">' + displayVal + ' TL</div>' +
          '</div>';
      }
      html += '</div>';
    } else {
      html += '<div class="yk-no-coupons">Kullanılabilir kupon bulunamadı.</div>';
    }

    box.innerHTML = html;

    // DOM'a ekle - ödeme özeti yanına
    const desktopTarget = document.querySelector(
      'sm-delivery-payment .side-container fe-line-checkout-summary-desktop'
    );
    const mobileTarget = document.querySelector(
      'sm-delivery-payment .checkout-container fe-line-checkout-price-summary.mobile-only'
    );

    if (mobileTarget) {
      mobileTarget.parentNode.insertBefore(box, mobileTarget);
    } else if (desktopTarget) {
      desktopTarget.parentNode.insertBefore(box, desktopTarget);
    } else {
      const fallback = document.querySelector('fe-line-checkout-price-summary, .checkout-container, sm-delivery-payment');
      if (fallback) fallback.parentNode.insertBefore(box, fallback);
      else document.body.appendChild(box);
    }

    window.ykMigrosCoupon.couponUIContainer = box;

    // Event listeners
    const applyBtn = box.querySelector('#yk-coupon-apply-btn');
    const input = box.querySelector('#yk-coupon-input');

    applyBtn.addEventListener('click', () => {
      const code = input.value.trim();
      if (!code) return;
      applyCouponAction(code, null);
    });

    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        const code = input.value.trim();
        if (!code) return;
        applyCouponAction(code, null);
      }
    });

    // Kupon listesinde tıklama
    box.querySelectorAll('.yk-coupon-item').forEach(item => {
      item.addEventListener('click', () => {
        const code = item.getAttribute('data-coupon-code');
        const id = item.getAttribute('data-coupon-id');
        applyCouponAction(code || null, id || null);
      });
    });

    // Kuponu kaldır butonu
    box.querySelector('.yk-remove-btn').addEventListener('click', () => clearAppliedCouponUI());

    // Kart durumu kontrolü başlat
    setTimeout(() => {
      updateCardState();
      startCardFieldObserver();
    }, 500);

    // Eğer daha önce uygulanan kupon varsa göster
    if (window.ykMigrosCoupon.appliedCouponData) {
      const d = window.ykMigrosCoupon.appliedCouponData;
      handleSuccessfulApply({ name: d.name, discountValue: d.value * 100, id: d.id }, d.code, d.id);
    }
  }

  // =============================================
  // ===== SAYFA İZLEME =====
  // =============================================
  let lastUrl = location.href;

  function isCheckoutPage() {
    return location.pathname.includes('/odeme/');
  }

  function checkPage() {
    if (lastUrl !== location.href) {
      lastUrl = location.href;
      if (!isCheckoutPage()) {
        clearAppliedCouponUI();
        const box = document.getElementById('yk-coupon-box');
        if (box) box.remove();
        return;
      }
    }

    if (!isCheckoutPage()) return;

    const summaryPresent = document.querySelector('fe-line-checkout-price-summary, fe-line-checkout-summary-desktop');
    if (summaryPresent && !document.getElementById('yk-coupon-box')) {
      buildCouponUI();
    }
  }

  // İlk çalıştırma
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => setTimeout(checkPage, 1000));
  } else {
    setTimeout(checkPage, 1000);
  }

  setTimeout(checkPage, 2000);

  // MutationObserver
  const pageObserver = new MutationObserver((mutations) => {
    let shouldCheck = lastUrl !== location.href;

    if (isCheckoutPage() && !document.getElementById('yk-coupon-box')) {
      for (const mutation of mutations) {
        if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
          for (const node of mutation.addedNodes) {
            if (node.nodeType === Node.ELEMENT_NODE) {
              if (
                (node.matches && (
                  node.matches('fe-line-checkout-price-summary') ||
                  node.matches('fe-line-checkout-summary-desktop')
                )) ||
                (node.querySelector && (
                  node.querySelector('fe-line-checkout-price-summary') ||
                  node.querySelector('fe-line-checkout-summary-desktop')
                ))
              ) {
                shouldCheck = true;
                break;
              }
            }
          }
          if (shouldCheck) break;
        }
      }
    }

    if (shouldCheck) {
      clearTimeout(pageObserver._debounce);
      pageObserver._debounce = setTimeout(checkPage, 300);
    }
  });

  pageObserver.observe(document.documentElement, { childList: true, subtree: true });

  setInterval(() => {
    if (lastUrl !== location.href) checkPage();
    if (isCheckoutPage() && !document.getElementById('yk-coupon-box')) checkPage();
  }, 3000);

})();
