const JavaScriptObfuscator = require('javascript-obfuscator');
const fs = require('fs');
const path = require('path');

// Kaynak ve hedef klasörler
const sourceDir = __dirname;
const outputDir = path.join(__dirname, 'hash');

// Obfuscation ayarları (Chrome extension için optimize)
const obfuscatorOptions = {
    compact: true,
    controlFlowFlattening: true,
    controlFlowFlatteningThreshold: 0.5,
    deadCodeInjection: true,
    deadCodeInjectionThreshold: 0.2,
    debugProtection: false, // Chrome extension'da sorun çıkarabilir
    disableConsoleOutput: false, // Debug için console'u açık bırak
    identifierNamesGenerator: 'hexadecimal',
    log: false,
    numbersToExpressions: true,
    renameGlobals: false, // Chrome API'leri bozulmasın
    selfDefending: false, // Extension'da sorun çıkarabilir
    simplify: true,
    splitStrings: true,
    splitStringsChunkLength: 10,
    stringArray: true,
    stringArrayCallsTransform: true,
    stringArrayEncoding: ['base64'],
    stringArrayIndexShift: true,
    stringArrayRotate: true,
    stringArrayShuffle: true,
    stringArrayWrappersCount: 2,
    stringArrayWrappersChainedCalls: true,
    stringArrayWrappersParametersMaxCount: 4,
    stringArrayWrappersType: 'function',
    stringArrayThreshold: 0.75,
    transformObjectKeys: true,
    unicodeEscapeSequence: false
};

// Obfuscate edilecek JS dosyaları (ana dizindeki)
const jsFiles = [
    'background.js',
    'fullscreen.js',
    'content.js',
    'inject.js',
    'popup.js',
    'migros-coupon-inject.js',
    'generate-rsig.js',
    'earlyBlocker.js'
];

// Kopyalanacak diğer dosyalar (obfuscate edilmeyecek)
const copyFiles = [
    'manifest.json',
    'fullscreen.html',
    'crypto-js.min.js'
];

// Kopyalanacak klasörler
const copyFolders = [
    'icons',
    'src'
];

// Klasör oluştur (recursive)
function ensureDir(dir) {
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }
}

// Dosya kopyala
function copyFile(src, dest) {
    ensureDir(path.dirname(dest));
    fs.copyFileSync(src, dest);
}

// Klasör kopyala (recursive)
function copyFolder(src, dest) {
    if (!fs.existsSync(src)) {
        console.log(`⚠️ Klasör bulunamadı: ${src}`);
        return;
    }
    
    ensureDir(dest);
    
    const items = fs.readdirSync(src);
    for (const item of items) {
        const srcPath = path.join(src, item);
        const destPath = path.join(dest, item);
        
        if (fs.statSync(srcPath).isDirectory()) {
            copyFolder(srcPath, destPath);
        } else if (item.endsWith('.js')) {
            // JS dosyalarını obfuscate et
            obfuscateFile(srcPath, destPath);
        } else {
            // Diğer dosyaları kopyala
            copyFile(srcPath, destPath);
        }
    }
}

// JS dosyasını obfuscate et
function obfuscateFile(srcPath, destPath) {
    try {
        const code = fs.readFileSync(srcPath, 'utf8');
        const obfuscatedCode = JavaScriptObfuscator.obfuscate(code, obfuscatorOptions).getObfuscatedCode();
        
        ensureDir(path.dirname(destPath));
        fs.writeFileSync(destPath, obfuscatedCode);
        console.log(`✅ Obfuscated: ${path.relative(sourceDir, srcPath)}`);
    } catch (error) {
        console.error(`❌ Hata (${path.relative(sourceDir, srcPath)}): ${error.message}`);
        // Hata olursa orijinali kopyala
        copyFile(srcPath, destPath);
    }
}

// Ana işlem
async function main() {
    console.log('🔐 YeKupon Obfuscator Başlatılıyor...\n');
    
    // Hash klasörünü temizle
    if (fs.existsSync(outputDir)) {
        fs.rmSync(outputDir, { recursive: true });
    }
    ensureDir(outputDir);
    
    // Ana JS dosyalarını obfuscate et
    console.log('📦 Ana JS dosyaları işleniyor...');
    for (const file of jsFiles) {
        const srcPath = path.join(sourceDir, file);
        const destPath = path.join(outputDir, file);
        
        if (fs.existsSync(srcPath)) {
            obfuscateFile(srcPath, destPath);
        } else {
            console.log(`⚠️ Dosya bulunamadı: ${file}`);
        }
    }
    
    // Diğer dosyaları kopyala
    console.log('\n📄 Diğer dosyalar kopyalanıyor...');
    for (const file of copyFiles) {
        const srcPath = path.join(sourceDir, file);
        const destPath = path.join(outputDir, file);
        
        if (fs.existsSync(srcPath)) {
            copyFile(srcPath, destPath);
            console.log(`📋 Kopyalandı: ${file}`);
        }
    }
    
    // Klasörleri kopyala (içindeki JS'leri obfuscate ederek)
    console.log('\n📁 Klasörler işleniyor...');
    for (const folder of copyFolders) {
        const srcPath = path.join(sourceDir, folder);
        const destPath = path.join(outputDir, folder);
        
        if (fs.existsSync(srcPath)) {
            console.log(`📂 İşleniyor: ${folder}/`);
            copyFolder(srcPath, destPath);
        }
    }
    
    console.log('\n✨ Obfuscation tamamlandı!');
    console.log(`📍 Çıktı klasörü: ${outputDir}`);
}

main().catch(console.error);
