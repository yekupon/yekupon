importScripts('./crypto-js.min.js');
importScripts('./generate-rsig.js');

chrome.action.onClicked.addListener(function() {
    chrome.tabs.create({ url: 'fullscreen.html' });
});

// Global state for voucher map and checkout tracking
let globalVoucherMap = {};
let isCheckoutInProgress = false;

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// ===== TRENDYOL MOBİL API HEADER SPOOFING =====
// RAKİP ANALİZİ: Sadece belirli endpoint'lere mobil header uygulanır
// Geniş ||api.tgoapis.com filtresi adres API'lerini bozuyordu (hata 4001)
// Rakip gibi sadece kupon/sepet/adres-servis endpoint'leri hedeflenir
async function setupTrendyolMobileHeaders() {
    try {
        // Önce mevcut kuralları temizle
        const existingRules = await chrome.declarativeNetRequest.getSessionRules();
        const tyRuleIds = existingRules
            .filter(rule => rule.id >= 9900 && rule.id <= 9910)
            .map(rule => rule.id);
        
        if (tyRuleIds.length > 0) {
            await chrome.declarativeNetRequest.updateSessionRules({
                removeRuleIds: tyRuleIds
            });
        }
        
        // RAKİP ANALİZİ: Rakip sadece belirli endpoint'leri hedefliyor
        // Geniş api.tgoapis.com filtresi adres/şehir/ilçe/mahalle API'lerini de etkiliyor → hata 4001
        const mobileHeaderActions = [
            { header: "sec-ch-ua", operation: "remove" },
            { header: "sec-ch-ua-mobile", operation: "remove" },
            { header: "sec-ch-ua-platform", operation: "remove" },
            { header: "Sec-Fetch-Dest", operation: "remove" },
            { header: "Sec-Fetch-Mode", operation: "remove" },
            { header: "Sec-Fetch-Site", operation: "remove" },
            { header: "Sec-Fetch-Storage-Access", operation: "remove" },
            { header: "Referer", operation: "remove" },
            { header: "Origin", operation: "remove" },
            { header: "Accept", operation: "set", value: "*/*" },
            { header: "User-Agent", operation: "set", value: "Dalvik/2.1.0 (Linux; U; Android 9; 2203121C Build/PQ3A.190605.09201023) TrendyolGo/1.45.4.164" }
        ];
        
        await chrome.declarativeNetRequest.updateSessionRules({
            addRules: [
                {
                    id: 9901,
                    priority: 10,
                    action: { type: "modifyHeaders", requestHeaders: mobileHeaderActions },
                    condition: {
                        urlFilter: "api.tgoapis.com/localcommerce-member-zeususer-service/addresses",
                        resourceTypes: ["xmlhttprequest"]
                    }
                },
                {
                    id: 9902,
                    priority: 10,
                    action: { type: "modifyHeaders", requestHeaders: mobileHeaderActions },
                    condition: {
                        urlFilter: "api.tgoapis.com/meal-mmcheckout-sfxcarts-santral/*",
                        resourceTypes: ["xmlhttprequest"]
                    }
                },
                {
                    id: 9903,
                    priority: 10,
                    action: { type: "modifyHeaders", requestHeaders: mobileHeaderActions },
                    condition: {
                        urlFilter: "api.tgoapis.com/meal-mmcheckout-sfxcarts-santral/carts",
                        resourceTypes: ["xmlhttprequest"]
                    }
                },
                {
                    id: 9904,
                    priority: 10,
                    action: { type: "modifyHeaders", requestHeaders: mobileHeaderActions },
                    condition: {
                        urlFilter: "api.tgoapis.com/meal-mmcheckout-sfxcarts-santral/carts/code-promotions",
                        resourceTypes: ["xmlhttprequest"]
                    }
                },
                {
                    id: 9905,
                    priority: 10,
                    action: { type: "modifyHeaders", requestHeaders: mobileHeaderActions },
                    condition: {
                        urlFilter: "api.tgoapis.com/web-checkout-apicheckout-santral/carts/code-promotions",
                        resourceTypes: ["xmlhttprequest"]
                    }
                },
                // Web adres endpoint'i - Chrome extension Origin'ini tgoyemek.com'a çevir
                // Chrome service worker'dan fetch yapınca Origin: chrome-extension://... oluyor
                // Bu kural sayesinde istek tgoyemek.com sitesinden geliyormuş gibi görünür
                {
                    id: 9906,
                    priority: 10,
                    action: {
                        type: "modifyHeaders",
                        requestHeaders: [
                            { header: "Origin", operation: "set", value: "https://tgoyemek.com" },
                            { header: "Sec-Fetch-Site", operation: "set", value: "cross-site" },
                            { header: "Sec-Fetch-Mode", operation: "set", value: "cors" },
                            { header: "Sec-Fetch-Dest", operation: "set", value: "empty" },
                            { header: "Sec-Fetch-Storage-Access", operation: "remove" },
                            { header: "sec-ch-ua-platform", operation: "set", value: "\"Windows\"" },
                            { header: "sec-ch-ua", operation: "set", value: "\"Not)A;Brand\";v=\"8\", \"Chromium\";v=\"138\", \"Microsoft Edge\";v=\"138\"" },
                            { header: "sec-ch-ua-mobile", operation: "set", value: "?0" },
                            { header: "User-Agent", operation: "set", value: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0" },
                            { header: "accept-language", operation: "set", value: "tr,en;q=0.9,en-GB;q=0.8,en-US;q=0.7" }
                        ]
                    },
                    condition: {
                        urlFilter: "api.tgoapis.com/web-user-apimemberaddress-santral/addresses",
                        resourceTypes: ["xmlhttprequest"]
                    }
                }
            ]
        });
        
        console.log('[YeKupon] ✅ Trendyol mobil header kuralları eklendi (belirli endpoint\'ler + adres web origin)');
    } catch (error) {
        console.error('[YeKupon] ❌ Trendyol header kuralları eklenemedi:', error);
    }
}

// Extension başladığında kuralları ayarla
setupTrendyolMobileHeaders();

// ===== MIGROS TAM MOBİL SPOOFING (Kuppo.net benzeri) =====
// Migros API'lerine Android cihaz gibi görünmek için header'ları değiştir

// X-Device-Sign için tarih formatı (YYYYMMDDHH)
function getCurrentDateInFormat() {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    return `${year}${month}${day}${hours}`;
}

// Global device info (oturum boyunca sabit kalır)
let migrosDeviceInfo = null;

// Cihaz bilgisi oluştur/al (gerçek Android cihaz formatında)
function getOrCreateMigrosDeviceInfo(forceNew = false) {
    if (migrosDeviceInfo && !forceNew) {
        return migrosDeviceInfo;
    }
    
    // Üreticiler
    const manufacturers = [
        'Samsung', 'Xiaomi', 'Huawei', 'OPPO', 'vivo', 'Realme', 'OnePlus', 'Google', 'Sony', 'Motorola'
    ];
    
    // Model formatları
    const modelFormats = {
        'Samsung': ['Galaxy S{n}', 'Galaxy Note {n}', 'Galaxy A{n}', 'SM-G{x}{y}{z}{a}'],
        'Xiaomi': ['Mi {n}', 'Redmi Note {n}', 'Poco F{n}', 'Redmi {n}'],
        'Huawei': ['P{n}', 'P{n} Pro', 'Mate {n}', 'Nova {n}'],
        'OPPO': ['Find X{n}', 'Reno {n}', 'A{n}'],
        'vivo': ['X{n}', 'Y{n}', 'V{n}'],
        'Realme': ['Realme {n}', 'GT {n}', 'C{n}'],
        'OnePlus': ['{n}', '{n} Pro', 'Nord {n}'],
        'Google': ['Pixel {n}', 'Pixel {n} Pro', 'Pixel {n}a'],
        'Sony': ['Xperia {n}', 'Xperia {n} Pro'],
        'Motorola': ['Moto G{n}', 'Edge {n}']
    };
    
    // Rastgele üretici seç
    const manufacturer = manufacturers[Math.floor(Math.random() * manufacturers.length)];
    const formats = modelFormats[manufacturer] || modelFormats['Samsung'];
    let modelTemplate = formats[Math.floor(Math.random() * formats.length)];
    
    // Model numarası
    const modelNumber = Math.floor(Math.random() * 30) + 1;
    const randomChar = () => String.fromCharCode(Math.floor(Math.random() * 26) + 97);
    
    let model = modelTemplate
        .replace('{n}', modelNumber)
        .replace('{x}', Math.floor(Math.random() * 10))
        .replace('{y}', Math.floor(Math.random() * 10))
        .replace('{z}', Math.floor(Math.random() * 10))
        .replace('{a}', randomChar());
    
    // Android ID formatında device ID (16 hex karakter)
    let deviceId = '';
    const hexChars = '0123456789abcdef';
    for (let i = 0; i < 16; i++) {
        deviceId += hexChars.charAt(Math.floor(Math.random() * 16));
    }
    
    migrosDeviceInfo = {
        manufacturer: manufacturer,
        model: model,
        deviceId: deviceId
    };
    
    // forceNew olmadığında storage'a kaydet (token işlemi sırasında kaydetme - her token için yeni cihaz)
    if (!forceNew) {
        chrome.storage.local.set({ 'migrosDeviceInfo': migrosDeviceInfo });
    }
    console.log('[YeKupon] ' + (forceNew ? 'Yeni' : 'İlk') + ' Migros cihaz bilgisi oluşturuldu:', migrosDeviceInfo);
    
    return migrosDeviceInfo;
}

// Storage'dan device info yükle
async function loadMigrosDeviceInfo() {
    try {
        const result = await chrome.storage.local.get('migrosDeviceInfo');
        if (result.migrosDeviceInfo) {
            migrosDeviceInfo = result.migrosDeviceInfo;
            console.log('[YeKupon] Migros cihaz bilgisi yüklendi:', migrosDeviceInfo);
        }
    } catch (error) {
        console.error('[YeKupon] Device info yükleme hatası:', error);
    }
}

// Token prefix'inden servisi belirle (Kuponstore ile aynı)
function getServiceFromToken(token) {
    if (!token) return 'sanalmarket';
    
    if (token.startsWith('mgy-')) {
        return 'yemek';
    } else if (token.startsWith('mgh-')) {
        return 'hemen';
    } else if (token.startsWith('mga-')) {
        return 'all';
    } else {
        return 'sanalmarket'; // mg- veya prefix yok
    }
}

// Servise göre URL belirle
function getServiceUrl(service) {
    const urls = {
        'yemek': 'https://www.migros.com.tr/yemek',
        'hemen': 'https://www.migros.com.tr/hemen',
        'sanalmarket': 'https://www.migros.com.tr',
        'all': 'https://www.migros.com.tr'
    };
    return urls[service] || urls['sanalmarket'];
}

// Global değişken - mevcut servis
let currentMigrosService = 'sanalmarket';

// remember-me cookie'si için header kuralı ekle
async function setupMigrosRememberMeCookie(rememberMeValue) {
    try {
        console.log('[YeKupon] remember-me cookie kuralı ekleniyor...');
        
        const device = getOrCreateMigrosDeviceInfo();
        
        // Önce mevcut remember-me kuralını kaldır
        const existingRules = await chrome.declarativeNetRequest.getSessionRules();
        const cookieRuleIds = existingRules
            .filter(rule => rule.id === 9877 || rule.id === 9890)
            .map(rule => rule.id);
        
        if (cookieRuleIds.length > 0) {
            await chrome.declarativeNetRequest.updateSessionRules({
                removeRuleIds: cookieRuleIds
            });
        }
        
        // Cookie header kuralı ekle
        await chrome.declarativeNetRequest.updateSessionRules({
            addRules: [
                {
                    id: 9877,
                    priority: 2,
                    action: {
                        type: "modifyHeaders",
                        requestHeaders: [
                            { header: "Cookie", operation: "set", value: `remember-me=${rememberMeValue}` }
                        ]
                    },
                    condition: {
                        urlFilter: "rest.migros.com.tr",
                        resourceTypes: ["xmlhttprequest"]
                    }
                },
                {
                    id: 9890,
                    priority: 5,
                    action: {
                        type: "modifyHeaders",
                        requestHeaders: [
                            { header: "Cookie", operation: "set", value: `remember-me=${rememberMeValue}` }
                        ]
                    },
                    condition: {
                        urlFilter: "migros.com.tr",
                        resourceTypes: ["xmlhttprequest", "main_frame", "sub_frame", "stylesheet", "script", "image", "font", "object", "other"]
                    }
                }
            ]
        });
        
        console.log('[YeKupon] ✅ remember-me cookie kuralı eklendi');
        return true;
    } catch (error) {
        console.error('[YeKupon] ❌ remember-me cookie kuralı eklenemedi:', error);
        return false;
    }
}

// Ödeme sayfası için özel kural (mobil header'ları kaldır, tarayıcı header'larını kullan)
async function setupMigrosPaymentRule() {
    try {
        const browserUserAgent = navigator.userAgent;
        
        // Önce mevcut ödeme kuralını kaldır
        const existingRules = await chrome.declarativeNetRequest.getSessionRules();
        const paymentRuleIds = existingRules
            .filter(rule => rule.id === 9981)
            .map(rule => rule.id);
        
        if (paymentRuleIds.length > 0) {
            await chrome.declarativeNetRequest.updateSessionRules({
                removeRuleIds: paymentRuleIds
            });
        }
        
        // Ödeme sayfası için özel kural ekle (mobil header'ları KALDIRIP tarayıcı header'larını kullan)
        await chrome.declarativeNetRequest.updateSessionRules({
            addRules: [{
                id: 9981,
                priority: 500, // En yüksek öncelik - diğer kuralları geçersiz kılar
                action: {
                    type: "modifyHeaders",
                    requestHeaders: [
                        // Mobil cihaz header'larını kaldır
                        { header: "X-Device-Platform", operation: "remove" },
                        { header: "X-Device-Platform-Version", operation: "remove" },
                        { header: "X-Device-Type", operation: "remove" },
                        { header: "X-Device-App-Version", operation: "remove" },
                        { header: "X-Device-Identifier", operation: "remove" },
                        { header: "X-Device-Model", operation: "remove" },
                        { header: "X-Device-App-Screen", operation: "remove" },
                        // Tarayıcı header'larını ayarla
                        { header: "User-Agent", operation: "set", value: browserUserAgent },
                        { header: "sec-ch-ua-platform", operation: "set", value: "\"Windows\"" },
                        { header: "accept-language", operation: "set", value: "tr-TR,tr;q=0.9" },
                        { header: "sec-ch-ua", operation: "set", value: "\"Chromium\";v=\"131\", \"Not_A Brand\";v=\"24\"" },
                        { header: "x-forwarded-rest", operation: "set", value: "true" },
                        { header: "sec-ch-ua-mobile", operation: "set", value: "?0" },
                        { header: "x-device-pwa", operation: "set", value: "true" },
                        { header: "x-pwa", operation: "set", value: "true" },
                        { header: "accept", operation: "set", value: "application/json" },
                        { header: "sec-fetch-site", operation: "set", value: "same-origin" },
                        { header: "sec-fetch-mode", operation: "set", value: "cors" },
                        { header: "sec-fetch-dest", operation: "set", value: "empty" },
                        { header: "referer", operation: "set", value: "https://www.migros.com.tr/hemen/siparis/odeme/" },
                        { header: "accept-encoding", operation: "set", value: "gzip, deflate, br, zstd" }
                    ]
                },
                condition: {
                    urlFilter: "*purchase/online/credit-card*",
                    resourceTypes: ["xmlhttprequest", "main_frame", "sub_frame"]
                }
            }]
        });
        
        console.log('[YeKupon] ✅ Ödeme sayfası kuralı eklendi');
        return true;
    } catch (error) {
        console.error('[YeKupon] ❌ Ödeme sayfası kuralı eklenemedi:', error);
        return false;
    }
}

// Migros TAM MOBİL header kurallarını uygula (Kuppo.net benzeri)
async function setupMigrosMobileHeaders() {
    try {
        const device = getOrCreateMigrosDeviceInfo();
        console.log('[YeKupon] Migros TAM MOBİL header kuralları uygulanıyor...');

        // Önce mevcut kuralları temizle
        const existingRules = await chrome.declarativeNetRequest.getSessionRules();
        const migrosRuleIds = existingRules
            .filter(rule => rule.id >= 9870 && rule.id <= 9899)
            .map(rule => rule.id);
        
        if (migrosRuleIds.length > 0) {
            await chrome.declarativeNetRequest.updateSessionRules({
                removeRuleIds: migrosRuleIds
            });
            console.log('[YeKupon] Mevcut Migros kuralları temizlendi:', migrosRuleIds.length);
        }

        // TAM MOBİL SPOOFING: Web browser izlerini kaldır + Android headers ekle
        await chrome.declarativeNetRequest.updateSessionRules({
            addRules: [
                // rest.migros.com.tr için WEB HEADER'LARINI KALDIR
                {
                    id: 9878,
                    priority: 10,
                    action: {
                        type: "modifyHeaders",
                        requestHeaders: [
                            // Web browser izlerini kaldır
                            { header: "sec-ch-ua", operation: "remove" },
                            { header: "sec-ch-ua-mobile", operation: "remove" },
                            { header: "sec-ch-ua-platform", operation: "remove" },
                            { header: "sec-fetch-dest", operation: "remove" },
                            { header: "sec-fetch-mode", operation: "remove" },
                            { header: "sec-fetch-site", operation: "remove" },
                            { header: "sec-fetch-user", operation: "remove" },
                            { header: "sec-fetch-storage-access", operation: "remove" },
                            { header: "referer", operation: "remove" },
                            { header: "origin", operation: "remove" },
                            { header: "x-pwa", operation: "remove" },
                            { header: "x-device-pwa", operation: "remove" },
                            { header: "x-forwarded-rest", operation: "remove" },
                            { header: "x-device-channel", operation: "remove" },
                            { header: "x-ab-tests", operation: "remove" },
                            { header: "priority", operation: "remove" }
                        ]
                    },
                    condition: {
                        urlFilter: "rest.migros.com.tr",
                        resourceTypes: ["xmlhttprequest", "main_frame", "sub_frame"]
                    }
                },
                // rest.migros.com.tr için MOBİL HEADER'LAR EKLE
                {
                    id: 9879,
                    priority: 15,
                    action: {
                        type: "modifyHeaders",
                        requestHeaders: [
                            // Android mobil headers
                            { header: "User-Agent", operation: "set", value: "okhttp/5.3.2" },
                            { header: "X-Device-Platform", operation: "set", value: "ANDROID" },
                            { header: "X-Device-Platform-Version", operation: "set", value: "9" },
                            { header: "X-Device-Type", operation: "set", value: "MOBILE" },
                            { header: "X-Device-App-Version", operation: "set", value: "13.5.1" },
                            { header: "X-Device-Identifier", operation: "set", value: device.deviceId },
                            { header: "X-Device-Model", operation: "set", value: device.model },
                            { header: "X-Device-Sign", operation: "set", value: getCurrentDateInFormat() },
                            { header: "X-Device-App-Screen", operation: "set", value: "CART" },
                            { header: "Accept-Language", operation: "set", value: "tr-TR" },
                            { header: "Accept", operation: "set", value: "application/json" },
                            { header: "Accept-Encoding", operation: "set", value: "gzip, deflate, br" }
                        ]
                    },
                    condition: {
                        urlFilter: "rest.migros.com.tr",
                        resourceTypes: ["xmlhttprequest", "main_frame", "sub_frame"]
                    }
                },
                // www.migros.com.tr için WEB HEADER'LARINI KALDIR
                {
                    id: 9885,
                    priority: 10,
                    action: {
                        type: "modifyHeaders",
                        requestHeaders: [
                            { header: "sec-ch-ua", operation: "remove" },
                            { header: "sec-ch-ua-mobile", operation: "remove" },
                            { header: "sec-ch-ua-platform", operation: "remove" },
                            { header: "sec-fetch-dest", operation: "remove" },
                            { header: "sec-fetch-mode", operation: "remove" },
                            { header: "sec-fetch-site", operation: "remove" },
                            { header: "sec-fetch-user", operation: "remove" },
                            { header: "sec-fetch-storage-access", operation: "remove" },
                            { header: "x-pwa", operation: "remove" },
                            { header: "x-device-pwa", operation: "remove" },
                            { header: "x-forwarded-rest", operation: "remove" },
                            { header: "x-device-channel", operation: "remove" },
                            { header: "x-ab-tests", operation: "remove" },
                            { header: "referer", operation: "remove" },
                            { header: "origin", operation: "remove" },
                            { header: "priority", operation: "remove" }
                        ]
                    },
                    condition: {
                        urlFilter: "www.migros.com.tr/rest",
                        resourceTypes: ["xmlhttprequest"]
                    }
                },
                // www.migros.com.tr için MOBİL HEADER'LAR EKLE
                {
                    id: 9886,
                    priority: 15,
                    action: {
                        type: "modifyHeaders",
                        requestHeaders: [
                            { header: "User-Agent", operation: "set", value: "okhttp/5.3.2" },
                            { header: "X-Device-Platform", operation: "set", value: "ANDROID" },
                            { header: "X-Device-Platform-Version", operation: "set", value: "9" },
                            { header: "X-Device-Type", operation: "set", value: "MOBILE" },
                            { header: "X-Device-App-Version", operation: "set", value: "13.5.1" },
                            { header: "X-Device-Identifier", operation: "set", value: device.deviceId },
                            { header: "X-Device-Model", operation: "set", value: device.model },
                            { header: "X-Device-Sign", operation: "set", value: getCurrentDateInFormat() },
                            { header: "X-Device-App-Screen", operation: "set", value: "CART" },
                            { header: "Accept-Language", operation: "set", value: "tr-TR" },
                            { header: "Accept", operation: "set", value: "application/json" }
                        ]
                    },
                    condition: {
                        urlFilter: "www.migros.com.tr/rest",
                        resourceTypes: ["xmlhttprequest"]
                    }
                },
                // Sunucudan gelen set-cookie header'larını engelle (duplicate cookie önleme)
                {
                    id: 9887,
                    priority: 20,
                    action: {
                        type: "modifyHeaders",
                        responseHeaders: [
                            { header: "set-cookie", operation: "remove" }
                        ]
                    },
                    condition: {
                        urlFilter: "www.migros.com.tr/rest",
                        resourceTypes: ["xmlhttprequest"]
                    }
                },
                {
                    id: 9888,
                    priority: 20,
                    action: {
                        type: "modifyHeaders",
                        responseHeaders: [
                            { header: "set-cookie", operation: "remove" }
                        ]
                    },
                    condition: {
                        urlFilter: "rest.migros.com.tr",
                        resourceTypes: ["xmlhttprequest"]
                    }
                },
                // GENEL migros.com.tr kuralı - tüm istekleri kapsar (Kuponstore gibi)
                {
                    id: 9889,
                    priority: 4,
                    action: {
                        type: "modifyHeaders",
                        requestHeaders: [
                            // Mobil header'ları ekle
                            { header: "X-Device-Platform", operation: "set", value: "ANDROID" },
                            { header: "X-Device-Platform-Version", operation: "set", value: "9" },
                            { header: "X-Device-Type", operation: "set", value: "MOBILE" },
                            { header: "X-Device-App-Version", operation: "set", value: "13.5.1" },
                            { header: "X-Device-Identifier", operation: "set", value: device.deviceId },
                            { header: "X-Device-Model", operation: "set", value: device.model },
                            { header: "X-Device-Sign", operation: "set", value: getCurrentDateInFormat() },
                            { header: "X-Device-App-Screen", operation: "set", value: "CART" },
                            { header: "Accept-Language", operation: "set", value: "tr-TR" },
                            { header: "Accept-Encoding", operation: "set", value: "gzip, deflate, br, zstd" },
                            { header: "User-Agent", operation: "set", value: "okhttp/5.3.2" },
                            // Web header'larını kaldır
                            { header: "x-device-pwa", operation: "remove" },
                            { header: "x-forwarded-rest", operation: "remove" },
                            { header: "priority", operation: "remove" },
                            { header: "sec-ch-ua-platform", operation: "remove" },
                            { header: "sec-ch-ua", operation: "remove" },
                            { header: "x-device-channel", operation: "remove" },
                            { header: "sec-ch-ua-mobile", operation: "remove" },
                            { header: "x-pwa", operation: "remove" },
                            { header: "sec-fetch-site", operation: "remove" },
                            { header: "sec-fetch-mode", operation: "remove" },
                            { header: "sec-fetch-dest", operation: "remove" },
                            { header: "sec-fetch-storage-access", operation: "remove" },
                            { header: "sec-fetch-user", operation: "remove" },
                            { header: "x-ab-tests", operation: "remove" },
                            { header: "referer", operation: "remove" },
                            { header: "origin", operation: "remove" }
                        ]
                    },
                    condition: {
                        urlFilter: "migros.com.tr",
                        resourceTypes: ["xmlhttprequest", "main_frame", "sub_frame", "stylesheet", "script", "image", "font", "object", "other"]
                    }
                }
            ]
        });

        console.log('[YeKupon] ✅ Migros TAM MOBİL header kuralları eklendi');
        return true;
    } catch (error) {
        console.error('[YeKupon] ❌ Migros mobil header kuralları eklenemedi:', error);
        return false;
    }
}

// Migros remember-me cookie kuralını güncelle
async function setupMigrosRememberMeCookie(rememberMeValue) {
    if (!rememberMeValue) {
        console.warn('[YeKupon] remember-me değeri boş!');
        return false;
    }
    
    try {
        console.log('[YeKupon] remember-me cookie kuralı ekleniyor...');
        console.log('[YeKupon] remember-me (ilk 20 karakter):', rememberMeValue.substring(0, 20) + '...');
        
        // Mevcut 9877 kuralını kaldır
        try {
            await chrome.declarativeNetRequest.updateSessionRules({
                removeRuleIds: [9877]
            });
        } catch (e) { }
        
        // remember-me cookie header kuralı ekle
        await chrome.declarativeNetRequest.updateSessionRules({
            addRules: [{
                id: 9877,
                priority: 2,
                action: {
                    type: "modifyHeaders",
                    requestHeaders: [
                        { header: "Cookie", operation: "set", value: `remember-me=${rememberMeValue}` }
                    ]
                },
                condition: {
                    urlFilter: "rest.migros.com.tr",
                    resourceTypes: ["xmlhttprequest"]
                }
            }]
        });
        
        console.log('[YeKupon] ✅ remember-me cookie kuralı eklendi');
        return true;
    } catch (error) {
        console.error('[YeKupon] ❌ remember-me cookie kuralı eklenemedi:', error);
        return false;
    }
}

// Ödeme sayfası için özel kural - mobil header'ları kaldır, tarayıcı header'larını kullan
async function setupMigrosPaymentRule() {
    try {
        const browserUserAgent = navigator.userAgent;
        
        // Mevcut 9981 kuralını kaldır
        try {
            await chrome.declarativeNetRequest.updateSessionRules({
                removeRuleIds: [9981]
            });
        } catch (e) { }
        
        await chrome.declarativeNetRequest.updateSessionRules({
            addRules: [{
                id: 9981,
                priority: 1000,
                action: {
                    type: "modifyHeaders",
                    requestHeaders: [
                        // Mobil header'ları kaldır (eğer varsa)
                        { header: "X-Device-Platform", operation: "remove" },
                        { header: "X-Device-Platform-Version", operation: "remove" },
                        { header: "X-Device-Type", operation: "remove" },
                        { header: "X-Device-App-Version", operation: "remove" },
                        { header: "X-Device-Identifier", operation: "remove" },
                        { header: "X-Device-Model", operation: "remove" },
                        { header: "X-Device-App-Screen", operation: "remove" },
                        // Tarayıcı header'larını ayarla
                        { header: "User-Agent", operation: "set", value: browserUserAgent },
                        { header: "sec-ch-ua-platform", operation: "set", value: "\"Windows\"" },
                        { header: "accept-language", operation: "set", value: "tr-TR,tr;q=0.9" },
                        { header: "sec-ch-ua", operation: "set", value: "\"Chromium\";v=\"131\", \"Not_A Brand\";v=\"24\"" },
                        { header: "x-forwarded-rest", operation: "set", value: "true" },
                        { header: "sec-ch-ua-mobile", operation: "set", value: "?0" },
                        { header: "x-device-pwa", operation: "set", value: "true" },
                        { header: "x-pwa", operation: "set", value: "true" },
                        { header: "accept", operation: "set", value: "application/json" },
                        { header: "sec-fetch-site", operation: "set", value: "same-origin" },
                        { header: "sec-fetch-mode", operation: "set", value: "cors" },
                        { header: "sec-fetch-dest", operation: "set", value: "empty" },
                        { header: "referer", operation: "set", value: "https://www.migros.com.tr/hemen/siparis/odeme/" },
                        { header: "accept-encoding", operation: "set", value: "gzip, deflate, br, zstd" }
                    ]
                },
                condition: {
                    urlFilter: "*purchase/online/credit-card*",
                    resourceTypes: ["xmlhttprequest", "main_frame", "sub_frame"]
                }
            }]
        });
        
        console.log('[YeKupon] ✅ Ödeme sayfası kuralı eklendi');
        return true;
    } catch (error) {
        console.error('[YeKupon] ❌ Ödeme sayfası kuralı eklenemedi:', error);
        return false;
    }
}

// Service worker başladığında ayarları yükle ve kuralları uygula
(async function initMigrosRules() {
    await loadMigrosDeviceInfo();
    await setupMigrosMobileHeaders();
    await setupMigrosPaymentRule();
    
    // Mevcut remember-me cookie varsa kuralı ekle
    try {
        const rememberMeCookie = await new Promise(resolve => {
            chrome.cookies.get({ url: 'https://www.migros.com.tr', name: 'remember-me' }, cookie => {
                resolve(cookie);
            });
        });
        if (rememberMeCookie) {
            await setupMigrosRememberMeCookie(rememberMeCookie.value);
        }
    } catch (e) {
        console.log('[YeKupon] Mevcut remember-me cookie bulunamadı');
    }
})();
// ===== MIGROS TAM MOBİL HEADER SPOOFING SONU =====


function randomizeLocation(lat, lng, radiusMeters) {
    const radiusInDegrees = radiusMeters / 111320;
    const u = Math.random();
    const v = Math.random();
    const w = radiusInDegrees * Math.sqrt(u);
    const t = 2 * Math.PI * v;
    const x = w * Math.cos(t);
    const y = w * Math.sin(t);
    
    return {
        lat: lat + y,
        lng: lng + x
    };
}

console.log('YeKupon Background Script loaded - Organized version');

// === Background State ===
let ysVoucherMap = {};
let ysCheckoutInProgress = false;
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    switch (request.action) {
        case 'setupMigros':
            handleMigrosSetup(request.userData, request.tabId, sendResponse);
            return true;
            
        case 'setupTrendyol':
            handleTrendyolSetup(request.userData, request.tabId, sendResponse);
            return true;
            
        case 'setupYemekSepeti':
            handleYemekSepetiSetupNew(request.userData, request.tabId, sendResponse);
            return true;
            
        case 'fetchMigrosAPI':
            handleMigrosAPIRequest(request, sendResponse);
            return true;
            
        case 'fetchTrendyolAPI':
            handleTrendyolAPIRequest(request, sendResponse);
            return true;
            
        case 'fetchYemeksepetiAPI':
            handleYemeksepetiAPIRequest(request, sendResponse);
            return true;
            
        case 'createYemeksepetiAddress':
            createYemeksepetiAddress(request.address, request.tabId)
                .then(result => sendResponse({ success: result }))
                .catch(error => sendResponse({ success: false, error: error.message }));
            return true;
            
        case 'handleMigrosLogin':
            handleMigrosLogin(request.data, request.token, request.tabId);
            sendResponse({ success: true });
            return true;
            
        case 'handleTrendyolLogin':
            handleTrendyolLogin(request.data, request.token, request.tabId);
            sendResponse({ success: true });
            return true;

        case 'handleUberLogin':
            handleUberLogin(request.data, request.token, request.tabId);
            sendResponse({ success: true });
            return true;

        case 'setUdiFingerprintCookie':
            chrome.cookies.set({
                url: 'https://www.uber.com',
                name: 'udi-fingerprint',
                value: request.value,
                domain: '.uber.com',
                path: '/',
                secure: true,
                sameSite: 'no_restriction',
                expirationDate: Math.floor(Date.now() / 1000) + 365 * 24 * 60 * 60
            });
            sendResponse({ success: true });
            return false;
            
        case 'openExtension':
            chrome.tabs.create({ url: 'fullscreen.html' });
            sendResponse({ success: true });
            return true;
            
        case 'ysProxyRequest':
            console.log('🛰️ YS Proxy request received:', request.url || request.requestDetails?.url);
            handleYsProxyRequest(request, sendResponse);
            return true;
            
        case 'YS_PROXY_REQUEST':
            console.log('🔴 YS Proxy request received:', request.url);
            handleYsProxyRequest(request, sendResponse);
            return true;
            
        case 'tyProxyRequest':
            console.log('🟠 TY Proxy request received:', request.url);
            handleTyProxyRequest(request, sendResponse);
            return true;

        // Content script'ten adres listesi talebi
        case 'GET_ADDRESS_LIST_FROM_CONTENT':
            (async () => {
                try {
                    const data = await new Promise(resolve => {
                        chrome.storage.sync.get('addressList', result => {
                            if (chrome.runtime.lastError || !result || !result.addressList) {
                                chrome.storage.local.get('addressList', localResult => {
                                    if (chrome.runtime.lastError) {
                                        resolve({ addressList: null });
                                    } else {
                                        resolve(localResult || {});
                                    }
                                });
                            } else {
                                resolve(result);
                            }
                        });
                    });

                    let addresses = [];
                    if (data && data.addressList) {
                        try {
                            addresses = JSON.parse(data.addressList);
                            if (!Array.isArray(addresses)) addresses = [];
                        } catch (e) {
                            console.error('[YeKupon] Adres listesi parse hatası:', e);
                            addresses = [];
                        }
                    }

                    const savedData = await chrome.storage.local.get('yekupon_saved_addresses');
                    const savedAddresses = savedData.yekupon_saved_addresses || [];
                    const finalAddresses = addresses.length > 0 ? addresses : savedAddresses;
                    sendResponse({ success: true, addresses: finalAddresses });
                } catch (error) {
                    console.error('[YeKupon] Adres listesi alınırken hata:', error);
                    sendResponse({ success: false, error: error.message, addresses: [] });
                }
            })();
            return true;

        case 'updateVoucherMap':
            ysVoucherMap = request.voucherMap || {};
            console.log('[YeKupon] Voucher map güncellendi:', Object.keys(ysVoucherMap).length, 'kayıt');
            sendResponse({ success: true });
            return false;

        case 'updateCheckoutState':
            ysCheckoutInProgress = !!request.inProgress;
            console.log('[YeKupon] Checkout durumu:', ysCheckoutInProgress ? 'aktif' : 'pasif');
            sendResponse({ success: true });
            return false;

        case 'deleteMigrosAddress':
            console.log('[YeKupon] deleteMigrosAddress mesajı alındı:', request.addressId, request.service);
            (async () => {
                try {
                    // remember-me cookie'yi al
                    const cookies = await chrome.cookies.getAll({ domain: '.migros.com.tr' });
                    const rememberMe = cookies.find(c => c.name === 'remember-me');
                    
                    if (!rememberMe) {
                        console.error('[YeKupon] remember-me cookie bulunamadı');
                        sendResponse({ success: false, error: 'Oturum bulunamadı. Migros\'a giriş yapın.' });
                        return;
                    }
                    
                    const result = await deleteMigrosAddressWithCookie(
                        request.addressId, 
                        rememberMe.value, 
                        request.service || 'hemen'
                    );
                    
                    console.log('[YeKupon] Silme sonucu:', result);
                    sendResponse({ success: result });
                } catch (error) {
                    console.error('[YeKupon] deleteMigrosAddress hatası:', error);
                    sendResponse({ success: false, error: error.message });
                }
            })();
            return true;
            
        case 'updateVoucherMap':
            try {
                globalVoucherMap = request.data || {};
                console.log('[YeKupon] Voucher map updated:', Object.keys(globalVoucherMap).length, 'entries');
                sendResponse({ success: true });
            } catch (e) {
                console.error('[YeKupon] updateVoucherMap error:', e);
                sendResponse({ success: false, error: e.message });
            }
            return true;

        case 'checkoutStateChanged':
            try {
                isCheckoutInProgress = !!request.inProgress;
                console.log('[YeKupon] Checkout state changed:', isCheckoutInProgress);
                sendResponse({ success: true, checkoutInProgress: isCheckoutInProgress });
            } catch (e) {
                console.error('[YeKupon] checkoutStateChanged error:', e);
                sendResponse({ success: false, error: e.message });
            }
            return true;

        default:
            if (request.token) {
                if (request.token.startsWith('mg-')) {
                    console.log('?? Migros token detected:', request.token);
                    handleMigrosLogin(request.data, request.token, request.tabId);
                    sendResponse({ success: true });
                    return true;
                } else if (request.token.startsWith('ty-')) {
                    console.log('🧡 Trendyol token detected:', request.token);
                    handleTrendyolLogin(request.data, request.token, request.tabId);
                    sendResponse({ success: true });
                    return true;
                } else if (request.token.startsWith('tgo-')) {
                    console.log('🍽️ TgoYemek token detected:', request.token);
                    handleTgoYemekLogin(request.data, request.token, request.tabId);
                    sendResponse({ success: true });
                    return true;
                } else if (request.token.startsWith('ub-') || request.token.startsWith('uber-')) {
                    console.log('🚕 Uber token detected:', request.token);
                    handleUberLogin(request.data, request.token, request.tabId);
                    sendResponse({ success: true });
                    return true;
                } else if (request.token.startsWith('ys-') || request.token.startsWith('yx-')) {
                    console.log('🍕 YemekSepeti token detected:', request.token);
                    handleYemekSepetiSetup(request, sendResponse);
                    return true;
                } else {
                    console.log('ℹ️ Bilinmeyen token prefix:', request.token);
                    sendResponse({ 
                        success: true, 
                        message: 'Token alındı ancak platform algılanamadı.' 
                    });
                    return true;
                }
            } else {
                handleYemekSepetiSetup(request, sendResponse);
                return true;
            }
    }
});


async function handleMigrosAPIRequest(request, sendResponse) {
    try {
        console.log('Migros API proxy request:', request.url, request.method || 'GET');
        
        // Web REST API header'ları (inject.js'den gelen header'ları kullan)
        const headers = {};
        if (request.headers) {
            Object.assign(headers, request.headers);
        }
        
        const cookies = await new Promise((resolve) => {
            chrome.cookies.getAll({ domain: '.migros.com.tr' }, (cookies) => {
                resolve(cookies);
            });
        });
        
        if (cookies.length > 0) {
            const cookieString = cookies.map(c => `${c.name}=${c.value}`).join('; ');
            headers['Cookie'] = cookieString;
            console.log('Migros API PROXY: Cookies added:', cookies.length + ' items');
        }
        
        const fetchOptions = {
            method: request.method || 'GET',
            headers: headers
        };
        
        if (request.method === 'POST' && request.body) {
            fetchOptions.body = typeof request.body === 'string' ? request.body : JSON.stringify(request.body);
        }
        
        const response = await fetch(request.url, fetchOptions);
        
        // Yanıt başlıklarını al
        const respHeaders = {};
        response.headers.forEach((value, key) => {
            respHeaders[key.toLowerCase()] = value;
        });
        
        // Her durumda yanıt verisini al (hata kodlarında da veri olabilir)
        const textData = await response.text();
        let data;
        try {
            data = JSON.parse(textData);
        } catch (e) {
            data = textData;
        }
        
        console.log('Migros API PROXY: Response', response.status, textData.length, 'bytes');
        
        sendResponse({
            success: true,
            data: data,
            status: response.status,
            headers: respHeaders
        });
        
    } catch (error) {
        console.error('Migros API proxy error:', error);
        sendResponse({
            success: false,
            error: error.message,
            status: error.status || 500
        });
    }
}

// Chrome browsingData API ile site verilerini temizle - Kuppo.net benzeri (Paralel optimizasyon)
async function clearSiteData(domain) {
    const origin = `https://${domain}`;
    const totalStartTime = performance.now();

    try {
        // IndexedDB temizleme fonksiyonu (origin-specific only)
        const clearIndexedDB = async () => {
            const startTime = performance.now();
            try {
                await chrome.browsingData.remove({
                    origins: [origin]
                }, {
                    "indexedDB": true
                });
                const duration = performance.now() - startTime;
                console.log(`🗄️ IndexedDB temizlendi (${domain}): ${duration.toFixed(2)}ms`);
                return true;
            } catch (indexedDBError) {
                console.warn(`IndexedDB origin bazlı temizleme hatası (${domain}):`, indexedDBError);
                return false;
            }
        };

        // ServiceWorker temizleme fonksiyonu (origin-specific only)
        const clearServiceWorkers = async () => {
            const startTime = performance.now();
            try {
                await chrome.browsingData.remove({
                    origins: [origin]
                }, {
                    "serviceWorkers": true
                });
                const duration = performance.now() - startTime;
                console.log(`🔧 ServiceWorkers temizlendi (${domain}): ${duration.toFixed(2)}ms`);
                return true;
            } catch (swError) {
                console.warn(`ServiceWorkers origin bazlı temizleme hatası (${domain}):`, swError);
                return false;
            }
        };

        // Origin bazlı temizleme wrapper'ı
        const clearOriginData = async () => {
            const startTime = performance.now();
            try {
                await chrome.browsingData.remove({
                    origins: [origin]
                }, {
                    "cache": false,
                    "cacheStorage": false,
                    "cookies": true,
                    "downloads": false,
                    "history": false,
                    "localStorage": true,
                    "passwords": false
                });
                const duration = performance.now() - startTime;
                console.log(`🌐 Origin verileri temizlendi (${domain}): ${duration.toFixed(2)}ms`);
                return true;
            } catch (error) {
                console.error(`Origin temizleme hatası (${domain}):`, error);
                return false;
            }
        };

        // Tüm temizleme işlemlerini paralel olarak çalıştır
        const [originResult, indexedDBResult, swResult] = await Promise.allSettled([
            clearOriginData(),
            clearIndexedDB(),
            clearServiceWorkers()
        ]);

        // Sonuçları kontrol et
        const originSuccess = originResult.status === 'fulfilled' && originResult.value;
        const indexedDBSuccess = indexedDBResult.status === 'fulfilled' && indexedDBResult.value;
        const swSuccess = swResult.status === 'fulfilled' && swResult.value;

        const totalDuration = performance.now() - totalStartTime;
        console.log(`⏱️ TOPLAM ${domain} temizleme süresi: ${totalDuration.toFixed(2)}ms (Origin: ${originSuccess}, IndexedDB: ${indexedDBSuccess}, SW: ${swSuccess})`);

        return originSuccess; // Ana işlemin başarılı olması yeterli
    } catch (error) {
        console.error(`Site verileri temizlenirken hata: ${domain}`, error);
        return false;
    }
}

// Tüm Migros cookie'lerini temizle
async function clearAllMigrosCookies() {
    return new Promise(async (resolve) => {
        try {
            // Tüm Migros domain'lerinden cookie'leri al ve sil
            const domains = ['migros.com.tr', '.migros.com.tr', 'www.migros.com.tr', '.www.migros.com.tr', 'rest.migros.com.tr'];
            
            for (const domain of domains) {
                const cookies = await new Promise((res) => {
                    chrome.cookies.getAll({ domain: domain }, (cookies) => res(cookies || []));
                });
                
                for (const cookie of cookies) {
                    const url = `http${cookie.secure ? 's' : ''}://${cookie.domain.startsWith('.') ? cookie.domain.slice(1) : cookie.domain}${cookie.path}`;
                    await new Promise((res) => {
                        chrome.cookies.remove({ url: url, name: cookie.name }, () => res());
                    });
                }
            }
            
            // Ayrıca browsingData API ile de temizle (daha kapsamlı)
            try {
                await chrome.browsingData.removeCookies({
                    origins: [
                        "https://www.migros.com.tr",
                        "https://rest.migros.com.tr",
                        "https://migros.com.tr"
                    ]
                });
            } catch (e) {
                console.log('[YeKupon] browsingData API kullanılamadı, manuel temizlik yapıldı');
            }
            
            console.log('[YeKupon] ✅ Tüm Migros cookie\'leri temizlendi');
            resolve(true);
        } catch (error) {
            console.error('[YeKupon] Cookie temizleme hatası:', error);
            resolve(false);
        }
    });
}

// 🗑️ Token silme zamanlayıcı - sunucuya istek gönderir
async function scheduleTokenDeletion(tokenkodu, platform = 'migros', delayMinutes = 60) {
    try {
        const response = await fetch('https://yekupon.com/cookies/schedule_delete.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                tokenkodu: tokenkodu,
                platform: platform,
                delay_minutes: delayMinutes
            })
        });

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }

        const result = await response.json();
        console.log('[YeKupon] Token silme planlandı:', result);
        return result;
    } catch (error) {
        console.error('[YeKupon] Token silme planlama hatası:', error);
        throw error;
    }
}

async function handleMigrosLogin(data, token, tabId) {
    try {
        await sendMigrosLogMessage("🚀 Token işlemi başlatılıyor...", "info", tabId);
        
        // Token'dan servisi belirle (mgh- = hemen, mgy- = yemek, mg- = sanalmarket)
        currentMigrosService = getServiceFromToken(token);
        const serviceUrl = getServiceUrl(currentMigrosService);
        await sendMigrosLogMessage(`📍 Servis: ${currentMigrosService.toUpperCase()}`, "info", tabId);
        
        // ⚠️ ADRES KONTROLÜ: Migros hesaplarına girmeden önce adres olup olmadığını kontrol et
        const savedAddress = await getSavedAddress();
        if (!savedAddress) {
            await sendMigrosLogMessage("⚠️ Kayıtlı adres bulunamadı!", "warning", tabId);
            await showMigrosBottomWarning("Migros hesaplarına girmek için adres eklemelisiniz. Lütfen eklentiden bir adres ekleyin.", tabId);
            // İşleme devam et ama kullanıcıyı uyar
        }
        
        // Servisi storage'a kaydet
        await chrome.storage.local.set({ 
            'migros_current_service': currentMigrosService,
            'migros_service_url': serviceUrl
        });
        
        // ⚡ YENİ: Her token kullanımında YENİ cihaz bilgisi oluştur (kupon limiti bypass)
        const newDeviceInfo = getOrCreateMigrosDeviceInfo(true); // forceNew = true
        await sendMigrosLogMessage(`📱 Yeni cihaz: ${newDeviceInfo.manufacturer} ${newDeviceInfo.model}`, "info", tabId);
        
        // DNR kurallarını yeni device ID ile güncelle
        await setupMigrosMobileHeaders();
        
        // 1. ADIM: Tüm Migros verilerini temizle
        await sendMigrosLogMessage("🧹 Migros verileri temizleniyor...", "info", tabId);
        await clearAllMigrosCookies();
        await clearSiteData("migros.com.tr");
        
        // 2. ADIM: YeKupon API'den cookie'leri al
        await sendMigrosLogMessage("🔑 Token doğrulanıyor...", "info", tabId);
        const response = await fetch(`https://yekupon.com/cookies/${token}`);
        
        if (!response.ok) {
            throw new Error(`Sunucu hatası: ${response.status}`);
        }
        
        const responseData = await response.json();
        const cookiesArray = responseData.data || responseData;
        
        if (!Array.isArray(cookiesArray)) {
            throw new Error('Geçersiz veri formatı');
        }
        
        // 3. ADIM: Sadece remember-me cookie'sini bul ve kaydet
        const rememberMeCookie = cookiesArray.find(c => c.name === 'remember-me');
        
        if (!rememberMeCookie || !rememberMeCookie.value) {
            throw new Error('remember-me cookie bulunamadı!');
        }
        
        await sendMigrosLogMessage("✅ Token doğrulandı!", "success", tabId);
        
        // 4. ADIM: SADECE remember-me cookie'sini kaydet (TAM FORMAT)
        await sendMigrosLogMessage("🍪 Oturum ayarlanıyor...", "info", tabId);
        
        await new Promise((resolve) => {
            chrome.cookies.set({
                url: "https://www.migros.com.tr",
                name: "remember-me",
                value: rememberMeCookie.value,
                domain: ".migros.com.tr",
                path: "/",
                secure: true,
                httpOnly: false,
                sameSite: "unspecified",
                expirationDate: Math.floor(Date.now() / 1000) + (180 * 24 * 60 * 60) // 180 gün
            }, (cookie) => {
                if (chrome.runtime.lastError) {
                    console.error('[YeKupon] Cookie hatası:', chrome.runtime.lastError.message);
                } else {
                    console.log('[YeKupon] ✅ remember-me cookie kaydedildi');
                }
                resolve();
            });
        });
        
        // 5. ADIM: Arka planda adres ekle (siteye gitmeden)
        await sendMigrosLogMessage("📍 Adres ekleniyor...", "info", tabId);
        
        const addressResult = await addMigrosAddressInBackground(rememberMeCookie.value, currentMigrosService, tabId);
        
        if (addressResult.success) {
            await sendMigrosLogMessage("✅ Adres başarıyla eklendi!", "success", tabId);
            
            // 🗑️ MGY tokenleri için 1 saat sonra silme planla
            if (token && token.toLowerCase().startsWith('mgy')) {
                try {
                    await scheduleTokenDeletion(token, 'migros', 60); // 60 dakika = 1 saat
                    await sendMigrosLogMessage("🕐 Token 1 saat sonra silinmek üzere planlandı", "info", tabId);
                } catch (scheduleError) {
                    console.error('[YeKupon] Token silme planlaması hatası:', scheduleError);
                    // Hata olsa bile devam et
                }
            }
            
            // 6. ADIM: Sadece adres başarıyla eklendiyse siteye yönlendir
            await sendMigrosLogMessage("🌐 Migros'a yönlendiriliyor...", "info", tabId);
            
            await new Promise(resolve => setTimeout(resolve, 500));
            
            chrome.tabs.create({
                url: serviceUrl,
                active: true
            });
            
            await sendMigrosLogMessage("🎉 İşlem tamamlandı!", "success", tabId);
        } else {
            // Detaylı hata mesajı göster
            let errorMsg = addressResult.error || 'Bilinmeyen hata';
            
            // Violations varsa ekle
            if (addressResult.violations && addressResult.violations.length > 0) {
                const violationDetails = addressResult.violations.map(v => `${v.field}: ${v.errorDetail}`).join(', ');
                errorMsg += ` (${violationDetails})`;
            }
            
            await sendMigrosLogMessage(`❌ ${errorMsg}`, "error", tabId);
            
            // Eklenti sayfasında alt uyarı göster
            if (addressResult.isValidationError) {
                // Eksik alan hatası - detaylı mesaj göster
                await showMigrosBottomWarning(`⚠️ ${errorMsg} Lütfen eklentiden adres bilgilerinizi düzenleyin.`, tabId);
            } else if (addressResult.error === 'Kayıtlı adres bulunamadı') {
                await showMigrosBottomWarning("Migros hesaplarına girmek için adres eklemelisiniz. Lütfen eklentiden bir adres ekleyin.", tabId);
            } else {
                await showMigrosBottomWarning(`Adres eklenemedi: ${errorMsg}`, tabId);
            }
            
            await sendMigrosLogMessage("⚠️ Adres eklenmediği için Migros'a yönlendirilmedi. Lütfen adres bilgilerinizi kontrol edin.", "warning", tabId);
        }
        
    } catch (error) {
        console.error('[YeKupon] Migros login error:', error);
        await sendMigrosLogMessage(`❌ Hata: ${error.message}`, "error", tabId);
    }
}

// Arka planda adres ekleme fonksiyonu (siteye gitmeden)
async function addMigrosAddressInBackground(rememberMeValue, service, tabId) {
    try {
        // Service'i küçük harfe çevir
        const normalizedService = (service || '').toLowerCase();
        
        // Kayıtlı adresi al
        const activeAddress = await getSavedAddress();
        if (!activeAddress) {
            return { success: false, error: 'Kayıtlı adres bulunamadı' };
        }
        
        // Önce mevcut adresleri sil
        const existingAddresses = await getMigrosAddressesWithCookie(rememberMeValue, normalizedService);
        console.log(`[YeKupon] Mevcut adres sayısı: ${existingAddresses.length}`);
        
        if (existingAddresses.length > 0) {
            console.log(`[YeKupon] ${existingAddresses.length} mevcut adres siliniyor...`);
            for (const addr of existingAddresses) {
                const addressId = addr?.addressInfo?.id || addr?.id;
                console.log(`[YeKupon] Silinecek adres ID: ${addressId}`, addr);
                if (addressId) {
                    const deleteResult = await deleteMigrosAddressWithCookie(addressId, rememberMeValue, normalizedService);
                    console.log(`[YeKupon] Adres silme sonucu (${addressId}): ${deleteResult}`);
                    await new Promise(resolve => setTimeout(resolve, 300));
                }
            }
        }
        
        // Yeni adres ekle
        const result = await createMigrosAddressWithCookie(activeAddress, rememberMeValue, normalizedService);
        return result;
        
    } catch (error) {
        console.error('[YeKupon] Arka plan adres ekleme hatası:', error);
        return { success: false, error: error.message };
    }
}

// Cookie ile adres listesi al (eski eklenti gibi www.migros.com.tr/rest/delivery-bff)
async function getMigrosAddressesWithCookie(rememberMeValue, service) {
    try {
        const endpoint = service === 'hemen' ? '/rest/delivery-bff/hemen/delivery-addresses' : 
                        service === 'yemek' ? '/rest/delivery-bff/yemek/delivery-addresses' : 
                        '/rest/delivery-bff/delivery-addresses';
        
        console.log(`[YeKupon] Adres listesi alınıyor: www.migros.com.tr${endpoint} (service: ${service})`);
        
        const device = getOrCreateMigrosDeviceInfo();
        const response = await fetch(`https://www.migros.com.tr${endpoint}`, {
            method: 'GET',
            headers: {
                'accept': 'application/json',
                'accept-language': 'tr-TR',
                'X-Device-Platform': 'ANDROID',
                'X-Device-Platform-Version': '9',
                'X-Device-Type': 'MOBILE',
                'X-Device-App-Version': '13.5.1',
                'X-Device-App-Screen': 'CART',
                'X-Device-Sign': getCurrentDateInFormat(),
                'User-Agent': 'okhttp/5.3.2',
                'X-Device-Identifier': device.deviceId,
                'X-Device-Model': device.model,
                'cookie': `remember-me=${rememberMeValue}`
            }
        });
        
        if (!response.ok) {
            console.error(`[YeKupon] Adres listesi alınamadı: ${response.status}`);
            return [];
        }
        
        const data = await response.json();
        console.log(`[YeKupon] Adres listesi alındı:`, data);
        
        // API bazen data.data, bazen direkt array dönüyor
        const addresses = Array.isArray(data) ? data : (data.data || []);
        console.log(`[YeKupon] Parse edilmiş adres sayısı: ${addresses.length}`);
        return addresses;
        
    } catch (error) {
        console.error('[YeKupon] Adres listesi alınamadı:', error);
        return [];
    }
}

// Cookie ile adres sil (rest.migros.com.tr API - Kuponstore gibi)
async function deleteMigrosAddressWithCookie(addressId, rememberMeValue, service) {
    try {
        // Servis tipine göre endpoint belirle (Kuponstore formatı)
        let endpoint = `/v2/addresses/${addressId}`;
        if (service === 'hemen') {
            endpoint = `/hemen/v2/addresses/${addressId}`;
        } else if (service === 'yemek') {
            endpoint = `/yemek/v2/addresses/${addressId}`;
        }
        
        console.log(`[YeKupon] Adres silme isteği: rest.migros.com.tr${endpoint}`);
        
        // Mobil header'ları kullan (Kuponstore gibi - sadece remember-me cookie)
        const device = getOrCreateMigrosDeviceInfo();
        const headers = {
            'X-Device-Platform': 'ANDROID',
            'X-Device-Platform-Version': '9',
            'X-Device-Type': 'MOBILE',
            'X-Device-App-Version': '13.5.1',
            'X-Device-Sign': getCurrentDateInFormat(),
            'User-Agent': 'okhttp/5.3.2',
            'X-Device-Identifier': device.deviceId,
            'X-Device-Model': device.model,
            'Cookie': `remember-me=${rememberMeValue}`
        };
        
        const response = await fetch(`https://rest.migros.com.tr${endpoint}`, {
            method: 'DELETE',
            headers: headers
        });
        
        if (response.ok || response.status === 204 || response.status === 200) {
            console.log(`[YeKupon] ✅ Adres silindi: ${addressId}`);
            return true;
        } else {
            const errorText = await response.text().catch(() => '');
            console.error(`[YeKupon] Adres silme hatası: ${response.status} - ${errorText}`);
            return false;
        }
        
    } catch (error) {
        console.error('[YeKupon] Adres silme hatası:', error);
        return false;
    }
}

// Cookie ile adres ekle (Eski eklentiden - sorunsuz çalışan versiyon)
async function createMigrosAddressWithCookie(address, rememberMeValue, service) {
    try {
        // Eski eklenti gibi www.migros.com.tr/rest/delivery-bff kullan
        const endpoint = service === 'hemen' ? '/rest/delivery-bff/hemen/delivery-addresses' : 
                        service === 'yemek' ? '/rest/delivery-bff/yemek/delivery-addresses' : 
                        '/rest/delivery-bff/delivery-addresses';
        
        const requestId = Date.now().toString() + Math.floor(Math.random() * 1000000000).toString();
        
        // Alan değerlerini hazırla
        const processedNeighborhood = address.neighborhood || address.districtName || "";
        const processedStreet = address.street || address.streetName || "";
        const processedBuilding = address.building || address.buildingNo || "yok";
        const processedFloor = address.floor || address.floorNumber || "yok";
        const processedApartment = address.apartment || address.apartmentNo || "yok";
        const realNameInfo = `Ad Soyad: ${address.fullname || address.fullName || ""}`;

        let cityId = parseInt(address.cityId || address.city_id, 10);
        let townId = parseInt(address.townId || address.town_id || address.ilceId, 10) || 0;
        let districtId = parseInt(address.districtId || address.district_id || address.mahalleId, 10) || 0;

        if (!Number.isFinite(cityId) || cityId <= 0) {
            cityId = 34;
        }

        // Eğer townId veya districtId yoksa, Migros API'den al (eski eklenti mantığı)
        if (!townId || !districtId) {
            const locationIds = await getMigrosLocationIdsOld(
                rememberMeValue,
                address.district || address.townName || 'Bağcılar',
                address.city || address.cityName || 'İstanbul'
            );
            townId = townId || locationIds.townId || 0;
            districtId = districtId || locationIds.districtId || 0;
        }

        const useCleanAddress = Object.prototype.hasOwnProperty.call(address, 'useCleanAddress')
            ? address.useCleanAddress
            : false;

        // İsim ve soyisim ayırma - lastName boş olamaz!
        const fullNameParts = (address.fullname || address.fullName || "Müşteri Adı")?.trim().split(' ') || ["Müşteri", "Adı"];
        const firstName = fullNameParts[0] || "Müşteri";
        const lastName = fullNameParts.slice(1).join(' ') || fullNameParts[0] || "Adı"; // Tek isim varsa aynısını kullan

        // Telefon numarasını açıklamaya eklemek için rastgele mesajlar
        const phoneMessages = [
            "YENİ NUMARAM",
            "BU NUMARAYI ARAYIN",
            "BURAYI ARAYIN",
            "BU TEL İLE ARAYIN",
            "SİPARİŞ TEL",
            "İLETİŞİM NUMARAM BU",
            "BU NUMARADAN ARAYIN MUTLAKA",
            "MUTLAKA BU NUMARAYI ARAYIN",
            "BENİ BU NUMARADAN ARAYIN",
            "GÜNCEL TEL NUMARAM",
            "SADECE BU NUMARAYI ARAYIN",
            "SİPARİŞ İÇİN BU NUMARAYI ARAYIN",
            "LÜTFEN BU NUMARAYI ARAYIN",
            "BU TEL NUMARASINI ARAYIN",
            "TEL NO"
        ];
        const randomPhoneMessage = phoneMessages[Math.floor(Math.random() * phoneMessages.length)];
        
        // Telefon numarasını direction alanının EN BAŞINA ekle (numara önce!)
        const phoneForDirection = address.phone || address.phoneNumber || "";
        const baseDirection = address.description || address.direction || "";
        const directionWithPhone = phoneForDirection 
            ? `${phoneForDirection} - ${randomPhoneMessage} - ${baseDirection}` 
            : baseDirection;

        // Eski eklenti formatında adres verisi
        const addressData = {
            name: address.label || address.fullname || address.fullName || "Ev",
            districtId: districtId || 420,
            firstName: firstName,
            lastName: lastName,
            townId: townId || 25,
            cityId: cityId,
            streetName: processedStreet,
            floorNumber: processedFloor,
            doorNumber: processedApartment,
            buildingNumber: processedBuilding,
            direction: directionWithPhone,
            latitude: parseFloat(address.latitude || address.lat || 41.0082),
            longitude: parseFloat(address.longitude || address.lng || 28.9784),
            detail: `${processedNeighborhood}, ${processedStreet} ${processedBuilding}, ${address.district || address.townName || 'Bağcılar'}/${address.province || address.cityName || 'İstanbul'}`,
            townName: address.district || address.townName || "Bağcılar",
            districtName: processedNeighborhood
        };
        
        console.log('[YeKupon] Gönderilecek adres verisi:', addressData);
        
        // www.migros.com.tr'ye istek at (eski eklenti gibi)
        const response = await fetch(`https://www.migros.com.tr${endpoint}?reid=${requestId}`, {
            method: 'POST',
            headers: {
                'accept': 'application/json, text/plain, */*',
                'accept-language': 'tr-TR,tr;q=0.9,en;q=0.8',
                'content-type': 'application/json',
                'cookie': `remember-me=${rememberMeValue}`,
                'referer': 'https://www.migros.com.tr/yemek',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            },
            body: JSON.stringify(addressData)
        });
        
        const result = await response.json();
        
        if (response.ok && result.successful !== false) {
            console.log('[YeKupon] ✅ Adres eklendi');
            return { success: true, data: result };
        } else {
            console.error('[YeKupon] Adres ekleme başarısız:', result);
            
            // API'den gelen detaylı hata mesajını al
            let errorMessage = '';
            
            // 422 hatası kontrolü - eksik alan hataları
            if (response.status === 422 || result.status === 422) {
                const detail = result.detail || '';
                // "direction: boş değer olamaz" gibi mesajları Türkçeleştir
                if (detail.includes('direction')) {
                    errorMessage = 'Adres Tarifi alanı boş bırakılamaz. Lütfen adresinize ulaşım tarifi ekleyin.';
                } else if (detail.includes('streetName')) {
                    errorMessage = 'Sokak/Cadde alanı boş bırakılamaz.';
                } else if (detail.includes('buildingNumber')) {
                    errorMessage = 'Bina No alanı boş bırakılamaz.';
                } else if (detail.includes('floorNumber')) {
                    errorMessage = 'Kat alanı boş bırakılamaz.';
                } else if (detail.includes('doorNumber')) {
                    errorMessage = 'Daire No alanı boş bırakılamaz.';
                } else {
                    // Genel 422 hatası - API mesajını göster
                    errorMessage = detail || 'Eksik veya hatalı alan var. Tüm alanları kontrol edin.';
                }
                
                return { 
                    success: false, 
                    error: errorMessage,
                    apiError: detail,
                    isValidationError: true,
                    violations: result.violations 
                };
            }
            
            return { success: false, error: result.errorDetail || result.message || result.detail || 'Adres eklenemedi', violations: result.violations };
        }
        
    } catch (error) {
        console.error('[YeKupon] Adres ekleme hatası:', error);
        return { success: false, error: error.message };
    }
}

// Eski eklentiden lokasyon ID alma fonksiyonu (www.migros.com.tr/rest/delivery-bff kullanır)
async function getMigrosLocationIdsOld(rememberMeValue, districtName, cityName = 'İstanbul') {
    try {
        console.log('[YeKupon] Migros API\'den lokasyon ID\'leri alınıyor:', districtName, 'şehir:', cityName);
        
        // Türkiye'nin TÜM şehirlerinin plaka kodları (Migros cityId olarak plaka kodunu kullanır)
        const cityIds = {
            'adana': 1, 'Adana': 1,
            'adıyaman': 2, 'Adıyaman': 2,
            'afyon': 3, 'Afyon': 3, 'afyonkarahisar': 3, 'Afyonkarahisar': 3,
            'ağrı': 4, 'Ağrı': 4,
            'amasya': 5, 'Amasya': 5,
            'ankara': 6, 'Ankara': 6,
            'antalya': 7, 'Antalya': 7,
            'artvin': 8, 'Artvin': 8,
            'aydın': 9, 'Aydın': 9,
            'balıkesir': 10, 'Balıkesir': 10,
            'bilecik': 11, 'Bilecik': 11,
            'bingöl': 12, 'Bingöl': 12,
            'bitlis': 13, 'Bitlis': 13,
            'bolu': 14, 'Bolu': 14,
            'burdur': 15, 'Burdur': 15,
            'bursa': 16, 'Bursa': 16,
            'çanakkale': 17, 'Çanakkale': 17,
            'çankırı': 18, 'Çankırı': 18,
            'çorum': 19, 'Çorum': 19,
            'denizli': 20, 'Denizli': 20,
            'diyarbakır': 21, 'Diyarbakır': 21,
            'edirne': 22, 'Edirne': 22,
            'elazığ': 23, 'Elazığ': 23,
            'erzincan': 24, 'Erzincan': 24,
            'erzurum': 25, 'Erzurum': 25,
            'eskişehir': 26, 'Eskişehir': 26,
            'gaziantep': 27, 'Gaziantep': 27,
            'giresun': 28, 'Giresun': 28,
            'gümüşhane': 29, 'Gümüşhane': 29,
            'hakkari': 30, 'Hakkari': 30,
            'hatay': 31, 'Hatay': 31,
            'ısparta': 32, 'Isparta': 32,
            'mersin': 33, 'Mersin': 33, 'içel': 33, 'İçel': 33,
            'istanbul': 34, 'İstanbul': 34,
            'izmir': 35, 'İzmir': 35,
            'kars': 36, 'Kars': 36,
            'kastamonu': 37, 'Kastamonu': 37,
            'kayseri': 38, 'Kayseri': 38,
            'kırklareli': 39, 'Kırklareli': 39,
            'kırşehir': 40, 'Kırşehir': 40,
            'kocaeli': 41, 'Kocaeli': 41,
            'konya': 42, 'Konya': 42,
            'kütahya': 43, 'Kütahya': 43,
            'malatya': 44, 'Malatya': 44,
            'manisa': 45, 'Manisa': 45,
            'kahramanmaraş': 46, 'Kahramanmaraş': 46, 'maraş': 46, 'Maraş': 46,
            'mardin': 47, 'Mardin': 47,
            'muğla': 48, 'Muğla': 48,
            'muş': 49, 'Muş': 49,
            'nevşehir': 50, 'Nevşehir': 50,
            'niğde': 51, 'Niğde': 51,
            'ordu': 52, 'Ordu': 52,
            'rize': 53, 'Rize': 53,
            'sakarya': 54, 'Sakarya': 54,
            'samsun': 55, 'Samsun': 55,
            'siirt': 56, 'Siirt': 56,
            'sinop': 57, 'Sinop': 57,
            'sivas': 58, 'Sivas': 58,
            'tekirdağ': 59, 'Tekirdağ': 59,
            'tokat': 60, 'Tokat': 60,
            'trabzon': 61, 'Trabzon': 61,
            'tunceli': 62, 'Tunceli': 62,
            'şanlıurfa': 63, 'Şanlıurfa': 63, 'urfa': 63, 'Urfa': 63,
            'uşak': 64, 'Uşak': 64,
            'van': 65, 'Van': 65,
            'yozgat': 66, 'Yozgat': 66,
            'zonguldak': 67, 'Zonguldak': 67,
            'aksaray': 68, 'Aksaray': 68,
            'bayburt': 69, 'Bayburt': 69,
            'karaman': 70, 'Karaman': 70,
            'kırıkkale': 71, 'Kırıkkale': 71,
            'batman': 72, 'Batman': 72,
            'şırnak': 73, 'Şırnak': 73,
            'bartın': 74, 'Bartın': 74,
            'ardahan': 75, 'Ardahan': 75,
            'ığdır': 76, 'Iğdır': 76,
            'yalova': 77, 'Yalova': 77,
            'karabük': 78, 'Karabük': 78,
            'kilis': 79, 'Kilis': 79,
            'osmaniye': 80, 'Osmaniye': 80,
            'düzce': 81, 'Düzce': 81
        };
        
        // Şehir adını normalize et ve ID'yi bul
        const normalizedCityName = cityName?.toLowerCase()
            .replace(/ı/g, 'i')
            .replace(/ğ/g, 'g')
            .replace(/ü/g, 'u')
            .replace(/ş/g, 's')
            .replace(/ö/g, 'o')
            .replace(/ç/g, 'c')
            .trim();
        
        let cityId = cityIds[cityName] || cityIds[normalizedCityName] || null;
        
        // Bulunamadıysa kısmi eşleşme dene
        if (!cityId) {
            const cityKey = Object.keys(cityIds).find(key => 
                key.toLowerCase().includes(normalizedCityName) || 
                normalizedCityName.includes(key.toLowerCase())
            );
            if (cityKey) {
                cityId = cityIds[cityKey];
                console.log(`[YeKupon] Kısmi eşleşme bulundu: ${cityName} -> ${cityKey} (ID: ${cityId})`);
            }
        }
        
        // Hala bulunamadıysa varsayılan olarak İstanbul kullan
        if (!cityId) {
            console.warn(`[YeKupon] Şehir bulunamadı: ${cityName}, varsayılan İstanbul (34) kullanılıyor`);
            cityId = 34;
        }
        
        console.log('[YeKupon] Şehir ID:', cityId, 'için', cityName);
        
        const reid = Date.now().toString() + Math.floor(Math.random() * 1000000);
        
        // www.migros.com.tr/rest/delivery-bff endpoint'ini kullan (eski eklenti gibi)
        const townsResponse = await fetch(`https://www.migros.com.tr/rest/delivery-bff/locations/towns/${cityId}/deliverable?reid=${reid}`, {
            method: 'GET',
            headers: {
                'accept': 'application/json, text/plain, */*',
                'accept-language': 'tr-TR,tr;q=0.9,en;q=0.8',
                'cache-control': 'no-cache',
                'pragma': 'no-cache',
                'cookie': `remember-me=${rememberMeValue}`,
                'referer': 'https://www.migros.com.tr/yemek',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });
        
        if (!townsResponse.ok) {
            console.error('[YeKupon] İlçeler alınamadı:', townsResponse.status);
            return { townId: 0, districtId: 0 };
        }
        
        const townsData = await townsResponse.json();
        console.log('[YeKupon] Migros towns listesi:', townsData?.length || 0, 'adet');
        
        if (!Array.isArray(townsData) || townsData.length === 0) {
            return { townId: 0, districtId: 0 };
        }
        
        // İlçeyi bul
        const targetTown = townsData.find(town => 
            town.name?.toLowerCase().includes(districtName?.toLowerCase()) ||
            districtName?.toLowerCase().includes(town.name?.toLowerCase())
        );
        
        if (!targetTown) {
            console.log('[YeKupon] İlçe bulunamadı, ilk town kullanılıyor:', townsData[0]?.name);
            return { townId: townsData[0]?.id || 0, districtId: 0 };
        }
        
        console.log('[YeKupon] İlçe bulundu:', targetTown.name, 'ID:', targetTown.id);
        
        // Mahalleleri al
        const districtsResponse = await fetch(`https://www.migros.com.tr/rest/delivery-bff/locations/districts/${targetTown.id}/deliverable?reid=${reid}`, {
            method: 'GET',
            headers: {
                'accept': 'application/json, text/plain, */*',
                'accept-language': 'tr-TR,tr;q=0.9,en;q=0.8',
                'cache-control': 'no-cache',
                'pragma': 'no-cache',
                'cookie': `remember-me=${rememberMeValue}`,
                'referer': 'https://www.migros.com.tr/yemek',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });
        
        if (!districtsResponse.ok) {
            return { townId: targetTown.id, districtId: 0 };
        }
        
        const districtsData = await districtsResponse.json();
        console.log('[YeKupon] Migros districts listesi:', districtsData?.length || 0, 'adet');
        
        if (Array.isArray(districtsData) && districtsData.length > 0) {
            const firstDistrict = districtsData[0];
            console.log('[YeKupon] Seçilen mahalle:', firstDistrict.name, 'ID:', firstDistrict.id);
            return { townId: targetTown.id, districtId: firstDistrict.id };
        }
        
        return { townId: targetTown.id, districtId: 0 };
        
    } catch (error) {
        console.error('[YeKupon] Migros lokasyon API hatası:', error);
        return { townId: 0, districtId: 0 };
    }
}

// Yedek: Migros API'den ilçe ve mahalle ID'lerini al (rest.migros.com.tr)
async function getMigrosLocationIdsFromAPI(rememberMeValue, ilce, mahalle, il) {
    try {
        console.log(`[YeKupon] Lokasyon aranıyor: İl=${il}, İlçe=${ilce}, Mahalle=${mahalle}`);
        
        // Şehir ID'leri
        const cityIds = {
            'istanbul': 34, 'İstanbul': 34,
            'ankara': 6, 'Ankara': 6,
            'izmir': 35, 'İzmir': 35,
            'bursa': 16, 'Bursa': 16,
            'antalya': 7, 'Antalya': 7
        };
        const cityId = cityIds[il] || cityIds[il?.toLowerCase()] || 34;
        
        // 1. İlçeleri al
        const reid = Date.now().toString();
        const townsResponse = await fetch(`https://rest.migros.com.tr/locations/towns/${cityId}/deliverable?reid=${reid}`, {
            headers: {
                'Accept': 'application/json',
                'Accept-Language': 'tr-TR',
                'Cookie': `remember-me=${rememberMeValue}`
            }
        });
        
        if (!townsResponse.ok) {
            console.error('[YeKupon] İlçeler alınamadı:', townsResponse.status);
            return null;
        }
        
        const towns = await townsResponse.json();
        console.log(`[YeKupon] ${towns.length} ilçe bulundu`);
        
        // İlçeyi bul (fuzzy match)
        const ilceLower = ilce?.toLowerCase().trim();
        const matchedTown = towns.find(t => 
            t.name?.toLowerCase() === ilceLower ||
            t.name?.toLowerCase().includes(ilceLower) ||
            ilceLower?.includes(t.name?.toLowerCase())
        );
        
        if (!matchedTown) {
            console.log('[YeKupon] İlçe bulunamadı:', ilce);
            // İlk ilçeyi varsayılan olarak kullan
            if (towns.length > 0) {
                console.log('[YeKupon] İlk ilçe kullanılıyor:', towns[0].name);
                return { townId: towns[0].id, districtId: null };
            }
            return null;
        }
        
        console.log(`[YeKupon] İlçe bulundu: ${matchedTown.name} (ID: ${matchedTown.id})`);
        
        // 2. Mahalleleri al
        const districtsResponse = await fetch(`https://rest.migros.com.tr/locations/districts/${matchedTown.id}/deliverable?reid=${reid}`, {
            headers: {
                'Accept': 'application/json',
                'Accept-Language': 'tr-TR',
                'Cookie': `remember-me=${rememberMeValue}`
            }
        });
        
        if (!districtsResponse.ok) {
            console.error('[YeKupon] Mahalleler alınamadı:', districtsResponse.status);
            return { townId: matchedTown.id, districtId: null };
        }
        
        const districts = await districtsResponse.json();
        console.log(`[YeKupon] ${districts.length} mahalle bulundu`);
        
        // Mahalleyi bul (fuzzy match)
        const mahalleLower = mahalle?.toLowerCase().trim();
        let matchedDistrict = districts.find(d => 
            d.name?.toLowerCase() === mahalleLower ||
            d.name?.toLowerCase().includes(mahalleLower) ||
            mahalleLower?.includes(d.name?.toLowerCase())
        );
        
        // Mahalle bulunamazsa " Mh." ekleyerek dene
        if (!matchedDistrict && mahalle) {
            const mahalleWithSuffix = mahalle.trim() + ' Mh.';
            matchedDistrict = districts.find(d => 
                d.name?.toLowerCase().includes(mahalleWithSuffix.toLowerCase())
            );
        }
        
        // Hala bulunamazsa ilk mahalleyi kullan
        if (!matchedDistrict && districts.length > 0) {
            matchedDistrict = districts[0];
            console.log('[YeKupon] Mahalle bulunamadı, ilk mahalle kullanılıyor:', matchedDistrict.name);
        }
        
        if (matchedDistrict) {
            console.log(`[YeKupon] Mahalle bulundu: ${matchedDistrict.name} (ID: ${matchedDistrict.id})`);
            return { townId: matchedTown.id, districtId: matchedDistrict.id };
        }
        
        return { townId: matchedTown.id, districtId: null };
        
    } catch (error) {
        console.error('[YeKupon] Lokasyon ID alma hatası:', error);
        return null;
    }
}

async function performMigrosAddressOperations(userData, tabId) {
    try {
        await sendMigrosLogMessage("Mevcut adresler kontrol ediliyor...", "info", tabId);

        // Cookie'ler handleMigrosLogin'de zaten kaydedildi, tekrar kaydetmeye gerek yok
        // Sadece adres işlemlerine devam et

        await new Promise(resolve => setTimeout(resolve, 500));

        const activeAddress = await getSavedAddress();
        if (!activeAddress) {
            await sendMigrosLogMessage("Aktif adres bulunamadı - lütfen eklentiden adres ekleyin.", "error", tabId);
            return false;
        }

        const shouldAutoAdd = activeAddress.autoAddAddress ?? activeAddress.autoFillAddress ?? true;
        return await manageMigrosAddresses(activeAddress, shouldAutoAdd, tabId);

    } catch (error) {
        console.error('Migros adres işlemi hatası:', error);
        await sendMigrosLogMessage(`Adres işlemi hatası: ${error.message}`, "error", tabId);
        return false;
    }
}

async function manageMigrosAddresses(address, shouldAddAddress, tabId) {
    try {
        if (!address) {
            await sendMigrosLogMessage("Adres bilgisi bulunamadı.", "error", tabId);
            return false;
        }

        if (!shouldAddAddress) {
            await sendMigrosLogMessage("Otomatik adres ekleme pasif, mevcut adresler korunuyor.", "info", tabId);
        }

        // Token'dan belirlenen servisi kullan (hemen, yemek veya sanalmarket)
        // Storage'dan al veya global değişkenden
        const storage = await chrome.storage.local.get('migros_current_service');
        const tokenService = storage.migros_current_service || currentMigrosService || 'sanalmarket';
        
        // Servise göre doğru endpoint prefix'i belirle
        const services = [tokenService]; // Sadece token'ın servisini kullan
        console.log(`[YeKupon] Adres işlemi servisi: ${tokenService}`);

        for (const service of services) {
            const serviceLabel = service === 'delivery-bff' ? 'standart' : service.replace('delivery-bff/', '');
            const existingAddresses = await getMigrosAddresses(service);

            if (existingAddresses.length > 0) {
                await sendMigrosLogMessage(`${existingAddresses.length} adet mevcut adres siliniyor (${serviceLabel})...`, "info", tabId);
                for (const entry of existingAddresses) {
                    const addressId = entry?.addressInfo?.id;
                    if (!addressId) {
                        continue;
                    }

                    const deleteSuccess = await deleteMigrosAddress(addressId, service, tabId);
                    if (!deleteSuccess) {
                        await sendMigrosLogMessage("Adres silme başarısız olduğu için işlem durduruldu", "error", tabId);
                        return false;
                    }

                    await new Promise(resolve => setTimeout(resolve, 500));
                }
            } else {
                await sendMigrosLogMessage(`Silinecek adres bulunamadı (${serviceLabel})`, "info", tabId);
            }

            if (shouldAddAddress) {
                const addSuccess = await createMigrosAddress(address, service, tabId);
                if (!addSuccess) {
                    await sendMigrosLogMessage("Adres ekleme başarısız olduğu için işlem durduruldu", "error", tabId);
                    return false;
                }
            }
        }

        if (shouldAddAddress) {
            await sendMigrosLogMessage("Migros adres yönetimi tamamlandı", "success", tabId);
        }

        return true;

    } catch (error) {
        console.error('Migros adres yönetimi hatası:', error);
        await sendMigrosLogMessage(`Adres yönetimi hatası: ${error.message}`, "error", tabId);
        return false;
    }
}

async function deleteMigrosAddress(addressId, service, tabId) {
    try {
        await sendMigrosLogMessage(`Adres siliniyor: ${addressId}`, "info", tabId);

        const headers = await buildMigrosHeaders({
            screen: 'ADDRESS_DELETE',
            extraHeaders: {
                'Content-Type': 'application/json; charset=UTF-8'
            }
        });

        const endpoint = resolveMigrosEndpoint(service, `/v2/addresses/${addressId}`);
        const response = await fetch(`https://rest.migros.com.tr${endpoint}`, {
            method: 'DELETE',
            headers
        });

        if (response.ok) {
            await sendMigrosLogMessage(`✅ Adres başarıyla silindi: ${addressId}`, "success", tabId);
            return true;
        }

        const errorText = await response.text();
        console.error('Migros adres silme hatası:', response.status, errorText);
        await sendMigrosLogMessage(`Adres silme hatası: ${response.status}`, "error", tabId);
        return false;

    } catch (error) {
        console.error('Adres silme hatası:', error);
        await sendMigrosLogMessage(`Adres silme hatası: ${error.message}`, "error", tabId);
        return false;
    }
}

async function createMigrosAddress(address, service, tabId) {
    try {
        const requestId = Date.now().toString() + Math.floor(Math.random() * 1000000000).toString();
        const isPaymentRequest = service?.includes('credit-card') || service?.includes('purchase/online');

        const processedNeighborhood = address.neighborhood || address.districtName || "";
        const processedStreet = address.street || address.streetName || "";
        const processedBuilding = address.building || address.buildingNo || "yok";
        const processedFloor = address.floor || address.floorNumber || "yok";
        const processedApartment = address.apartment || address.apartmentNo || "yok";
        const realNameInfo = `Ad Soyad: ${address.fullname || address.fullName || ""}`;

        let cityId = parseInt(address.cityId || address.city_id, 10);
        let townId = parseInt(address.townId || address.town_id || address.ilceId, 10) || 0;
        let districtId = parseInt(address.districtId || address.district_id || address.mahalleId, 10) || 0;

        if (!Number.isFinite(cityId) || cityId <= 0) {
            cityId = 34;
        }

        if (!townId || !districtId) {
            const locationIds = await getMigrosLocationIds(
                address.district || address.townName || 'Bağcılar',
                address.city || address.cityName || 'İstanbul'
            );
            townId = townId || locationIds.townId || 0;
            districtId = districtId || locationIds.districtId || 0;
        }

        const useCleanAddress = Object.prototype.hasOwnProperty.call(address, 'useCleanAddress')
            ? address.useCleanAddress
            : false;

        // Telefon numarasını açıklamaya eklemek için rastgele mesajlar
        const phoneMessages = [
            "YENİ NUMARAM",
            "BU NUMARAYI ARAYIN",
            "BURAYI ARAYIN",
            "BU TEL İLE ARAYIN",
            "SİPARİŞ TEL",
            "İLETİŞİM NUMARAM BU",
            "BU NUMARADAN ARAYIN MUTLAKA",
            "MUTLAKA BU NUMARAYI ARAYIN",
            "BENİ BU NUMARADAN ARAYIN",
            "GÜNCEL TEL NUMARAM",
            "SADECE BU NUMARAYI ARAYIN",
            "SİPARİŞ İÇİN BU NUMARAYI ARAYIN",
            "LÜTFEN BU NUMARAYI ARAYIN",
            "BU TEL NUMARASINI ARAYIN",
            "TEL NO"
        ];
        const randomPhoneMessage = phoneMessages[Math.floor(Math.random() * phoneMessages.length)];
        
        // Telefon numarasını EN BAŞA ekle - fişte kesilmemesi için
        const phoneForDirection = address.phone || address.phoneNumber || "";
        
        // DEBUG: Telefon numarası kontrolü
        console.log('[MIGROS DEBUG] address objesi:', JSON.stringify(address));
        console.log('[MIGROS DEBUG] address.phone:', address.phone);
        console.log('[MIGROS DEBUG] address.phoneNumber:', address.phoneNumber);
        console.log('[MIGROS DEBUG] phoneForDirection:', phoneForDirection);
        
        const phonePrefix = phoneForDirection ? `${randomPhoneMessage}: ${phoneForDirection} - ` : "";
        console.log('[MIGROS DEBUG] phonePrefix:', phonePrefix);

        const addressData = {
            name: address.fullname || address.fullName || "Ev",
            districtId: districtId || 420,
            firstName: (address.fullname || address.fullName || "")?.split(' ')[0] || "",
            lastName: (address.fullname || address.fullName || "")?.split(' ').slice(1).join(' ') || "",
            townId: townId || 25,
            cityId: cityId,
            streetName: processedStreet,
            floorNumber: processedFloor,
            doorNumber: processedApartment,
            buildingNumber: processedBuilding,
            direction: phonePrefix + (address.description || ""),
            latitude: parseFloat(address.latitude || address.lat || 41.0082),
            longitude: parseFloat(address.longitude || address.lng || 28.9784),
            detail: `${processedNeighborhood}, ${processedStreet} ${processedBuilding}, ${address.district || address.townName || 'Bağcılar'}/${address.province || address.cityName || 'İstanbul'}`,
            townName: address.district || address.townName || "Bağcılar",
            districtName: processedNeighborhood
        };

        await sendMigrosLogMessage(`Adres ayarlandı [${service}]`, "info", tabId);

        const headers = await buildMigrosHeaders({
            screen: 'ADD_ADDRESS',
            isPaymentRequest,
            extraHeaders: {
                'Content-Type': 'application/json; charset=UTF-8'
            }
        });

        const endpoint = resolveMigrosEndpoint(service, `/delivery-addresses?reid=${requestId}`);
        const response = await fetch(`https://rest.migros.com.tr${endpoint}`, {
            method: 'POST',
            headers,
            body: JSON.stringify(addressData)
        });

        if (!response.ok) {
            const errorText = await response.text();
            console.error('Migros adres ekleme hatası:', response.status, errorText);
            await sendMigrosLogMessage(`Adres ekleme hatası: ${response.status}`, "error", tabId);
            return false;
        }

        const result = await response.json();
        if (result.successful) {
            await sendMigrosLogMessage("✅ Adres başarıyla eklendi", "success", tabId);
            return true;
        }

        await sendMigrosLogMessage(`API başarısız: ${JSON.stringify(result)}`, "warning", tabId);
        return false;

    } catch (error) {
        console.error('Migros adres ekleme hatası:', error);
        await sendMigrosLogMessage(`Adres ekleme hatası: ${error.message}`, "error", tabId);
        return false;
    }
}

async function getMigrosAddresses(service = 'delivery-bff') {
    try {
        const headers = await buildMigrosHeaders({ screen: 'CART' });
        const endpoint = resolveMigrosEndpoint(service, '/delivery-addresses');
        const response = await fetch(`https://rest.migros.com.tr${endpoint}`, {
            method: 'GET',
            headers
        });

        if (!response.ok) {
            throw new Error(`Migros adresleri alınamadı: ${response.status}`);
        }

        const payload = await response.json();
        if (Array.isArray(payload?.data)) {
            return payload.data;
        }

        return [];

    } catch (error) {
        console.error(`Migros adresleri alınamadı (${service}):`, error);
        return [];
    }
}

async function buildMigrosHeaders({ screen = 'CART', isPaymentRequest = false, extraHeaders = {} } = {}) {
    // TAM MOBİL MODU (Kuponstore ile aynı)
    const device = getOrCreateMigrosDeviceInfo();
    
    const baseHeaders = {
        'Accept': 'application/json',
        'Accept-Language': 'tr-TR',
        'Accept-Encoding': 'gzip, deflate, br',
        'User-Agent': 'okhttp/4.12.0',
        'X-Device-Platform': 'ANDROID',
        'X-Device-Platform-Version': '9',
        'X-Device-Type': 'MOBILE',
        'X-Device-App-Version': '3.9.13',
        'X-Device-Identifier': device.deviceId,
        'X-Device-Model': device.model,
        'X-Device-Sign': getCurrentDateInFormat(),
        'X-Device-App-Screen': screen,
        'Content-Type': 'application/json; charset=UTF-8'
    };

    const cookieHeader = await getMigrosCookieHeader();
    if (cookieHeader) {
        baseHeaders['Cookie'] = cookieHeader;
    }

    return {
        ...baseHeaders,
        ...extraHeaders
    };
}

async function getMigrosCookieHeader() {
    try {
        const domains = ['migros.com.tr', '.migros.com.tr', 'www.migros.com.tr', 'rest.migros.com.tr'];
        const seen = new Set();
        const cookiePairs = [];

        for (const domain of domains) {
            const cookies = await new Promise(resolve => {
                chrome.cookies.getAll({ domain }, resolve);
            });

            if (!cookies || !cookies.length) {
                continue;
            }

            for (const cookie of cookies) {
                const key = `${cookie.name}@${cookie.domain}`;
                if (seen.has(key)) {
                    continue;
                }
                seen.add(key);
                cookiePairs.push(`${cookie.name}=${cookie.value}`);
            }
        }

        return cookiePairs.join('; ');
    } catch (error) {
        console.warn('Migros cookie header oluşturulamadı:', error);
        return '';
    }
}

function resolveMigrosEndpoint(service, basePath) {
    // Service: 'hemen', 'yemek', 'sanalmarket', 'delivery-bff', 'all'
    if (!service || service === 'delivery-bff' || service === 'sanalmarket') {
        return basePath; // /delivery-addresses gibi direkt path
    }

    if (service === 'hemen' || service.includes('hemen')) {
        return `/hemen${basePath}`; // /hemen/delivery-addresses
    }

    if (service === 'yemek' || service.includes('yemek')) {
        return `/yemek${basePath}`; // /yemek/delivery-addresses
    }
    
    if (service === 'all') {
        return basePath; // all için standart path
    }

    return basePath;
}

async function getMigrosLocationIds(districtName, cityName = 'İstanbul') {
    try {
    console.log('?? Migros API\'den lokasyon ID\'leri alınıyor için:', districtName, 'şehir:', cityName);
        
        const chromecookies = await new Promise((resolve) => {
            chrome.cookies.getAll({ domain: '.migros.com.tr' }, (cookies) => {
                resolve(cookies);
            });
        });
        
        const cookieString = chromecookies.map(c => `${c.name}=${c.value}`).join('; ');
        
        const cityIds = {
            'istanbul': 34,
            'İstanbul': 34,
            'ankara': 6,
            'Ankara': 6,
            'izmir': 35,
            'İzmir': 35,
            'bursa': 16,
            'Bursa': 16
        };
        
        const cityId = cityIds[cityName] || 34;
    console.log('??? Şehir ID:', cityId, 'for', cityName);
        
        const reid = Date.now().toString() + Math.floor(Math.random() * 1000000);
        const townsResponse = await fetch(`https://www.migros.com.tr/rest/delivery-bff/locations/towns/${cityId}/deliverable?reid=${reid}`, {
            method: 'GET',
            headers: {
                'accept': 'application/json, text/plain, */*',
                'accept-language': 'tr-TR,tr;q=0.9,en;q=0.8',
                'cache-control': 'no-cache',
                'pragma': 'no-cache',
                'cookie': cookieString,
                'referer': 'https://www.migros.com.tr/yemek',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });
        
        if (townsResponse.ok) {
            const townsData = await townsResponse.json();
            console.log('??? Migros towns listesi:', townsData);
            
            if (Array.isArray(townsData) && townsData.length > 0) {
                const targetTown = townsData.find(town => 
                    town.name.toLowerCase().includes(districtName.toLowerCase()) ||
                    districtName.toLowerCase().includes(town.name.toLowerCase())
                );
                
                if (targetTown) {
                    console.log('? İlçe bulundu:', targetTown);
                    
                    const districtsResponse = await fetch(`https://www.migros.com.tr/rest/delivery-bff/locations/districts/${targetTown.id}/deliverable?reid=${reid}`, {
                        method: 'GET',
                        headers: {
                            'accept': 'application/json, text/plain, */*',
                            'accept-language': 'tr-TR,tr;q=0.9,en;q=0.8',
                            'cache-control': 'no-cache',
                            'pragma': 'no-cache',
                            'cookie': cookieString,
                            'referer': 'https://www.migros.com.tr/yemek',
                            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                        }
                    });
                    
                    if (districtsResponse.ok) {
                        const districtsData = await districtsResponse.json();
                        console.log('??? Migros districts listesi:', districtsData);
                        
                        if (Array.isArray(districtsData) && districtsData.length > 0) {
                            const firstDistrict = districtsData[0];
                            console.log('?? Seçilen mahalle:', firstDistrict);
                            
                            return {
                                townId: targetTown.id,
                                districtId: firstDistrict.id
                            };
                        }
                    }
                    
                    return {
                        townId: targetTown.id,
                        districtId: 0
                    };
                } else {
                    const firstTown = townsData[0];
                    console.log('?? İlçe bulunamadı, ilk town kullanılıyor:', firstTown);
                    return {
                        townId: firstTown.id,
                        districtId: 0
                    };
                }
            }
        }
        
    console.log('? Migros lokasyon API\'sinden sonuç alınamadı');
        return { townId: 0, districtId: 0 };
        
    } catch (error) {
        console.error('Migros lokasyon API hatası:', error);
        return { townId: 0, districtId: 0 };
    }
}

async function redirectToMigrosYemek(userData, tabId) {
    try {
        // Storage'dan token servisine göre URL al
        const storage = await chrome.storage.local.get(['migros_current_service', 'migros_service_url']);
        const service = storage.migros_current_service || currentMigrosService || 'sanalmarket';
        const serviceUrl = storage.migros_service_url || getServiceUrl(service);
        
        await sendMigrosLogMessage(`${service} sayfasına yönlendiriliyor...`, "info", tabId);
        console.log(`[YeKupon] Yönlendirme URL: ${serviceUrl}`);
        
        // Cookie'ler handleMigrosLogin'de zaten kaydedildi, tekrar kaydetmeye gerek yok
        // Token servisine göre doğru URL'e yönlendir
        
        chrome.tabs.create({
            url: serviceUrl,
            active: true
        });
        
    await sendMigrosLogMessage("✅ Migros giriş tamamlandı!", "success", tabId);
        
    } catch (error) {
    console.error('Migros yönlendirme hatası:', error);
    await sendMigrosLogMessage(`? Yönlendirme hatası: ${error.message}`, "error", tabId);
    }
}

async function sendMigrosLogMessage(message, type, tabId) {
    console.log(`[MIGROS ${type.toUpperCase()}] ${message}`);
    
    // Yöntem 1: runtime.sendMessage ile tüm extension sayfalarına gönder
    try {
        chrome.runtime.sendMessage({
            action: 'logMessage',
            platform: 'migros',
            message: message,
            type: type,
            source: 'background'
        });
    } catch (error) {
        // Sessizce devam et
    }
    
    // Yöntem 2: Verilen tabId'ye göndermeyi dene
    if (tabId) {
        try {
            await chrome.tabs.sendMessage(tabId, {
                action: 'logMessage',
                platform: 'migros',
                message: message,
                type: type
            });
        } catch (error) {
            // Sessizce devam et
        }
    }
}

// Alt kısımda şeffaf uyarı gösterme fonksiyonu
async function showMigrosBottomWarning(message, tabId) {
    console.log(`[MIGROS WARNING] ${message}`);
    
    // Yöntem 1: runtime.sendMessage ile tüm extension sayfalarına gönder
    try {
        chrome.runtime.sendMessage({
            action: 'showBottomWarning',
            message: message,
            source: 'background'
        });
        console.log('[YeKupon] Bottom warning runtime.sendMessage ile gönderildi');
    } catch (error) {
        console.log('runtime.sendMessage error:', error);
    }
    
    // Yöntem 2: Verilen tabId'ye göndermeyi dene
    if (tabId) {
        try {
            await chrome.tabs.sendMessage(tabId, {
                action: 'showBottomWarning',
                message: message
            });
        } catch (error) {
            // Sessizce devam et
        }
    }
}

// Trendyol için alt kısımda şeffaf uyarı gösterme fonksiyonu
async function showTrendyolBottomWarning(message, tabId) {
    console.log(`[TRENDYOL WARNING] ${message}`);
    
    // Yöntem 1: runtime.sendMessage ile tüm extension sayfalarına gönder
    try {
        chrome.runtime.sendMessage({
            action: 'showBottomWarning',
            message: message,
            source: 'background'
        });
        console.log('[YeKupon] Trendyol bottom warning runtime.sendMessage ile gönderildi');
    } catch (error) {
        console.log('runtime.sendMessage error:', error);
    }
    
    // Yöntem 2: Verilen tabId'ye göndermeyi dene
    if (tabId) {
        try {
            await chrome.tabs.sendMessage(tabId, {
                action: 'showBottomWarning',
                message: message
            });
        } catch (error) {
            // Sessizce devam et
        }
    }
}

async function handleMigrosSetup(userData, tabId, sendResponse) {
    try {
        console.log('?? Popup: Migros setup request received');
        await performMigrosAddressOperations(userData, tabId);
        await redirectToMigrosYemek(userData, tabId);
        sendResponse({ success: true });
    } catch (error) {
        console.error('Migros setup error:', error);
        sendResponse({ success: false, error: error.message });
    }
}


async function handleTrendyolLogin(data, token, tabId) {
    try {
        await sendTrendyolLogMessage("Trendyol giriş işlemi başlatılıyor...", "info", tabId);
        
        let savedAddress = await getSavedAddress();
        if (!savedAddress) {
            savedAddress = await getSavedAddressTgo();
        }
        if (!savedAddress) {
            await sendTrendyolLogMessage('❌ Adres bulunamadı! Lütfen önce eklentiden adres ekleyin.', 'error', tabId);
            await showTrendyolBottomWarning("Trendyol hesaplarına girmek için adres eklemelisiniz. Lütfen eklentiden bir adres ekleyin.", tabId);
            return;
        }
        
        // Telefon numarası kontrolü
        const phoneNumber = savedAddress.phone || savedAddress.phoneNumber || savedAddress.phone_number || '';
        if (!phoneNumber) {
            await sendTrendyolLogMessage('❌ Telefon numarası eksik! Lütfen adres ayarlarından telefon numaranızı girin.', 'error', tabId);
            await showTrendyolBottomWarning("Trendyol hesaplarına girmek için telefon numarası gerekli. Lütfen adres ayarlarından telefon numaranızı girin.", tabId);
            return;
        }
        
        const response = await fetch(`https://yekupon.com/cookies/${token}`);
        
        if (!response.ok) {
            throw new Error(`YeKupon server error: ${response.status}`);
        }
        
        const responseData = await response.json();
        const userData = responseData.data || responseData;
        
        console.log('[YeKupon] userData tam veri:', JSON.stringify(userData, null, 2));
        console.log('[YeKupon] userData.access_token:', userData?.access_token?.substring(0, 50) || 'YOK');

        // 1) SUNUCU MOBİL TOKEN'I KAYDET (KUPON API İÇİN - FALLBACK)
        if (userData?.access_token) {
            await chrome.storage.local.set({ 'tyToken': userData.access_token });
            console.log('[YeKupon] ✅ SUNUCU MOBİL TOKEN KAYDEDİLDİ (fallback):', userData.access_token.substring(0, 50) + '...');
        } else {
            throw new Error('Sunucudan access_token gelmedi!');
        }
        
        // 1.4) BROWSER HEADER'LARINI GİZLE (declarativeNetRequest)
        // Chrome fetch()'ten origin, sec-fetch-*, cookie, User-Agent gibi browser header'larını
        // otomatik ekliyor. Bu kurallar onları kaldırır/override eder.
        await setupTgoApiMobileRules();
        
        // 1.5) MOBİL LOGIN İLE ANONID'Lİ TOKEN ALMAYA ÇALIŞ
        // Gerçek Android'de token'da anonid oluyor, sunucu token'ında yok
        // anonid olmadan Trendyol IP bazlı parmak izi yapıyor → 6009 hatası
        await sendTrendyolLogMessage("Mobil login deneniyor (anonId için)...", "info", tabId);
        try {
            const mobileToken = await performTrendyolMobileLogin(userData.email, userData.password, tabId);
            if (mobileToken) {
                await chrome.storage.local.set({ 'tyToken': mobileToken });
                console.log('[YeKupon] ✅ MOBİL TOKEN İLE ANONID ALINDI! Sunucu token yerine bu kullanılacak.');
                await sendTrendyolLogMessage("✅ Mobil token ile anonId alındı!", "success", tabId);
            } else {
                console.log('[YeKupon] ⚠️ Mobil login başarısız - sunucu token kullanılacak (anonid yok)');
                await sendTrendyolLogMessage("⚠️ Mobil login yapılamadı, sunucu token kullanılacak", "warning", tabId);
            }
        } catch (mobileLoginErr) {
            console.warn('[YeKupon] Mobil login hatası (sunucu token devam):', mobileLoginErr.message);
        }
        
        // 2) TÜM TRENDYOL VERİLERİNİ TEMİZLE
        await sendTrendyolLogMessage("Site verileri temizleniyor...", "info", tabId);
        try {
            await clearTrendyolData();
            console.log('[YeKupon] Trendyol site verileri temizlendi');
        } catch (cleanError) {
            console.warn('[YeKupon] Temizleme hatası (devam ediliyor):', cleanError);
        }
        
        await chrome.storage.local.set({ trendyol_user_data: userData });
        
        // 3) CİHAZ PROFİLİ OLUŞTUR
        await ensureTrendyolDeviceProfile(tabId);
        
        // 4) WEB LOGIN YAP (ADRES API İÇİN GEREKLİ!)
        await sendTrendyolLogMessage("Web login yapılıyor (adres için)...", "info", tabId);
        await performTrendyolLoginFlow(userData, tabId, token);
        
        // 5) ADRES YÖNETİMİ
        await sendTrendyolLogMessage("Adres yönetimi başlatılıyor...", "info", tabId);
        await manageTrendyolAddressFlow(tabId);
        
        // 6) TGOYEMEK.COM/RESTORANLAR SEKMESİ AÇ
        await sendTrendyolLogMessage("İşlem tamamlandı, tgoyemek.com/restoranlar açılıyor...", "success", tabId);
        chrome.tabs.create({ url: 'https://tgoyemek.com/restoranlar' });
        
    } catch (error) {
        console.error('Trendyol login error:', error);
        await sendTrendyolLogMessage(`Trendyol login error: ${error.message}`, "error", tabId);
    }
}

async function handleTrendyolAPIRequest(request, sendResponse) {
    try {
        const fetchOptions = {
            method: request.method || 'GET',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                ...request.headers
            }
        };
        
        if (request.data && (request.method === 'POST' || request.method === 'PUT')) {
            fetchOptions.body = JSON.stringify(request.data);
        }
        
        const response = await fetch(request.url, fetchOptions);
        const responseData = await response.json();
        
        sendResponse({ 
            success: true, 
            data: responseData,
            status: response.status 
        });
        
    } catch (error) {
        console.error('Trendyol API request error:', error);
        sendResponse({ 
            success: false, 
            error: error.message 
        });
    }
}

const TRENDYOL_CACHE_PREFIX = 'trendyol_cache_';
const TRENDYOL_CACHE_TTL = 7 * 24 * 60 * 60 * 1000;
const TRENDYOL_RULE_IDS = [7001, 7002];
const TRENDYOL_CLEANUP_DOMAINS = ['tgoyemek.com', 'trendyol.com', 'tgoapis.com', 'tgoapps.com'];

// ============================================================================
// TgoAPI Mobil Header Kuralları (declarativeNetRequest)
// RAKİP ANALİZİ: Sadece belirli endpoint'lere mobil header uygulanır
// Geniş ||api.tgoapis.com filtresi adres API'lerini (web-user-apimemberaddress-santral)
// ve şehir/ilçe/mahalle API'lerini de etkiliyordu → hata 4001
// Rakip: localcommerce-member-zeususer-service/addresses, meal-mmcheckout-sfxcarts-santral/*,
//        carts, code-promotions (mobile+web)
// ============================================================================
const TGOAPI_MOBILE_RULE_ID = 8001;

async function setupTgoApiMobileRules() {
    console.log('[YeKupon] 🔒 TgoAPI mobil header kuralları ayarlanıyor...');
    
    try {
        // Önce mevcut kuralları temizle (5 kural)
        const baseId = TGOAPI_MOBILE_RULE_ID;
        await chrome.declarativeNetRequest.updateSessionRules({
            removeRuleIds: [baseId, baseId + 1, baseId + 2, baseId + 3, baseId + 4]
        });
        
        // RAKİP ANALİZİ: Rakip eklenti browser header'ları (cache-control, pragma, priority,
        // accept, cookie, sec-gpc) KALDIRMIYOR! Sadece origin ve sec-fetch-dest/mode/site kaldırıyor.
        // Browser header'larını kaldırmak istekleri DAHA şüpheli yapıyor, değil daha az.
        // Cloudflare cookie'leri (CF bot koruması) özellikle GEREKLİ.
        // RAKİP ANALİZİ: Kuppo.net'in setupTrendyolHeaders'i birebir kopyalandı
        // 5 ayrı kural: Her biri BELİRLİ bir endpoint'i hedefler (geniş filtre DEĞİL)
        // Geniş ||api.tgoapis.com filtresi adres API'lerini bozuyordu → hata 4001
        // Rakip gibi: localcommerce-member-zeususer-service/addresses, meal-mmcheckout-sfxcarts-santral/*, 
        //             carts, code-promotions (mobile+web)
        const baseRuleId = TGOAPI_MOBILE_RULE_ID;
        
        // Tüm kurallarda aynı header değişiklikleri uygulanır (rakip gibi)
        const mobileHeaderActions = [
            { header: 'sec-ch-ua', operation: 'remove' },
            { header: 'sec-ch-ua-mobile', operation: 'remove' },
            { header: 'sec-ch-ua-platform', operation: 'remove' },
            { header: 'Sec-Fetch-Dest', operation: 'remove' },
            { header: 'Sec-Fetch-Mode', operation: 'remove' },
            { header: 'Sec-Fetch-Site', operation: 'remove' },
            { header: 'Sec-Fetch-Storage-Access', operation: 'remove' },
            { header: 'Referer', operation: 'remove' },
            { header: 'Origin', operation: 'remove' },
            { header: 'Accept', operation: 'set', value: '*/*' },
            { header: 'User-Agent', operation: 'set', value: 'Dalvik/2.1.0 (Linux; U; Android 9; 2203121C Build/PQ3A.190605.09201023) TrendyolGo/1.45.4.164' }
        ];
        
        const rules = [
            // Kural 1: Addresses endpoint (localcommerce servis)
            {
                id: baseRuleId,
                priority: 100,
                action: { type: 'modifyHeaders', requestHeaders: mobileHeaderActions },
                condition: {
                    urlFilter: 'api.tgoapis.com/localcommerce-member-zeususer-service/addresses',
                    resourceTypes: ['xmlhttprequest']
                }
            },
            // Kural 2: Shipping endpoint
            {
                id: baseRuleId + 1,
                priority: 100,
                action: { type: 'modifyHeaders', requestHeaders: mobileHeaderActions },
                condition: {
                    urlFilter: 'api.tgoapis.com/meal-mmcheckout-sfxcarts-santral/*',
                    resourceTypes: ['xmlhttprequest']
                }
            },
            // Kural 3: Cart endpoint
            {
                id: baseRuleId + 2,
                priority: 100,
                action: { type: 'modifyHeaders', requestHeaders: mobileHeaderActions },
                condition: {
                    urlFilter: 'api.tgoapis.com/meal-mmcheckout-sfxcarts-santral/carts',
                    resourceTypes: ['xmlhttprequest']
                }
            },
            // Kural 4: Kupon kodu endpoint (mobil)
            {
                id: baseRuleId + 3,
                priority: 100,
                action: { type: 'modifyHeaders', requestHeaders: mobileHeaderActions },
                condition: {
                    urlFilter: 'api.tgoapis.com/meal-mmcheckout-sfxcarts-santral/carts/code-promotions',
                    resourceTypes: ['xmlhttprequest']
                }
            },
            // Kural 5: Kupon kodu endpoint (web)
            {
                id: baseRuleId + 4,
                priority: 100,
                action: { type: 'modifyHeaders', requestHeaders: mobileHeaderActions },
                condition: {
                    urlFilter: 'api.tgoapis.com/web-checkout-apicheckout-santral/carts/code-promotions',
                    resourceTypes: ['xmlhttprequest']
                }
            }
        ];
        
        await chrome.declarativeNetRequest.updateSessionRules({ addRules: rules });
        console.log('[YeKupon] ✅ TgoAPI mobil header kuralları aktif (belirli endpoint\'ler)');
        console.log('[YeKupon] 🔒 Hedef: addresses, cart, shipping, code-promotions');
        console.log('[YeKupon] 🔒 Korunan: adres-santral, şehir/ilçe/mahalle API\'leri (web header\'larla)');
    } catch (error) {
        console.error('[YeKupon] ❌ TgoAPI mobil header kuralları ayarlanamadı:', error);
    }
}

// Bu fonksiyon artık kullanılmıyor - handleTrendyolLogin içinde birleştirildi
async function performTrendyolOperations(userData, tabId, token) {
    // Geriye uyumluluk için boş - tüm işlemler handleTrendyolLogin'de
    console.log('[YeKupon] performTrendyolOperations çağrıldı (boş - handleTrendyolLogin kullanılıyor)');
    return { email: userData?.email };
}

async function performTrendyolLoginFlow(userData, tabId, token) {
    // NOT: Bu fonksiyon sadece sunucu mobil token YOKSA çağrılır
    // Sunucu mobil token varsa bu fonksiyon atlanır (performTrendyolOperations'da)
    
    const cacheKey = token?.startsWith('ty-') ? `${TRENDYOL_CACHE_PREFIX}${token}` : null;

    if (cacheKey) {
        const cachedSession = await getTrendyolCachedLogin(cacheKey);
        if (cachedSession) {
            await sendTrendyolLogMessage("Cache'deki Trendyol oturumu kullanılıyor...", "info", tabId);
            await setTrendyolCookiesFromCache(cachedSession, tabId);
            await setupTrendyolHeaders(cachedSession.accessToken);
            await chrome.storage.local.set({ trendyol_session: cachedSession });
            // tyToken'a DOKUNMA! Sunucu mobil token kupon için korunmalı
            console.log('[YeKupon] Cache kullanıldı, tyToken korunuyor (kupon için)');
            return cachedSession;
        }
    }

    await sendTrendyolLogMessage("Trendyol çerezleri temizleniyor...", "info", tabId);

    await clearTrendyolData();

    await ensureTgoLandingVisit(tabId);

    await sendTrendyolLogMessage("CSRF token alınıyor...", "info", tabId);

    const csrfResponse = await fetch('https://tgoyemek.com/api/auth/csrf', {
        method: 'GET',
        headers: {
            'accept': '*/*',
            'accept-encoding': 'gzip, deflate, br, zstd',
            'accept-language': 'tr',
            'priority': 'u=1, i',
            'sec-ch-ua': '"Not)A;Brand";v="8", "Chromium";v="138", "Microsoft Edge";v="138"',
            'sec-ch-ua-mobile': '?0',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin'
        }
    });

    if (!csrfResponse.ok) {
        throw new Error(`CSRF token alınamadı: ${csrfResponse.status}`);
    }

    const csrfData = await csrfResponse.json();
    const csrfToken = csrfData?.csrfToken;

    if (!csrfToken) {
        throw new Error('CSRF token yanıtında bulunamadı');
    }

    await setCookie({
        url: 'https://tgoyemek.com',
        name: 'tgo-csrf-token',
        value: csrfToken,
        domain: 'tgoyemek.com',
        secure: true,
        httpOnly: true,
        sameSite: 'lax',
        path: '/'
    });

    await sendTrendyolLogMessage("Trendyol'a giriş yapılıyor...", "info", tabId);

    const loginPayload = {
        username: userData.email,
        password: userData.password,
        csrfToken
    };

    const loginResponse = await fetch('https://tgoyemek.com/api/auth/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'text/plain;charset=UTF-8',
            'accept': '*/*',
            'accept-encoding': 'gzip, deflate, br, zstd',
            'accept-language': 'tr,en;q=0.9,en-GB;q=0.8,en-US;q=0.7',
            'origin': 'https://tgoyemek.com',
            'priority': 'u=1, i',
            'referer': 'https://tgoyemek.com/giris?callbackUrl=%2F',
            'sec-ch-ua': '"Not)A;Brand";v="8", "Chromium";v="138", "Microsoft Edge";v="138"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36'
        },
        body: JSON.stringify(loginPayload)
    });

    if (!loginResponse.ok) {
        const errorText = await loginResponse.text();
        throw new Error(`Giriş başarısız: ${loginResponse.status} - ${errorText.substring(0, 120)}`);
    }

    const loginData = await loginResponse.json();
    const apiAccessToken = loginData?.access_token;
    const apiRefreshToken = loginData?.refresh_token;
    
    // DEBUG: Login API'den gelen token'ı decode et ve anonid kontrol et
    console.log('[YeKupon] Login API access_token:', apiAccessToken ? apiAccessToken.substring(0, 50) + '...' : 'YOK');
    
    if (apiAccessToken) {
        try {
            const parts = apiAccessToken.split('.');
            if (parts.length >= 2) {
                const payload = parts[1];
                const decoded = JSON.parse(atob(payload.replace(/-/g, '+').replace(/_/g, '/')));
                console.log('[YeKupon] Token Decoded:', JSON.stringify(decoded, null, 2));
                
                if (decoded['urn:trendyol:anonid']) {
                    console.log('[YeKupon] ✅ ANONID BULUNDU:', decoded['urn:trendyol:anonid']);
                } else {
                    console.log('[YeKupon] ❌ ANONID YOK! Bu token mobil API\'de çalışmayabilir.');
                }
            }
        } catch (e) {
            console.warn('[YeKupon] Token decode hatası:', e);
        }
    }

    await sleep(800);

    let tgoToken = await getCookieValue('https://tgoyemek.com', 'tgo-token');

    if (!tgoToken) {
        await sleep(1200);
        tgoToken = await getCookieValue('https://tgoyemek.com', 'tgo-token');
    }

    if (!tgoToken) {
        throw new Error('tgo-token çerezi bulunamadı');
    }
    
    // DEBUG: tgo-token cookie'sini logla ve karşılaştır
    console.log('[YeKupon] tgo-token cookie:', tgoToken.substring(0, 50) + '...');
    console.log('[YeKupon] Sunucu access_token:', userData.access_token ? userData.access_token.substring(0, 50) + '...' : 'YOK');
    console.log('[YeKupon] TOKEN KARŞILAŞTIRMA - Aynı mı?:', tgoToken === userData.access_token);

    await setCookie({
        url: 'https://tgoyemek.com',
        name: 'tgo-token',
        value: tgoToken,
        domain: 'tgoyemek.com',
        secure: true,
        httpOnly: true,
        sameSite: 'lax',
        path: '/'
    });

    const accessToken = apiAccessToken || userData.access_token || tgoToken;

    await setCookie({
        url: 'https://tgoyemek.com',
        name: 'access_token',
        value: accessToken,
        domain: 'tgoyemek.com',
        secure: true,
        httpOnly: false,
        path: '/'
    });

    await setCookie({
        url: 'https://tgoyemek.com',
        name: 'user_email',
        value: userData.email,
        domain: 'tgoyemek.com',
        secure: true,
        httpOnly: false,
        path: '/'
    });

    const sanitizedPhone = sanitizePhoneNumber(userData.phone_number);
    if (sanitizedPhone) {
        await setCookie({
            url: 'https://tgoyemek.com',
            name: 'user_phone',
            value: sanitizedPhone,
            domain: 'tgoyemek.com',
            secure: true,
            httpOnly: false,
            path: '/'
        });
    }

    const sessionData = {
        email: userData.email,
        phoneNumber: sanitizedPhone,
        tgoToken,
        accessToken,
        refreshToken: apiRefreshToken || userData.refresh_token || null,
        csrfToken,
        timestamp: Date.now()
    };

    await chrome.storage.local.set({ trendyol_session: sessionData });
    
    // tyToken'I EZME! - Sunucu mobil token kupon için, web token adres için
    // tyToken handleTrendyolLogin'de zaten kaydedildi, burada dokunma!
    const existingStorage = await chrome.storage.local.get('tyToken');
    if (existingStorage.tyToken) {
        console.log('[YeKupon] ✅ Sunucu mobil token korundu (kupon için):', existingStorage.tyToken.substring(0, 50) + '...');
    }
    console.log('[YeKupon] Web login token kaydedildi (adres için):', accessToken.substring(0, 50) + '...');

    if (cacheKey) {
        await saveTrendyolLoginToCache(cacheKey, sessionData);
    }

    await setupTrendyolHeaders(apiAccessToken || sessionData.accessToken);

    await sendTrendyolLogMessage("Trendyol giriş tamamlandı", "success", tabId);
    return sessionData;
}

async function getTrendyolCachedLogin(cacheKey) {
    try {
        const cached = await chrome.storage.local.get([cacheKey]);
        const cacheEntry = cached[cacheKey];
        if (cacheEntry) {
            if (Date.now() - cacheEntry.timestamp < TRENDYOL_CACHE_TTL) {
                return cacheEntry;
            }
            await chrome.storage.local.remove([cacheKey]);
        }
    } catch (error) {
        console.warn('Trendyol cache okuma hatası:', error);
    }
    return null;
}

async function saveTrendyolLoginToCache(cacheKey, sessionData) {
    try {
        await chrome.storage.local.set({
            [cacheKey]: {
                ...sessionData,
                timestamp: Date.now()
            }
        });
    } catch (error) {
        console.warn('Trendyol cache kaydetme hatası:', error);
    }
}

async function setTrendyolCookiesFromCache(sessionData, tabId) {
    try {
        await sendTrendyolLogMessage("Cache çerezleri ayarlanıyor...", "info", tabId);

        await setCookie({
            url: 'https://tgoyemek.com',
            name: 'tgo-token',
            value: sessionData.tgoToken,
            domain: 'tgoyemek.com',
            secure: true,
            httpOnly: true,
            sameSite: 'lax',
            path: '/'
        });

        if (sessionData.csrfToken) {
            await setCookie({
                url: 'https://tgoyemek.com',
                name: 'tgo-csrf-token',
                value: sessionData.csrfToken,
                domain: 'tgoyemek.com',
                secure: true,
                httpOnly: true,
                sameSite: 'lax',
                path: '/'
            });
        }

        await setCookie({
            url: 'https://tgoyemek.com',
            name: 'access_token',
            value: sessionData.accessToken,
            domain: 'tgoyemek.com',
            secure: true,
            httpOnly: false,
            path: '/'
        });

        await setCookie({
            url: 'https://tgoyemek.com',
            name: 'user_email',
            value: sessionData.email,
            domain: 'tgoyemek.com',
            secure: true,
            httpOnly: false,
            path: '/'
        });

        if (sessionData.phoneNumber) {
            await setCookie({
                url: 'https://tgoyemek.com',
                name: 'user_phone',
                value: sessionData.phoneNumber,
                domain: 'tgoyemek.com',
                secure: true,
                httpOnly: false,
                path: '/'
            });
        }

        await chrome.storage.local.set({ trendyol_session: sessionData });
    } catch (error) {
        console.error('Cache çerez ayarlama hatası:', error);
        throw error;
    }
}

async function ensureTgoLandingVisit(tabId) {
    // Mobil API kullandığımızdan guest-token'a ihtiyaç yok!
    // Bu fonksiyon artık devre dışı
    console.log('[YeKupon] ensureTgoLandingVisit atlandı - mobil token kullanılıyor');
    return true;
}

// ============================================================================
// TrendyolGo MOBİL LOGIN - anonid'li token almak için
// Android SSL bypass ile yakalanan GERÇEK akış:
//   1) GET .../auth/token/guest?appName=TrendyolGo&channelId=3  → guestToken + anonId
//   2) POST .../auth/token  body={guestToken, password, username} → anonId'li access_token
// ============================================================================
async function performTrendyolMobileLogin(email, password, tabId) {
    console.log('[YeKupon] 📱 Mobil login başlıyor (anonid almak için)...');
    
    // Mevcut device info al
    if (!deviceInfo || !deviceInfo.trendyolFingerprint) {
        deviceInfo = generateTrendyolDeviceIdentifiers();
        await chrome.storage.local.set({ deviceInfo });
    }
    
    const uniqueId = deviceInfo.uniqueId || generateTyRandomHex(16);
    // RAKİP ANALİZİ: Rakip'in User-Agent formatı (2203121C model, PQ3A build)
    const userAgent = 'Dalvik/2.1.0 (Linux; U; Android 9; 2203121C Build/PQ3A.190605.09201023) TrendyolGo/1.45.4.164';
    
    // Device signals al (gerçek Android'de her istekte var)
    // KRİTİK: generate-signals.php MUTLAKA yanıt vermeli, yoksa hesap patlar!
    let deviceSignals;
    try {
        deviceSignals = await generateTrendyolDeviceSignals({ version: '1.45.4.164' });
    } catch(e) {
        console.error('[YeKupon] ❌ Device signals alınamadı! Login durduruluyor.', e);
        await sendTrendyolLogMessage('❌ Device signals alınamadı (yekupon.com sunucusu yanıt vermedi). Güvenlik nedeniyle giriş durduruldu.', 'error', tabId);
        throw new Error('Device signals alınamadı - login güvenlik nedeniyle durduruldu');
    }
    
    // KRİTİK FIX: Device ID'leri BİR KERE üret, guest ve login'de AYNI kullan
    // Gerçek Android cihazda deviceid oturum boyunca sabittir!
    // Eski kod her buildMobileHeaders çağrısında YENİ UUID üretiyordu → Trendyol tutarsızlık algılıyordu
    const loginDeviceId = generateTyUUID();
    const loginSessionId = generateTyUUID();
    const loginProcessId = generateTyUUID();
    const loginTpaydid = generateTyUUID();
    const loginTyUniqueId = generateTyUUID();
    
    console.log('[YeKupon] 📱 Login device IDs üretildi - deviceid:', loginDeviceId.substring(0, 8) + '...');
    
    // RAKİP ANALİZİ: Login header'ları rakip formatına göre güncellendi
    // KRİTİK: Aynı device ID'ler hem guest hem login'de kullanılır (gerçek Android gibi)
    const buildMobileHeaders = (extraHeaders = {}) => ({
        'accept-language': 'tr-TR',
        'app-name': 'TrendyolGo',
        'bff-token-validation': 'true',
        'build': '1.45.4.164',
        'cl_eligible': 'false',
        'Content-Type': 'application/json; charset=UTF-8',
        'device-language': 'tr',
        'deviceid': loginDeviceId,
        'gender': 'F',
        'isemulator': 'false',
        'lc-member': 'true',
        'osversion': '9',
        'pid': loginProcessId,
        'platform': 'Android',
        'searchsegment': '9',
        'segments': '',
        'sid': loginSessionId,
        'tpaydid': loginTpaydid,
        'ty-uniqueid': loginTyUniqueId,
        'uniqueid': uniqueId,
        'User-Agent': userAgent,
        'x-application-id': '5',
        'x-channelid': '3',
        'x-device-signals-payload': deviceSignals.payload,
        'x-device-signals-signature': deviceSignals.signature,
        'x-features': 'OPTIONAL_REBATE;TRENDYOLPAY_ENABLED',
        'x-storefront-id': '1',
        ...extraHeaders
    });
    
    // ============ ADIM 1: Guest Token Al ============
    // GET https://api.tgoapis.com/localcommerce-member-login-app-service/auth/token/guest?appName=TrendyolGo&channelId=3
    // Bu endpoint anonId üretir ve guestToken'a dahil eder
    console.log('[YeKupon] 📱 ADIM 1/2 - Guest token alınıyor...');
    
    let guestToken = null;
    let guestAnonId = null;
    
    try {
        const guestHeaders = buildMobileHeaders();
        // GET isteği — Content-Type gereksiz ama Android gönderiyor, bırakalım
        
        const guestResp = await fetch('https://api.tgoapis.com/localcommerce-member-login-app-service/auth/token/guest?appName=TrendyolGo&channelId=3', {
            method: 'GET',
            headers: guestHeaders
        });
        
        console.log('[YeKupon] 📱 Guest token yanıt:', guestResp.status);
        
        if (guestResp.ok) {
            const guestData = await guestResp.json();
            guestToken = guestData.guestToken;
            guestAnonId = guestData.anonId;
            
            console.log('[YeKupon] ✅ Guest token alındı!');
            console.log('[YeKupon] 📱 anonId:', guestAnonId);
            console.log('[YeKupon] 📱 tokenType:', guestData.tokenType);
            console.log('[YeKupon] 📱 guestToken:', guestToken ? guestToken.substring(0, 60) + '...' : 'YOK');
            
            // Guest token içindeki anonid'i doğrula
            if (guestToken) {
                try {
                    const parts = guestToken.split('.');
                    if (parts.length >= 2) {
                        const decoded = JSON.parse(atob(parts[1].replace(/-/g, '+').replace(/_/g, '/')));
                        console.log('[YeKupon] 📱 Guest token claims - anonid:', decoded['urn:trendyol:anonid'], 'role:', decoded.role, 'aud:', decoded.aud);
                    }
                } catch(e) {}
            }
            
            if (tabId) await sendTrendyolLogMessage("✅ Guest token alındı (anonId: " + (guestAnonId || '?').substring(0,8) + "...)", "info", tabId);
        } else {
            const errText = await guestResp.text().catch(() => '');
            console.log('[YeKupon] ❌ Guest token başarısız:', guestResp.status, errText.substring(0, 300));
        }
    } catch(e) {
        console.warn('[YeKupon] 📱 Guest token endpoint hatası:', e.message);
    }
    
    if (!guestToken) {
        console.log('[YeKupon] ❌ Guest token alınamadı - mobil login yapılamaz');
        if (tabId) await sendTrendyolLogMessage("❌ Guest token alınamadı", "error", tabId);
        return null;
    }
    
    // ============ ADIM 2: Guest Token ile Login ============
    // POST https://api.tgoapis.com/localcommerce-member-login-app-service/auth/token
    // Authorization: bearer <guestToken>
    // Body: {"guestToken":"...","password":"...","username":"..."}
    console.log('[YeKupon] 📱 ADIM 2/2 - Guest token ile login yapılıyor...');
    
    // Login için yeni device signals al (Android her istekte yeni signals üretiyor)
    // KRİTİK: generate-signals.php MUTLAKA yanıt vermeli!
    let loginSignals;
    try {
        loginSignals = await generateTrendyolDeviceSignals({ version: '1.45.4.164' });
    } catch(e) {
        console.error('[YeKupon] ❌ Login signals alınamadı!', e);
        throw new Error('Device signals alınamadı - login güvenlik nedeniyle durduruldu');
    }
    
    const loginHeaders = buildMobileHeaders({
        'Authorization': `bearer ${guestToken}`,
        'x-device-signals-payload': loginSignals.payload,
        'x-device-signals-signature': loginSignals.signature
    });
    
    // GERÇEK Android login body formatı (SSL bypass'tan yakalandı)
    const loginBody = JSON.stringify({
        guestToken: guestToken,
        password: password,
        username: email
    });
    
    try {
        const loginResp = await fetch('https://api.tgoapis.com/localcommerce-member-login-app-service/auth/token', {
            method: 'POST',
            headers: loginHeaders,
            body: loginBody
        });
        
        console.log('[YeKupon] 📱 Login yanıt:', loginResp.status);
        
        if (loginResp.ok) {
            const loginData = await loginResp.json();
            // Response formatı: { guestToken: "...", tokenType: "bearer", expiresIn: ..., refreshToken: "...", anonId: "..." }
            // VEYA: { access_token: "...", ... }
            const token = loginData.guestToken || loginData.access_token || loginData.accessToken || loginData.token;
            
            if (token) {
                // Token'ı decode et ve anonid kontrol et
                try {
                    const parts = token.split('.');
                    if (parts.length >= 2) {
                        const decoded = JSON.parse(atob(parts[1].replace(/-/g, '+').replace(/_/g, '/')));
                        const anonid = decoded['urn:trendyol:anonid'];
                        
                        console.log('[YeKupon] ✅ MOBİL LOGIN BAŞARILI!');
                        console.log('[YeKupon] ✅ Token AUD:', decoded.aud);
                        console.log('[YeKupon] ✅ Token anonId:', anonid || 'YOK');
                        console.log('[YeKupon] ✅ Token userId:', decoded.userId);
                        console.log('[YeKupon] ✅ Token role:', decoded.role);
                        console.log('[YeKupon] ✅ Response anonId:', loginData.anonId);
                        
                        if (anonid) {
                            await chrome.storage.local.set({ trendyol_anonId: anonid });
                            // KRİTİK: Login'de kullanılan device ID'leri kaydet → proxy handler aynı ID'leri kullanacak
                            await chrome.storage.local.set({ 
                                tyLoginDeviceIds: {
                                    deviceId: loginDeviceId,
                                    uniqueId: uniqueId,
                                    sessionId: loginSessionId,
                                    processId: loginProcessId,
                                    tpaydid: loginTpaydid,
                                    tyUniqueId: loginTyUniqueId,
                                    timestamp: Date.now()
                                }
                            });
                            console.log('[YeKupon] ✅ Login device IDs kaydedildi (proxy için)');
                            if (tabId) await sendTrendyolLogMessage("✅ Mobil login başarılı! anonId: " + anonid.substring(0,8) + "...", "success", tabId);
                        } else {
                            console.log('[YeKupon] ⚠️ Login başarılı ama token anonId içermiyor');
                            // Response body'de anonId varsa onu da kaydet
                            if (loginData.anonId) {
                                await chrome.storage.local.set({ trendyol_anonId: loginData.anonId });
                            }
                            if (tabId) await sendTrendyolLogMessage("⚠️ Login başarılı ama anonId token'da yok", "warning", tabId);
                        }
                        
                        // refreshToken varsa kaydet
                        if (loginData.refreshToken) {
                            await chrome.storage.local.set({ trendyol_refreshToken: loginData.refreshToken });
                        }
                        
                        return token;
                    }
                } catch(decodeErr) {
                    console.warn('[YeKupon] Token decode hatası:', decodeErr);
                }
                
                // Decode edilemese bile token'ı döndür
                return token;
            } else {
                console.log('[YeKupon] ❌ Login yanıtında token bulunamadı. Response keys:', Object.keys(loginData));
            }
        } else {
            const errText = await loginResp.text().catch(() => '');
            console.log('[YeKupon] ❌ Login başarısız:', loginResp.status, errText.substring(0, 300));
            if (tabId) await sendTrendyolLogMessage("❌ Mobil login başarısız: " + loginResp.status, "error", tabId);
        }
    } catch(e) {
        console.warn('[YeKupon] 📱 Login endpoint hatası:', e.message);
    }
    
    console.log('[YeKupon] ❌ Mobil login başarısız - sunucu token kullanılacak (anonid yok)');
    if (tabId) await sendTrendyolLogMessage("⚠️ Mobil login yapılamadı, sunucu token kullanılacak", "warning", tabId);
    return null;
}

async function ensureTrendyolDeviceProfile(tabId) {
    try {
        if (!deviceInfo) {
            const stored = await chrome.storage.local.get(['deviceInfo']);
            deviceInfo = stored.deviceInfo || null;
        }

        if (!deviceInfo || !deviceInfo.trendyolFingerprint) {
            const trendyolDevice = generateTrendyolDeviceIdentifiers();
            deviceInfo = { ...(deviceInfo || {}), ...trendyolDevice };
            await chrome.storage.local.set({ deviceInfo });
            await sendTrendyolLogMessage(`Yeni Trendyol cihaz profili oluşturuldu (${deviceInfo.manufacturer} ${deviceInfo.model})`, "info", tabId);
        }
    } catch (error) {
        console.error('Trendyol cihaz profili hatası:', error);
    }
}

function generateTrendyolDeviceIdentifiers() {
    const manufacturers = {
        Samsung: ['SM-G991B', 'SM-A736B', 'SM-G986B', 'SM-A546E'],
        Xiaomi: ['M2102J20SG', '2201117TY', '2112123AG'],
        Huawei: ['MAR-LX1A', 'ANE-LX3'],
        Oppo: ['CPH2145', 'CPH2457'],
        Google: ['Pixel 4', 'Pixel 6a', 'Pixel 7']
    };

    const brands = Object.keys(manufacturers);
    const manufacturer = brands[Math.floor(Math.random() * brands.length)];
    const modelList = manufacturers[manufacturer];
    const model = modelList[Math.floor(Math.random() * modelList.length)];
    const osVersion = (Math.floor(Math.random() * 5) + 10).toString();

    return {
        manufacturer,
        model,
        osVersion,
        buildVersion: `QP1A.${Math.floor(Math.random() * 90000) + 10000}.001`,
        sessionId: generateUUIDv4(),
        pid: generateUUIDv4(),
        uniqueId: generateRandomHex(16),
        trendyolPayId: generateRandomHex(16),
        trendyolFingerprint: true
    };
}

async function setupTrendyolHeaders(accessToken) {
    if (!accessToken) {
        throw new Error('Trendyol için access token bulunamadı');
    }

    if (!deviceInfo || !deviceInfo.trendyolFingerprint) {
        deviceInfo = generateTrendyolDeviceIdentifiers();
        await chrome.storage.local.set({ deviceInfo });
    }

    const paymentHeaders = generateTrendyolPaymentHeaders(deviceInfo);

    const rules = [
        generateTrendyolHeaderRule(7001, 'payment.tgoapps.com/v3/payment/options', accessToken, deviceInfo, paymentHeaders),
        generateTrendyolHeaderRule(7002, 'payment.tgoapps.com/v2/payment/pay', accessToken, deviceInfo, paymentHeaders)
    ];

    await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: TRENDYOL_RULE_IDS });
    await chrome.declarativeNetRequest.updateSessionRules({ addRules: rules });
}

function generateTrendyolHeaderRule(id, urlFilter, accessToken, device, paymentHeaders) {
    return {
        id,
        priority: 100,
        action: {
            type: 'modifyHeaders',
            requestHeaders: [
                { header: 'sec-ch-ua', operation: 'remove' },
                { header: 'sec-ch-ua-mobile', operation: 'remove' },
                { header: 'sec-ch-ua-platform', operation: 'remove' },
                { header: 'Sec-Fetch-Dest', operation: 'remove' },
                { header: 'Sec-Fetch-Mode', operation: 'remove' },
                { header: 'Sec-Fetch-Site', operation: 'remove' },
                { header: 'Referer', operation: 'remove' },
                { header: 'Origin', operation: 'remove' },
                { header: 'Authorization', operation: 'set', value: `Bearer ${accessToken}` },
                { header: 'Content-Type', operation: 'set', value: 'application/json' },
                { header: 'Pid', operation: 'set', value: paymentHeaders.pid },
                { header: 'Traceparent', operation: 'set', value: `00-${paymentHeaders.traceId}-${paymentHeaders.spanId}-01` },
                { header: 'Tracestate', operation: 'set', value: `@nr=0-2---${paymentHeaders.spanId}----${paymentHeaders.timestamp}` },
                { header: 'Newrelic', operation: 'set', value: JSON.stringify({
                    v: [0, 2],
                    d: {
                        ty: 'Mobile',
                        ac: '',
                        ap: '',
                        tr: paymentHeaders.traceId,
                        id: paymentHeaders.spanId,
                        ti: paymentHeaders.timestamp,
                        tk: ''
                    }
                }) },
                { header: 'Deviceid', operation: 'set', value: '00000000-0000-0000-0000-000000000000' },
                { header: 'X-Features', operation: 'set', value: 'OPTIONAL_REBATE;TRENDYOLPAY_ENABLED;MEAL_CART_ENABLED;MEAL_CARD_TRENDYOL_PROMOTION;DELIVERY_FEE_SUMMARY_HIDDEN' },
                { header: 'X-Application-Id', operation: 'set', value: '5' },
                { header: 'Cl_eligible', operation: 'set', value: 'false' },
                { header: 'Sid', operation: 'set', value: paymentHeaders.sessionId },
                { header: 'Build', operation: 'set', value: '1.37.0.76' },
                { header: 'Platform', operation: 'set', value: 'Android' },
                { header: 'Device-Language', operation: 'set', value: 'tr' },
                { header: 'Osversion', operation: 'set', value: device.osVersion || '11' },
                { header: 'Isemulator', operation: 'set', value: 'false' },
                { header: 'X-Channelid', operation: 'set', value: '4' },
                { header: 'Uniqueid', operation: 'set', value: paymentHeaders.uniqueId },
                { header: 'Tpaydid', operation: 'set', value: paymentHeaders.trendyolPayId },
                { header: 'App-Name', operation: 'set', value: 'TrendyolGo' },
                { header: 'Lc-Member', operation: 'set', value: 'true' },
                { header: 'Accept-Language', operation: 'set', value: 'tr-TR' },
                { header: 'X-Storefront-Id', operation: 'set', value: '1' },
                { header: 'Searchsegment', operation: 'set', value: '20' },
                { header: 'Gender', operation: 'set', value: 'F' },
                { header: 'X-Visitor-Type', operation: 'set', value: '4' },
                { header: 'Segments', operation: 'set', value: '140750000_0,410750000_1,365750000_generic_6' },
                { header: 'User-Agent', operation: 'set', value: `Dalvik/2.1.0 (Linux; U; Android ${device.osVersion}; ${device.model} Build/${device.buildVersion}) TrendyolGo/1.37.0.76` },
                { header: 'Accept-Encoding', operation: 'set', value: 'gzip, deflate, br' },
                { header: 'Service.name', operation: 'set', value: 'mobile-android-go' },
                { header: 'Service.version', operation: 'set', value: '1.37.0.76' },
                { header: 'Service.type', operation: 'set', value: 'client' },
                { header: 'Baggage', operation: 'set', value: 'ty.source.service.name=mobile-android-go,ty.source.service.type=client,ty.source.service.version=1.37.0.76' },
                { header: 'X-B3-Traceid', operation: 'set', value: paymentHeaders.traceId },
                { header: 'X-B3-Spanid', operation: 'set', value: paymentHeaders.spanId },
                { header: 'X-B3-Sampled', operation: 'set', value: '1' }
            ]
        },
        condition: {
            urlFilter,
            resourceTypes: ['xmlhttprequest', 'sub_frame', 'main_frame']
        }
    };
}

function generateTrendyolPaymentHeaders(deviceOverrides = {}) {
    const traceId = generateRandomHex(32);
    const spanId = generateRandomHex(16);
    return {
        pid: deviceOverrides.pid || generateUUIDv4(),
        sessionId: deviceOverrides.sessionId || generateUUIDv4(),
        uniqueId: deviceOverrides.uniqueId || generateRandomHex(16),
        trendyolPayId: deviceOverrides.trendyolPayId || generateRandomHex(16),
        traceId,
        spanId,
        timestamp: Date.now()
    };
}

async function clearTrendyolData() {
    try {
        const results = await Promise.all(TRENDYOL_CLEANUP_DOMAINS.map(domain => clearSiteData(domain)));
        if (results.some(result => result === false)) {
            await clearTrendyolCookiesManual();
        }
    } catch (error) {
        console.warn('Trendyol site verileri API ile temizlenemedi, manuel temizleme yapılıyor:', error);
        await clearTrendyolCookiesManual();
    }
}

async function clearTrendyolCookiesManual() {
    const cookies = await getAllCookies({});
    const targets = cookies.filter(cookie => TRENDYOL_CLEANUP_DOMAINS.some(domain => cookie.domain?.includes(domain)));
    await Promise.all(targets.map(cookie => removeCookieEntry(cookie)));
}

async function manageTrendyolAddressFlow(tabId) {
    let savedAddress = await getSavedAddress();

    if (!savedAddress) {
        savedAddress = await getSavedAddressTgo();
    }

    if (!savedAddress) {
        await sendTrendyolLogMessage('Kayıtlı adres bulunamadı. Lütfen eklentiden adres ekleyin.', 'error', tabId);
        await showAddressRequiredPopup(tabId);
        return;
    }

    const shouldAutoAdd = savedAddress.autoAddAddress ?? savedAddress.autoFillAddress ?? true;

    if (!shouldAutoAdd) {
        await sendTrendyolLogMessage('Otomatik adres ekleme devre dışı, Trendyol adresini manuel seçin.', 'warning', tabId);
        return;
    }

    // Önce PUT ile güncelle (SMS tetiklemez), yoksa POST dene
    await manageTrendyolAddressesWithDelete(savedAddress, tabId);
}

async function manageTrendyolAddresses(address, shouldAddAddress, tabId) {
    try {
        await sendTrendyolLogMessage('Trendyol adres yönetimi başlatılıyor...', 'info', tabId);

        const addresses = await getTrendyolAddresses();

        if (!shouldAddAddress) {
            await sendTrendyolLogMessage('Adres otomasyonu devre dışı, mevcut adresler korunuyor.', 'info', tabId);
            return;
        }

        if (!addresses || addresses.length === 0) {
            await sendTrendyolLogMessage('Güncellenecek adres bulunamadı, lütfen Trendyol uygulamasından bir adres ekleyin.', 'warning', tabId);
            return;
        }

        const candidateId = address.trendyolAddressId || address.trendyol_address_id || address.tgoAddressId || address.tgo_address_id;
        let targetAddress = null;

        if (candidateId) {
            targetAddress = addresses.find(item => item.id?.toString() === candidateId.toString());
            if (!targetAddress) {
                await sendTrendyolLogMessage(`Adres ID ${candidateId} Trendyol tarafında bulunamadı, ilk adres güncellenecek.`, 'warning', tabId);
            }
        }

        if (!targetAddress) {
            targetAddress = addresses[0];
        }

        const baseLat = parseFloat(address.latitude || address.lat);
        const baseLng = parseFloat(address.longitude || address.lng);

        if (!Number.isFinite(baseLat) || !Number.isFinite(baseLng)) {
            throw new Error('Adres koordinatları eksik');
        }

        const randomized = randomizeLocation(baseLat, baseLng, 5);
        const addressWithRandom = {
            ...address,
            latitude: randomized.lat,
            longitude: randomized.lng
        };

        await updateTrendyolAddress(targetAddress.id, addressWithRandom, tabId);
        await sendTrendyolLogMessage(`Trendyol adresi güncellendi (ID ${targetAddress.id}).`, 'success', tabId);
    } catch (error) {
        console.error('Trendyol adres yönetimi hatası:', error);
        await sendTrendyolLogMessage(`Trendyol adres hatası: ${error.message}`, 'error', tabId);
    }
}

// ADRES YÖNETİMİ: Mevcut adres varsa PUT ile güncelle (SMS tetiklenmez), yoksa POST ile ekle
async function manageTrendyolAddressesWithDelete(address, tabId) {
    try {
        console.log('[YeKupon] ========== ADRES YÖNETİMİ BAŞLADI (PUT-FIRST v2) ==========');
        await sendTrendyolLogMessage('Trendyol adres yönetimi başlatılıyor (PUT-first v2)...', 'info', tabId);

        // 1) MEVCUT ADRESLERİ AL
        const existingAddresses = await getTrendyolAddresses();
        console.log('[YeKupon] Mevcut adres sayısı:', existingAddresses?.length || 0);

        // 2) Mevcut adresten telefon numarasını al
        let phoneFromExisting = "";
        if (existingAddresses && existingAddresses.length > 0) {
            const firstAddr = existingAddresses[0];
            console.log('[YeKupon] Mevcut adres ID:', firstAddr?.id, 'phone:', firstAddr?.phone);
            if (firstAddr && firstAddr.phone) {
                phoneFromExisting = firstAddr.phone.replace(/\D/g, '');
                if (phoneFromExisting.startsWith('0')) phoneFromExisting = phoneFromExisting.substring(1);
                if (phoneFromExisting.startsWith('90')) phoneFromExisting = phoneFromExisting.substring(2);
                if (!phoneFromExisting.startsWith('5') || phoneFromExisting.length !== 10) {
                    phoneFromExisting = "";
                }
            }
        }

        // Telefon numarasını address objesine ekle
        if (phoneFromExisting) {
            address._existingPhone = phoneFromExisting;
        }

        // 3) KOORDİNATLARI RASTGELE OFFSET EKLE
        const baseLat = parseFloat(address.latitude || address.lat);
        const baseLng = parseFloat(address.longitude || address.lng);

        if (!Number.isFinite(baseLat) || !Number.isFinite(baseLng)) {
            throw new Error('Adres koordinatları eksik. Lütfen haritadan konum seçin.');
        }

        const randomized = randomizeLocation(baseLat, baseLng, 5);
        const addressWithRandom = {
            ...address,
            latitude: randomized.lat,
            longitude: randomized.lng
        };

        // 3.5) LOCATION ID'LERİ BİR KEZ ÇEK (hem PUT hem POST için)
        console.log('[YeKupon] Location ID\'leri alınıyor...');
        const locationIds = await getTrendyolLocationIds(addressWithRandom);
        console.log('[YeKupon] Location IDs:', JSON.stringify(locationIds));
        addressWithRandom._locationIds = locationIds;

        // 4) MEVCUT ADRES VARSA → PUT İLE GÜNCELLE (SMS tetiklemez!)
        if (existingAddresses && existingAddresses.length > 0) {
            const targetAddress = existingAddresses[0];
            console.log('[YeKupon] >>> PUT DENENİYOR - Adres ID:', targetAddress.id);
            await sendTrendyolLogMessage(`PUT ile güncelleniyor (ID: ${targetAddress.id})...`, 'info', tabId);
            
            try {
                await updateTrendyolAddress(targetAddress.id, addressWithRandom, tabId);
                console.log('[YeKupon] >>> PUT BAŞARILI!');
                
                // PUT başarılıysa, fazla adresleri sil (birden fazla varsa)
                if (existingAddresses.length > 1) {
                    await sendTrendyolLogMessage(`${existingAddresses.length - 1} fazla adres siliniyor...`, 'info', tabId);
                    for (let i = 1; i < existingAddresses.length; i++) {
                        try {
                            await deleteTrendyolAddress(existingAddresses[i].id, tabId);
                        } catch (delError) {
                            console.warn(`Adres silinemedi (${existingAddresses[i].id}):`, delError);
                        }
                    }
                }
                
                await sendTrendyolLogMessage('✅ Trendyol adresi güncellendi (PUT)!', 'success', tabId);
                return;
            } catch (putError) {
                console.error('[YeKupon] >>> PUT BAŞARISIZ:', putError.message);
                await sendTrendyolLogMessage(`PUT başarısız (${putError.message}), POST deneniyor...`, 'warning', tabId);
            }
        } else {
            console.log('[YeKupon] >>> MEVCUT ADRES YOK, doğrudan POST yapılacak');
        }

        // 5) MEVCUT ADRES YOKSA VEYA PUT BAŞARISIZSA → POST İLE EKLE
        console.log('[YeKupon] >>> POST DENENİYOR');
        await sendTrendyolLogMessage('Yeni adres ekleniyor (POST)...', 'info', tabId);
        const result = await createTrendyolAddress(addressWithRandom, tabId);
        
        if (result.success) {
            // POST başarılıysa eski adresleri sil
            if (existingAddresses && existingAddresses.length > 0) {
                await sendTrendyolLogMessage(`${existingAddresses.length} eski adres siliniyor...`, 'info', tabId);
                for (const addr of existingAddresses) {
                    try {
                        await deleteTrendyolAddress(addr.id, tabId);
                    } catch (delError) {
                        console.warn(`Adres silinemedi (${addr.id}):`, delError);
                    }
                }
            }
            await sendTrendyolLogMessage('✅ Trendyol adresi başarıyla eklendi!', 'success', tabId);
        } else if (result.smsVerification) {
            await sendTrendyolLogMessage('⚠️ SMS doğrulama gerekli - hesap atlandı, mevcut adresler korundu', 'warning', tabId);
        } else {
            await sendTrendyolLogMessage(`❌ Adres eklenemedi: ${result.error}`, 'error', tabId);
        }
        
    } catch (error) {
        console.error('[YeKupon] Trendyol adres yönetimi hatası:', error);
        await sendTrendyolLogMessage(`Trendyol adres hatası: ${error.message}`, 'error', tabId);
    }
}

// Trendyol adres silme fonksiyonu
async function deleteTrendyolAddress(addressId, tabId) {
    const response = await fetch(`https://api.tgoapis.com/web-user-apimemberaddress-santral/addresses/${addressId}`, {
        method: 'DELETE',
        headers: {
            'Authorization': await getTrendyolAuthHeader(),
            'Accept': 'application/json, text/plain, */*',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-ch-ua': '"Not)A;Brand";v="8", "Chromium";v="138", "Microsoft Edge";v="138"',
            'sec-ch-ua-mobile': '?0',
            'origin': 'https://tgoyemek.com',
            'sec-fetch-site': 'cross-site',
            'sec-fetch-mode': 'cors',
            'sec-fetch-dest': 'empty',
            'accept-encoding': 'gzip, deflate, br, zstd',
            'accept-language': 'tr,en;q=0.9,en-GB;q=0.8,en-US;q=0.7',
            'priority': 'u=1, i'
        }
    });

    // 204 No Content = başarılı silme
    if (response.status === 204 || response.ok) {
        console.log(`[YeKupon] ✅ Trendyol adres silindi: ${addressId}`);
        return true;
    }
    
    const errorText = await response.text();
    throw new Error(`Adres silinemedi (${response.status}): ${errorText.substring(0, 100)}`);
}

// Trendyol yeni adres ekleme fonksiyonu (POST)
async function createTrendyolAddress(address, tabId) {
    try {
        console.log('[YeKupon] createTrendyolAddress çağrıldı (POST)');
        const locationIds = address._locationIds || await getTrendyolLocationIds(address);

        const useRandomSpaces = address.useRandomSpaces ?? true;

        const processedNeighborhood = addRandomSpacesForTrendyol(address.neighborhood || '', useRandomSpaces);
        const processedStreet = addRandomSpacesForTrendyol(address.street || '', useRandomSpaces);
        const processedBuilding = addRandomSpacesForTrendyol(address.buildingNo || address.building || '1', useRandomSpaces);
        const processedApartment = addRandomSpacesForTrendyol(address.apartmentNo || address.apartment || '1', useRandomSpaces);
        const processedDescription = addRandomSpacesForTrendyol(address.description || address.addressDescription || '', useRandomSpaces);
        const processedFloor = addRandomSpacesForTrendyol(address.floor || '1', useRandomSpaces);

        const fullName = (address.fullname || address.fullName || address.name || 'Adres Sahibi').trim();
        const nameParts = fullName.split(' ');
        const ownerName = addRandomSpacesForTrendyol(nameParts[0] || 'Adres', useRandomSpaces);
        const ownerSurname = addRandomSpacesForTrendyol(nameParts.slice(1).join(' ') || 'Sahibi', useRandomSpaces);

        const resolvedPhone = await getAccountPhoneNumber(address);
        // Önce mevcut adresten alınan telefonu kullan, yoksa resolvedPhone, yoksa varsayılan
        const phoneNumber = address._existingPhone || resolvedPhone || '5551234567';

        const latValue = parseFloat(address.latitude ?? address.lat);
        const lngValue = parseFloat(address.longitude ?? address.lng);

        if (!Number.isFinite(latValue) || !Number.isFinite(lngValue)) {
            return { success: false, error: 'Adres koordinatları eksik. Lütfen haritadan konum seçin.' };
        }

        const addressLine = `${processedNeighborhood}, ${processedStreet} No:${processedBuilding}`;

        // Telefon numarası için rastgele mesajlar
        const userInputPhone = address.phone || address.phone_number || address.phoneNumber || '';
        const phoneMessages = [
            "YENİ NUMARAM",
            "BU NUMARAYI ARAYIN",
            "BURAYI ARAYIN",
            "BU TEL İLE ARAYIN",
            "SİPARİŞ TEL",
            "İLETİŞİM NUMARAM BU",
            "BU NUMARADAN ARAYIN MUTLAKA",
            "MUTLAKA BU NUMARAYI ARAYIN",
            "BENİ BU NUMARADAN ARAYIN",
            "GÜNCEL TEL NUMARAM",
            "SADECE BU NUMARAYI ARAYIN",
            "SİPARİŞ İÇİN BU NUMARAYI ARAYIN",
            "LÜTFEN BU NUMARAYI ARAYIN",
            "BU TEL NUMARASINI ARAYIN",
            "TEL NO"
        ];
        const randomPhoneMessage = phoneMessages[Math.floor(Math.random() * phoneMessages.length)];
        
        // Telefon numarasını EN BAŞA ekle (numara önce!)
        const phonePrefix = userInputPhone ? `${userInputPhone} - ${randomPhoneMessage} - ` : "";
        const finalDescription = phonePrefix + processedDescription;

        // Random adres adı
        const randomAddressName = Array.from({length: 7}, () => 
            'abcdefghijklmnopqrstuvwxyz'[Math.floor(Math.random() * 26)]
        ).join('');

        const payload = {
            name: ownerName,
            surname: ownerSurname,
            phone: phoneNumber,
            apartmentNumber: processedBuilding,
            floor: processedFloor,
            doorNumber: processedApartment,
            addressName: randomAddressName,
            addressDescription: finalDescription,
            addressLine,
            cityId: locationIds.cityCode,
            districtId: locationIds.districtId,
            neighborhoodId: locationIds.neighborhoodId,
            latitude: latValue.toString(),
            longitude: lngValue.toString(),
            countryCode: 'TR',
            elevatorAvailable: false
        };

        console.log('[YeKupon] Trendyol adres ekleme payload:', JSON.stringify(payload, null, 2));

        const response = await fetch('https://api.tgoapis.com/web-user-apimemberaddress-santral/addresses', {
            method: 'POST',
            headers: {
                'Authorization': await getTrendyolAuthHeader(),
                'Content-Type': 'application/json',
                'Accept': 'application/json, text/plain, */*',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0',
                'sec-ch-ua-platform': '"Windows"',
                'sec-ch-ua': '"Not)A;Brand";v="8", "Chromium";v="138", "Microsoft Edge";v="138"',
                'sec-ch-ua-mobile': '?0',
                'origin': 'https://tgoyemek.com',
                'sec-fetch-site': 'cross-site',
                'sec-fetch-mode': 'cors',
                'sec-fetch-dest': 'empty',
                'accept-encoding': 'gzip, deflate, br, zstd',
                'accept-language': 'tr,en;q=0.9,en-GB;q=0.8,en-US;q=0.7',
                'priority': 'u=1, i'
            },
            body: JSON.stringify(payload)
        });

        // 204 No Content = başarılı
        if (response.status === 204) {
            console.log('[YeKupon] ✅ Trendyol adres başarıyla eklendi (204)');
            return { success: true };
        }

        // 200-299 arası da başarılı sayılabilir
        if (response.ok) {
            // SMS doğrulama kontrolü
            try {
                const resultData = await response.json();
                // Yanıt array olabilir: [{field: "sms_verification", ...}]
                const smsCheck = Array.isArray(resultData) ? resultData[0] : resultData;
                if (smsCheck && smsCheck.field === 'sms_verification') {
                    console.warn('[YeKupon] SMS doğrulama gerekli (2xx)');
                    await sendTrendyolLogMessage('⚠️ SMS doğrulama gerekli - bu hesap atlanıyor', 'warning', tabId);
                    return { success: false, error: 'SMS doğrulama gerekli - adres manuel olarak eklenmelidir', smsVerification: true };
                }
            } catch {
                // JSON parse edilemezse sorun yok, başarılı sayılır
            }
            console.log('[YeKupon] ✅ Trendyol adres başarıyla eklendi');
            return { success: true };
        }

        // SMS doğrulama kontrolü (428/429 status)
        if (response.status === 428 || response.status === 429) {
            try {
                const smsData = await response.json();
                const smsCheck = Array.isArray(smsData) ? smsData[0] : smsData;
                if (smsCheck && smsCheck.field === 'sms_verification') {
                    console.warn('[YeKupon] SMS doğrulama gerekli (428/429)');
                    await sendTrendyolLogMessage('⚠️ SMS doğrulama gerekli - bu hesap atlanıyor', 'warning', tabId);
                    return { success: false, error: 'SMS doğrulama gerekli - adres manuel olarak eklenmelidir', smsVerification: true };
                }
            } catch {}
        }

        // Hata durumu - detaylı mesaj göster
        let errorMessage = `HTTP ${response.status}`;
        try {
            const errorData = await response.json();
            if (errorData.message) {
                errorMessage = errorData.message;
            } else if (errorData.errors && Array.isArray(errorData.errors)) {
                errorMessage = errorData.errors.map(e => e.message || e).join(', ');
            } else if (errorData.error) {
                errorMessage = errorData.error;
            }
        } catch {
            try {
                const errorText = await response.text();
                if (errorText) errorMessage = errorText.substring(0, 150);
            } catch {}
        }

        // Türkçe hata mesajları
        if (response.status === 400) {
            errorMessage = `Geçersiz adres verisi: ${errorMessage}`;
        } else if (response.status === 401) {
            errorMessage = 'Oturum süresi dolmuş. Lütfen tekrar giriş yapın.';
        } else if (response.status === 422) {
            errorMessage = `Adres bilgilerinde hata: ${errorMessage}`;
        }

        console.error('[YeKupon] Trendyol adres ekleme hatası:', errorMessage);
        return { success: false, error: errorMessage };
        
    } catch (error) {
        console.error('[YeKupon] createTrendyolAddress exception:', error);
        return { success: false, error: error.message };
    }
}

async function getTrendyolAddresses() {
    try {
        const response = await fetch('https://api.tgoapis.com/web-user-apimemberaddress-santral/addresses', {
            method: 'GET',
            headers: {
                'Authorization': await getTrendyolAuthHeader(),
                'Accept': 'application/json, text/plain, */*',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0',
                'sec-ch-ua-platform': '"Windows"',
                'sec-ch-ua': '"Not)A;Brand";v="8", "Chromium";v="138", "Microsoft Edge";v="138"',
                'sec-ch-ua-mobile': '?0',
                'origin': 'https://tgoyemek.com',
                'sec-fetch-site': 'cross-site',
                'sec-fetch-mode': 'cors',
                'sec-fetch-dest': 'empty',
                'accept-encoding': 'gzip, deflate, br, zstd',
                'accept-language': 'tr,en;q=0.9,en-GB;q=0.8,en-US;q=0.7',
                'priority': 'u=1, i'
            }
        });

        if (!response.ok) {
            throw new Error(`Trendyol adres listesi alınamadı (${response.status})`);
        }

        const data = await response.json();
        return data?.addresses || [];
    } catch (error) {
        console.error('Trendyol adresleri alınamadı:', error);
        return [];
    }
}

async function updateTrendyolAddress(addressId, address, tabId) {
    console.log('[YeKupon] updateTrendyolAddress çağrıldı - ID:', addressId);
    const locationIds = address._locationIds || await getTrendyolLocationIds(address);
    console.log('[YeKupon] updateTrendyolAddress locationIds:', JSON.stringify(locationIds));

    const useRandomSpaces = address.useRandomSpaces ?? true;

    const processedNeighborhood = addRandomSpacesForTrendyol(address.neighborhood || '', useRandomSpaces);
    const processedStreet = addRandomSpacesForTrendyol(address.street || '', useRandomSpaces);
    // Bina No: buildingNo veya building alanından al
    const processedBuilding = addRandomSpacesForTrendyol(address.buildingNo || address.building || '1', useRandomSpaces);
    // Daire No: apartmentNo veya apartment alanından al
    const processedApartment = addRandomSpacesForTrendyol(address.apartmentNo || address.apartment || '1', useRandomSpaces);
    const processedDescription = addRandomSpacesForTrendyol(address.description || address.addressDescription || '', useRandomSpaces);
    const processedFloor = addRandomSpacesForTrendyol(address.floor || '1', useRandomSpaces);

    const fullName = (address.fullname || address.fullName || address.name || 'Adres Sahibi').trim();
    const nameParts = fullName.split(' ');
    const ownerName = addRandomSpacesForTrendyol(nameParts[0] || 'Adres', useRandomSpaces);
    const ownerSurname = addRandomSpacesForTrendyol(nameParts.slice(1).join(' ') || 'Sahibi', useRandomSpaces);

    const resolvedPhone = await getAccountPhoneNumber(address);
    // Önce mevcut adresten alınan telefonu kullan, yoksa resolvedPhone
    const phoneNumber = address._existingPhone || resolvedPhone || '5551234567';
    console.log('[YeKupon] updateTrendyolAddress phone:', phoneNumber);

    const latValue = parseFloat(address.latitude ?? address.lat ?? address.location?.lat);
    const lngValue = parseFloat(address.longitude ?? address.lng ?? address.location?.lng);

    if (!Number.isFinite(latValue) || !Number.isFinite(lngValue)) {
        throw new Error('Adres koordinatları eksik');
    }

    const addressLine = `${processedNeighborhood}, ${processedStreet} No:${processedBuilding}`;

    // Eklentiden girilen telefon numarasını al (address objesinden)
    const userInputPhone = address.phone || address.phone_number || address.phoneNumber || '';
    
    // Telefon numarası için rastgele mesajlar (Migros ile aynı)
    const phoneMessages = [
        "YENİ NUMARAM",
        "BU NUMARAYI ARAYIN",
        "BURAYI ARAYIN",
        "BU TEL İLE ARAYIN",
        "SİPARİŞ TEL",
        "İLETİŞİM NUMARAM BU",
        "BU NUMARADAN ARAYIN MUTLAKA",
        "MUTLAKA BU NUMARAYI ARAYIN",
        "BENİ BU NUMARADAN ARAYIN",
        "GÜNCEL TEL NUMARAM",
        "SADECE BU NUMARAYI ARAYIN",
        "SİPARİŞ İÇİN BU NUMARAYI ARAYIN",
        "LÜTFEN BU NUMARAYI ARAYIN",
        "BU TEL NUMARASINI ARAYIN",
        "TEL NO"
    ];
    const randomPhoneMessage = phoneMessages[Math.floor(Math.random() * phoneMessages.length)];
    
    // Telefon numarasını EN BAŞA ekle (numara önce!) - fişte kesilmemesi için
    const phonePrefix = userInputPhone ? `${userInputPhone} - ${randomPhoneMessage} - ` : "";
    const finalDescription = phonePrefix + processedDescription;

    // addressName için 7 haneli random string oluştur
    const randomAddressName = Array.from({length: 7}, () => 
        'abcdefghijklmnopqrstuvwxyz'[Math.floor(Math.random() * 26)]
    ).join('');

    const payload = {
        name: ownerName,
        surname: ownerSurname,
        phone: phoneNumber,
        apartmentNumber: processedBuilding,
        floor: processedFloor,
        doorNumber: processedApartment,
        addressName: randomAddressName,
        addressDescription: finalDescription,
        addressLine,
        cityId: locationIds.cityCode,
        districtId: locationIds.districtId,
        neighborhoodId: locationIds.neighborhoodId,
        latitude: latValue.toString(),
        longitude: lngValue.toString(),
        countryCode: 'TR',
        elevatorAvailable: false
    };

    console.log('[YeKupon] PUT isteği gönderiliyor - URL:', `https://api.tgoapis.com/web-user-apimemberaddress-santral/addresses/${addressId}`);

    const response = await fetch(`https://api.tgoapis.com/web-user-apimemberaddress-santral/addresses/${addressId}`, {
        method: 'PUT',
        headers: {
            'Authorization': await getTrendyolAuthHeader(),
            'Content-Type': 'application/json',
            'Accept': 'application/json, text/plain, */*',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-ch-ua': '"Not)A;Brand";v="8", "Chromium";v="138", "Microsoft Edge";v="138"',
            'sec-ch-ua-mobile': '?0',
            'origin': 'https://tgoyemek.com',
            'sec-fetch-site': 'cross-site',
            'sec-fetch-mode': 'cors',
            'sec-fetch-dest': 'empty',
            'accept-encoding': 'gzip, deflate, br, zstd',
            'accept-language': 'tr,en;q=0.9,en-GB;q=0.8,en-US;q=0.7',
            'priority': 'u=1, i'
        },
        body: JSON.stringify(payload)
    });

    console.log('[YeKupon] PUT yanıt status:', response.status);

    // 204 No Content = başarılı güncelleme
    if (response.status === 204 || response.ok) {
        // ok ama SMS kontrolü
        if (response.status !== 204) {
            try {
                const resultData = await response.json();
                const smsCheck = Array.isArray(resultData) ? resultData[0] : resultData;
                if (smsCheck && smsCheck.field === 'sms_verification') {
                    console.warn('[YeKupon] PUT bile SMS istedi!');
                    throw new Error('SMS doğrulama gerekli (PUT)');
                }
            } catch (e) {
                if (e.message.includes('SMS')) throw e;
            }
        }
        console.log('[YeKupon] ✅ PUT başarılı (', response.status, ')');
        await sendTrendyolLogMessage('Adres başarıyla güncellendi (PUT)', 'success', tabId);
        return;
    }

    // SMS kontrolü (428/429)
    if (response.status === 428 || response.status === 429) {
        try {
            const smsData = await response.json();
            const smsCheck = Array.isArray(smsData) ? smsData[0] : smsData;
            if (smsCheck && smsCheck.field === 'sms_verification') {
                console.warn('[YeKupon] PUT SMS doğrulama gerekli (428/429)');
                throw new Error('SMS doğrulama gerekli (PUT ' + response.status + ')');
            }
        } catch (e) {
            if (e.message.includes('SMS')) throw e;
        }
    }

    const errorText = await response.text();
    throw new Error(`PUT hatası: ${response.status} - ${errorText.substring(0, 120)}`);
}

async function getTrendyolAuthHeader() {
    // ADRES API İÇİN: Web login token'ı kullan (cookie veya trendyol_session)
    // RAKİP ANALİZİ: Rakip önce tgo-token cookie'yi kontrol ediyor, sonra access_token, sonra storage
    // RAKİP ANALİZİ: Rakip küçük harf "bearer" kullanıyor (büyük harf "Bearer" değil)
    
    const tgoTokenCookie = await getCookieValue('https://tgoyemek.com', 'tgo-token');
    if (tgoTokenCookie) {
        console.log('[YeKupon] getTrendyolAuthHeader: cookie tgo-token kullanılıyor');
        return `bearer ${tgoTokenCookie}`;
    }

    const accessTokenCookie = await getCookieValue('https://tgoyemek.com', 'access_token');
    if (accessTokenCookie) {
        console.log('[YeKupon] getTrendyolAuthHeader: cookie access_token kullanılıyor');
        return `bearer ${accessTokenCookie}`;
    }

    const stored = await chrome.storage.local.get(['trendyol_session']);
    if (stored?.trendyol_session?.accessToken) {
        console.log('[YeKupon] getTrendyolAuthHeader: trendyol_session.accessToken kullanılıyor');
        return `bearer ${stored.trendyol_session.accessToken}`;
    }

    throw new Error('Trendyol yetkilendirme tokenı bulunamadı');
}

async function getTrendyolLocationIds(address) {
    const cities = await fetchTrendyolCities();
    const city = findMatchInTrendyolData(cities, address.province || address.city || '');
    if (!city) {
        throw new Error('Şehir ID bulunamadı');
    }

    const districts = await fetchTrendyolDistricts(city.id);
    const district = findMatchInTrendyolData(districts, address.district || '');
    if (!district) {
        throw new Error('İlçe ID bulunamadı');
    }

    const neighborhoods = await fetchTrendyolNeighborhoods(district.id);
    const neighborhood = findMatchInTrendyolData(neighborhoods, address.neighborhood || address.neighborhoodName || '');
    if (!neighborhood) {
        throw new Error('Mahalle ID bulunamadı');
    }

    return {
        cityCode: city.id,
        districtId: district.id,
        neighborhoodId: neighborhood.id
    };
}

async function fetchTrendyolCities() {
    try {
        const response = await fetch('https://api.tgoapis.com/web-user-apimemberaddress-santral/cities', {
            method: 'GET',
            headers: {
                'Authorization': await getTrendyolAuthHeader(),
                'Accept': 'application/json'
            }
        });

        if (!response.ok) {
            throw new Error(`Trendyol şehir verisi alınamadı (${response.status})`);
        }

        const data = await response.json();
        return data?.cities || [];
    } catch (error) {
        console.error('Trendyol şehir verisi hatası:', error);
        return [];
    }
}

async function fetchTrendyolDistricts(cityId) {
    try {
        const response = await fetch(`https://api.tgoapis.com/web-user-apimemberaddress-santral/cities/${cityId}/districts`, {
            method: 'GET',
            headers: {
                'Authorization': await getTrendyolAuthHeader(),
                'Accept': 'application/json'
            }
        });

        if (!response.ok) {
            throw new Error(`Trendyol ilçe verisi alınamadı (${response.status})`);
        }

        const data = await response.json();
        return data?.districts || [];
    } catch (error) {
        console.error('Trendyol ilçe verisi hatası:', error);
        return [];
    }
}

async function fetchTrendyolNeighborhoods(districtId) {
    try {
        const response = await fetch(`https://api.tgoapis.com/web-user-apimemberaddress-santral/districts/${districtId}/neighborhoods`, {
            method: 'GET',
            headers: {
                'Authorization': await getTrendyolAuthHeader(),
                'Accept': 'application/json'
            }
        });

        if (!response.ok) {
            throw new Error(`Trendyol mahalle verisi alınamadı (${response.status})`);
        }

        const data = await response.json();
        return data?.neighborhoods || [];
    } catch (error) {
        console.error('Trendyol mahalle verisi hatası:', error);
        return [];
    }
}

function findMatchInTrendyolData(dataArray, nameToMatch) {
    if (!Array.isArray(dataArray) || !nameToMatch) {
        return null;
    }

    const simplify = (text) => text
        .toLowerCase()
        .normalize('NFKD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/[\u0130\u0049]/g, 'i')
        .replace(/[\u0131]/g, 'i')
        .replace(/ğ/g, 'g')
        .replace(/ü/g, 'u')
        .replace(/ş/g, 's')
        .replace(/ö/g, 'o')
        .replace(/ç/g, 'c')
        .replace(/[^a-z0-9]/g, '');

    const cleanSuffix = (text) => text
        .replace(/\s*(mah|mahallesi|mahalle|mh\.?|köy|köyü|beldesi|kasabası)\s*$/gi, '')
        .trim();

    const simplifyItem = (value) => simplify(cleanSuffix(value || ''));
    const target = simplifyItem(nameToMatch);

    if (!target) {
        return null;
    }

    const matchers = [
        (candidate) => candidate === target,
        (candidate, original) => candidate.startsWith(target) || target.startsWith(candidate),
        (candidate, original) => candidate.includes(target) || target.includes(candidate)
    ];

    for (const matcher of matchers) {
        const matched = dataArray.find(item => {
            const simplified = simplifyItem(item.name || item.title || '');
            return simplified && matcher(simplified, item.name || item.title || '');
        });
        if (matched) {
            return matched;
        }
    }

    if (target.length < 4) {
        return null;
    }

    const levenshtein = (a, b) => {
        const matrix = Array.from({ length: b.length + 1 }, (_, i) => [i]);
        for (let j = 0; j <= a.length; j++) {
            matrix[0][j] = j;
        }
        for (let i = 1; i <= b.length; i++) {
            for (let j = 1; j <= a.length; j++) {
                if (b.charAt(i - 1) === a.charAt(j - 1)) {
                    matrix[i][j] = matrix[i - 1][j - 1];
                } else {
                    matrix[i][j] = Math.min(
                        matrix[i - 1][j - 1] + 1,
                        matrix[i][j - 1] + 1,
                        matrix[i - 1][j] + 1
                    );
                }
            }
        }
        return matrix[b.length][a.length];
    };

    let bestMatch = null;
    let bestDistance = Infinity;
    const maxDistance = Math.floor(target.length * 0.3);

    for (const item of dataArray) {
        const simplified = simplifyItem(item.name || item.title || '');
        if (!simplified) continue;
        const distance = levenshtein(target, simplified);
        if (distance <= maxDistance && distance < bestDistance) {
            bestMatch = item;
            bestDistance = distance;
        }
    }

    return bestMatch;
}

function sanitizePhoneNumber(phone) {
    if (!phone) return '';
    const digits = phone.replace(/\D/g, '');
    const trimmed = digits.replace(/^90/, '').replace(/^0/, '');
    if (trimmed.length === 10 && trimmed.startsWith('5')) {
        return trimmed;
    }
    if (trimmed.length > 10) {
        return trimmed.slice(-10);
    }
    return '';
}

async function getAccountPhoneNumber(address = {}) {
    // 1. Storage'dan dene
    try {
        const stored = await chrome.storage.local.get(['yekupon_user_data']);
        const storedPhone = stored?.yekupon_user_data?.phone_number ||
            stored?.yekupon_user_data?.phone ||
            stored?.yekupon_user_data?.user_phone;
        const sanitizedStored = sanitizePhoneNumber(storedPhone);
        if (sanitizedStored) {
            return sanitizedStored;
        }
    } catch (error) {
        console.warn('Stored phone okunamadı:', error);
    }

    // 2. Cookie'den dene
    try {
        const cookiePhone = await getCookieValue('https://tgoyemek.com', 'user_phone');
        const sanitizedCookie = sanitizePhoneNumber(cookiePhone);
        if (sanitizedCookie) {
            return sanitizedCookie;
        }
    } catch (error) {
        console.warn('Cookie phone okunamadı:', error);
    }

    // 3. Trendyol adres API'sinden telefon al
    try {
        const trendyolAddresses = await getTrendyolAddresses();
        if (trendyolAddresses && trendyolAddresses.length > 0) {
            // İlk adresten telefon numarasını al
            const firstAddress = trendyolAddresses[0];
            const tyPhone = firstAddress.phone || firstAddress.phoneNumber;
            const sanitizedTyPhone = sanitizePhoneNumber(tyPhone);
            if (sanitizedTyPhone) {
                console.log('📱 Telefon Trendyol adresinden alındı:', sanitizedTyPhone);
                return sanitizedTyPhone;
            }
        }
    } catch (error) {
        console.warn('Trendyol adresinden telefon alınamadı:', error);
    }

    return '';
}

async function sendTrendyolLogMessage(message, type, tabId) {
    if (tabId) {
        try {
            chrome.tabs.sendMessage(tabId, {
                action: 'logMessage',
                platform: 'trendyol',
                message: message,
                type: type
            });
        } catch (error) {
            console.log('Tab message send error:', error);
        }
    }
    console.log(`[TRENDYOL ${type.toUpperCase()}] ${message}`);
}

async function handleTrendyolSetup(userData, tabId, sendResponse) {
    try {
        console.log('?? Popup: Trendyol setup request received');
        await performTrendyolOperations(userData, tabId);
        sendResponse({ success: true });
    } catch (error) {
        console.error('Trendyol setup error:', error);
        sendResponse({ success: false, error: error.message });
    }
}



async function handleTgoYemekLogin(data, token, tabId) {
    try {
    await sendTgoYemekLogMessage("TgoYemek giriş işlemi başlatılıyor...", "info", tabId);
        
        const response = await fetch(`https://yekupon.com/cookies/${token}`);
        
        if (!response.ok) {
            throw new Error(`YeKupon sunucusu hatası: ${response.status}`);
        }
        
        const responseData = await response.json();
    console.log('YeKupon sunucusundan alınan veri:', responseData);
        
        const userData = responseData.data || responseData;
        
        chrome.storage.local.set({
            'yekupon_user_data': userData
        }, function() {
            console.log('YeKupon user data chrome storage\'a kaydedildi');
        });
        
        if (userData.email && userData.password) {
            await performTgoYemekDirectLogin(userData.email, userData.password, userData.phone_number, tabId);
        } else if (userData.access_token) {
            await performTgoYemekTokenLogin(userData, tabId);
        } else {
            throw new Error('YeKupon sunucusundan geçersiz veri formatı alındı');
        }
        
    } catch (error) {
    console.error('TgoYemek giriş hatası:', error);
    await sendTgoYemekLogMessage(`TgoYemek giriş hatası: ${error.message}`, "error", tabId);
    }
}

async function performTgoYemekDirectLogin(email, password, phoneNumber, tabId) {
    try {
    await sendTgoYemekLogMessage("TgoYemek çerezleri temizleniyor...", "info", tabId);
        
        await clearTgoYemekCookies();
        
    await sendTgoYemekLogMessage("CSRF token alınıyor...", "info", tabId);
        
        const csrfResponse = await fetch('https://tgoyemek.com/api/auth/csrf', {
            method: 'GET',
            headers: {
                'sec-ch-ua': '"Not)A;Brand";v="8", "Chromium";v="138", "Microsoft Edge";v="138"',
                'sec-ch-ua-mobile': '?0',
                'accept': '*/*',
                'sec-fetch-site': 'same-origin',
                'sec-fetch-mode': 'cors',
                'sec-fetch-dest': 'empty',
                'accept-encoding': 'gzip, deflate, br, zstd',
                'accept-language': 'tr',
                'priority': 'u=1, i'
            }
        });
        
        if (!csrfResponse.ok) {
            throw new Error(`CSRF token alınamadı: ${csrfResponse.status}`);
        }
        
        const csrfData = await csrfResponse.json();
        const csrfToken = csrfData.csrfToken;
        
        if (!csrfToken) {
            throw new Error('CSRF token response\'unda bulunamadı');
        }
        
    console.log('TgoYemek CSRF token alındı:', csrfToken);
        
        await new Promise((resolve, reject) => {
            chrome.cookies.set({
                url: "https://tgoyemek.com",
                name: "tgo-csrf-token",
                value: csrfToken,
                domain: "tgoyemek.com",
                secure: true,
                httpOnly: true,
                sameSite: "lax",
                path: "/"
            }, (cookie) => {
                if (chrome.runtime.lastError) {
                    reject(new Error(chrome.runtime.lastError.message));
                } else {
                    resolve(cookie);
                }
            });
        });
    await sendTgoYemekLogMessage("TgoYemek'e giriş yapılıyor...", "info", tabId);
        
        const loginResponse = await fetch('https://tgoyemek.com/api/auth/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'text/plain;charset=UTF-8',
                'sec-ch-ua-platform': '"Windows"',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0',
                'sec-ch-ua': '"Not)A;Brand";v="8", "Chromium";v="138", "Microsoft Edge";v="138"',
                'sec-ch-ua-mobile': '?0',
                'accept': '*/*',
                'origin': 'https://tgoyemek.com',
                'sec-fetch-site': 'same-origin',
                'sec-fetch-mode': 'cors',
                'sec-fetch-dest': 'empty',
                'referer': 'https://tgoyemek.com/giris?callbackUrl=%2F',
                'accept-encoding': 'gzip, deflate, br, zstd',
                'accept-language': 'tr,en;q=0.9,en-GB;q=0.8,en-US;q=0.7',
                'priority': 'u=1, i',
                'Cookie': `tgo-csrf-token=${csrfToken}`
            },
            body: JSON.stringify({
                username: email,
                password: password,
                csrfToken: csrfToken
            })
        });
        
        if (!loginResponse.ok) {
            throw new Error(`TgoYemek giriş başarısız: ${loginResponse.status}`);
        }
        
        const loginData = await loginResponse.json();
    console.log('TgoYemek giriş yanıtı:', loginData);
        
        let tgoToken = null;
        
        const setCookieHeaders = loginResponse.headers.get('set-cookie');
        if (setCookieHeaders) {
            const tgoTokenMatch = setCookieHeaders.match(/tgo-token=([^;]+)/);
            if (tgoTokenMatch) {
                tgoToken = tgoTokenMatch[1];
                console.log('TgoYemek Header\'dan tgo-token alındı:', tgoToken.substring(0, 20) + '...');
            }
        }
        
        if (!tgoToken) {
            await new Promise(resolve => setTimeout(resolve, 1000));
            
            const tgoTokenCookie = await new Promise(resolve => {
                chrome.cookies.get({ url: 'https://tgoyemek.com', name: 'tgo-token' }, cookie => {
                    resolve(cookie);
                });
            });
            
            if (tgoTokenCookie && tgoTokenCookie.value) {
                tgoToken = tgoTokenCookie.value;
                console.log('TgoYemek Cookie\'den tgo-token alındı:', tgoToken.substring(0, 20) + '...');
            }
        }
        
        if (!tgoToken) {
            throw new Error('tgo-token ne header\'da ne de cookie\'de bulunamadı');
        }
        
        const cookiePromises = [
            new Promise((resolve, reject) => {
                chrome.cookies.set({
                    url: "https://tgoyemek.com",
                    name: "tgo-token",
                    value: tgoToken,
                    domain: "tgoyemek.com",
                    secure: true,
                    httpOnly: true,
                    sameSite: "lax",
                    path: "/"
                }, (cookie) => {
                    if (chrome.runtime.lastError) {
                        reject(new Error(chrome.runtime.lastError.message));
                    } else {
                        resolve(cookie);
                    }
                });
            }),
            new Promise((resolve, reject) => {
                chrome.cookies.set({
                    url: "https://tgoyemek.com",
                    name: "access_token",
                    value: tgoToken,
                    domain: "tgoyemek.com",
                    secure: true,
                    httpOnly: false
                }, (cookie) => {
                    if (chrome.runtime.lastError) {
                        reject(new Error(chrome.runtime.lastError.message));
                    } else {
                        resolve(cookie);
                    }
                });
            }),
            new Promise((resolve, reject) => {
                chrome.cookies.set({
                    url: "https://tgoyemek.com", 
                    name: "user_email",
                    value: email,
                    domain: "tgoyemek.com",
                    secure: true,
                    httpOnly: false
                }, (cookie) => {
                    if (chrome.runtime.lastError) {
                        reject(new Error(chrome.runtime.lastError.message));
                    } else {
                        resolve(cookie);
                    }
                });
            }),
            new Promise((resolve, reject) => {
                chrome.cookies.set({
                    url: "https://tgoyemek.com",
                    name: "logged_in",
                    value: "true",
                    domain: "tgoyemek.com",
                    secure: true,
                    httpOnly: false
                }, (cookie) => {
                    if (chrome.runtime.lastError) {
                        reject(new Error(chrome.runtime.lastError.message));
                    } else {
                        resolve(cookie);
                    }
                });
            })
        ];
        
        if (phoneNumber) {
            cookiePromises.push(
                new Promise((resolve, reject) => {
                    chrome.cookies.set({
                        url: "https://tgoyemek.com",
                        name: "user_phone",
                        value: phoneNumber,
                        domain: "tgoyemek.com",
                        secure: true,
                        httpOnly: false
                    }, (cookie) => {
                        if (chrome.runtime.lastError) {
                            reject(new Error(chrome.runtime.lastError.message));
                        } else {
                            resolve(cookie);
                        }
                    });
                })
            );
        }
        
        await Promise.all(cookiePromises);
        
        const allCookies = await new Promise(resolve => {
            chrome.cookies.getAll({ domain: 'tgoyemek.com' }, cookies => {
                resolve(cookies);
            });
        });
        
    console.log('TgoYemek aktif cookie\'ler:', allCookies.map(c => `${c.name}=${c.value.substring(0, 20)}...`));
        
    await sendTgoYemekLogMessage("TgoYemek direkt girişi başarılı!", "success", tabId);
        
        const userData = { 
            email: email, 
            access_token: tgoToken,
            tgo_token: tgoToken,
            phone_number: phoneNumber
        };
        
        chrome.storage.local.set({
            'yekupon_user_data': userData
        }, function() {
            console.log('YeKupon user data chrome storage\'a kaydedildi');
        });
        
        await manageSavedAddress('tgoyemek', tabId);
        
        chrome.tabs.create({ url: "https://tgoyemek.com" });
        
        return { 
            success: true, 
            userData: userData
        };
        
    } catch (error) {
    console.error('TgoYemek direkt giriş hatası:', error);
    await sendTgoYemekLogMessage(`TgoYemek direkt giriş hatası: ${error.message}`, "error", tabId);
        return { success: false, error: error.message };
    }
}

async function performTgoYemekTokenLogin(responseData, tabId) {
    try {
    await sendTgoYemekLogMessage("Token ile TgoYemek girişi yapılıyor...", "info", tabId);
        
        await setTgoYemekCookies(responseData, tabId);
        
    await sendTgoYemekLogMessage("TgoYemek token girişi başarılı!", "success", tabId);
        
        await manageSavedAddress('tgoyemek', tabId);
        
        chrome.tabs.create({ url: "https://tgoyemek.com" });
        
        return { success: true, userData: responseData };
        
    } catch (error) {
    console.error('TgoYemek token giriş hatası:', error);
    await sendTgoYemekLogMessage(`TgoYemek token giriş hatası: ${error.message}`, "error", tabId);
        return { success: false, error: error.message };
    }
}

async function setTgoYemekCookies(data, tabId) {
    try {
        const cookiePromises = [];
        
        if (data.access_token) {
            cookiePromises.push(
                new Promise((resolve, reject) => {
                    chrome.cookies.set({
                        url: "https://tgoyemek.com",
                        name: "access_token",
                        value: data.access_token,
                        domain: "tgoyemek.com",
                        secure: true,
                        httpOnly: false
                    }, (cookie) => {
                        if (chrome.runtime.lastError) {
                            reject(new Error(chrome.runtime.lastError.message));
                        } else {
                            resolve(cookie);
                        }
                    });
                })
            );
        }
        
        if (data.tgo_token) {
            cookiePromises.push(
                new Promise((resolve, reject) => {
                    chrome.cookies.set({
                        url: "https://tgoyemek.com",
                        name: "tgo-token",
                        value: data.tgo_token,
                        domain: "tgoyemek.com",
                        secure: true,
                        httpOnly: true,
                        sameSite: "lax",
                        path: "/"
                    }, (cookie) => {
                        if (chrome.runtime.lastError) {
                            reject(new Error(chrome.runtime.lastError.message));
                        } else {
                            resolve(cookie);
                        }
                    });
                })
            );
        }
        
        if (data.email) {
            cookiePromises.push(
                new Promise((resolve, reject) => {
                    chrome.cookies.set({
                        url: "https://tgoyemek.com",
                        name: "user_email",
                        value: data.email,
                        domain: "tgoyemek.com",
                        secure: true,
                        httpOnly: false
                    }, (cookie) => {
                        if (chrome.runtime.lastError) {
                            reject(new Error(chrome.runtime.lastError.message));
                        } else {
                            resolve(cookie);
                        }
                    });
                })
            );
        }
        
        const rawPhone = data.phone_number || data.phoneNumber || data.phone;
        const sanitizedPhone = sanitizePhoneNumber(rawPhone);
        if (sanitizedPhone) {
            cookiePromises.push(
                new Promise((resolve, reject) => {
                    chrome.cookies.set({
                        url: "https://tgoyemek.com",
                        name: "user_phone",
                        value: sanitizedPhone,
                        domain: "tgoyemek.com",
                        secure: true,
                        httpOnly: false
                    }, (cookie) => {
                        if (chrome.runtime.lastError) {
                            reject(new Error(chrome.runtime.lastError.message));
                        } else {
                            resolve(cookie);
                        }
                    });
                })
            );
        }
        
        cookiePromises.push(
            new Promise((resolve, reject) => {
                chrome.cookies.set({
                    url: "https://tgoyemek.com",
                    name: "logged_in",
                    value: "true",
                    domain: "tgoyemek.com",
                    secure: true,
                    httpOnly: false
                }, (cookie) => {
                    if (chrome.runtime.lastError) {
                        reject(new Error(chrome.runtime.lastError.message));
                    } else {
                        resolve(cookie);
                    }
                });
            })
        );
        
        await Promise.all(cookiePromises);
    console.log('TgoYemek çerezleri başarıyla ayarlandı');
        
    } catch (error) {
    console.error('TgoYemek çerez ayarlama hatası:', error);
        throw error;
    }
}

async function clearTgoYemekCookies() {
    try {
        const cookies = await new Promise((resolve) => {
            chrome.cookies.getAll({ domain: 'tgoyemek.com' }, (cookies) => {
                resolve(cookies);
            });
        });
        
        const removePromises = cookies.map(cookie => {
            return new Promise(resolve => {
                chrome.cookies.remove({
                    url: `https://tgoyemek.com${cookie.path}`,
                    name: cookie.name
                }, () => {
                    resolve();
                });
            });
        });
        
        await Promise.all(removePromises);
    console.log('TgoYemek çerezleri temizlendi');
        
    } catch (error) {
    console.error('TgoYemek çerez temizleme hatası:', error);
    }
}

async function sendTgoYemekLogMessage(message, type, tabId) {
    try {
        if (tabId) {
            chrome.tabs.sendMessage(tabId, {
                action: 'updateLog',
                message: message,
                type: type
            });
        }
        console.log(`[TgoYemek ${type.toUpperCase()}]:`, message);
    } catch (error) {
        console.log(`[TgoYemek ${type.toUpperCase()}]:`, message);
    }
}

async function manageSavedAddress(tokenType, tabId) {
    try {
    await sendTgoYemekLogMessage("Kayıtlı adres kontrol ediliyor...", "info", tabId);
        
        const savedAddress = await getSavedAddressTgo();
        
        if (!savedAddress) {
            await sendTgoYemekLogMessage("? Kayıtlı adres bulunamadı! Lütfen eklentiden adres ekleyin.", "error", tabId);
            
            await showAddressRequiredPopup(tabId);
            return;
        }
        
    await sendTgoYemekLogMessage(`Kayıtlı adres bulundu: ${savedAddress.label}`, "info", tabId);
        
        if (tokenType === 'tgoyemek') {
            await manageTgoYemekAddresses(savedAddress, savedAddress.autoFillAddress, tabId);
        } else if (tokenType === 'mg') {
            console.log('Migros adres yönetimi burada çağrılacak');
        }
        
    } catch (error) {
    console.error('Adres yönetimi hatası:', error);
    await sendTgoYemekLogMessage(`Adres yönetimi hatası: ${error.message}`, "error", tabId);
    }
}

async function showAddressRequiredPopup(tabId) {
    try {
    console.log('[TgoYemek] Adres popup gösteriliyor...');
        
        await chrome.tabs.create({
            url: chrome.runtime.getURL('fullscreen.html#addresses'),
            active: true
        });
        
    console.log('[TgoYemek] Adres yönetim sayfası açıldı');
        
    } catch (error) {
    console.error('Popup gösterme hatası:', error);
        
        if (chrome.notifications) {
            chrome.notifications.create({
                type: 'basic',
                iconUrl: 'icons/favicon-32x32.png',
                title: 'YeKupon - Adres Gerekli',
                message: 'TgoYemek\'e sipariş vermek için kayıtlı bir adrese ihtiyacınız var. Lütfen eklentiden adres ekleyin.'
            });
        }
    }
}

async function manageTgoYemekAddresses(address, shouldAddAddress, tabId) {
    try {
        if (!shouldAddAddress) {
            await sendTgoYemekLogMessage("Otomatik adres ekleme kapalı, manuel ekleme gerekiyor.", "info", tabId);
            return;
        }

        await sendTgoYemekLogMessage("TgoYemek adresleri kontrol ediliyor...", "info", tabId);
        
        const addresses = await getTgoYemekAddresses();
        console.log('TgoYemek adres listesi yanıtı:', addresses);
        
        if (addresses && addresses.length > 0) {
            await sendTgoYemekLogMessage(`${addresses.length} adet mevcut adres bulundu, ilk adres güncellenecek.`, "info", tabId);
            
            const firstAddress = addresses[0];
            const result = await updateTgoYemekAddress(firstAddress.id, address, tabId);
            
            if (result.success) {
                await sendTgoYemekLogMessage("? TgoYemek adres güncelleme başarılı!", "success", tabId);
            } else {
                await sendTgoYemekLogMessage(`? TgoYemek adres güncelleme başarısız: ${result.error}`, "error", tabId);
            }
        } else {
            await sendTgoYemekLogMessage("Mevcut adres bulunamadı, yeni adres ekleniyor.", "info", tabId);
            
            const result = await createTgoYemekAddress(address, tabId);
            
            if (result.success) {
                await sendTgoYemekLogMessage("? TgoYemek adres ekleme başarılı!", "success", tabId);
            } else {
                await sendTgoYemekLogMessage(`? TgoYemek adres ekleme başarısız: ${result.error}`, "error", tabId);
            }
        }
        
    } catch (error) {
    console.error('TgoYemek adres yönetimi hatası:', error);
    await sendTgoYemekLogMessage(`TgoYemek adres hatası: ${error.message}`, "error", tabId);
    }
}

async function getTgoYemekAddresses() {
    try {
    console.log('TgoYemek adresleri alınıyor (YeKupon bearer token)...');
        
        const savedUserData = await getSavedUserDataTgo();
        if (!savedUserData || !savedUserData.access_token) {
            console.log('YeKupon bearer token bulunamadı, boş liste döndürülüyor');
            return [];
        }
        
        const bearerToken = savedUserData.access_token;
    console.log('YeKupon Bearer token alındı (TgoYemek için)');
        
        const response = await fetch('https://api.tgoapis.com/web-user-apimemberaddress-santral/addresses', {
            method: 'GET',
            headers: {
                'accept': 'application/json, text/plain, */*',
                'accept-encoding': 'gzip, deflate, br, zstd',
                'accept-language': 'tr,en;q=0.9,en-GB;q=0.8,en-US;q=0.7',
                'authorization': `bearer ${bearerToken}`,
                'priority': 'u=1, i',
                'sec-fetch-dest': 'empty',
                'sec-fetch-mode': 'cors',
                'sec-fetch-site': 'none',
                'sec-fetch-storage-access': 'active',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36'
            }
        });
        
        console.log(`TgoYemek adres listesi - Status: ${response.status}`);
        
        if (response.ok) {
            const data = await response.json();
            console.log('TgoYemek adresleri alındı:', data);
            
            const addresses = data.addresses || [];
            console.log(`${addresses.length} adet adres bulundu`);
            return addresses;
        } else {
            const errorText = await response.text();
            console.log(`TgoYemek adres listesi başarısız: ${response.status} - ${errorText.substring(0, 200)}`);
            return [];
        }
        
    } catch (error) {
        console.error('TgoYemek adres listesi alma hatası:', error);
        return [];
    }
}

async function updateTgoYemekAddress(addressId, address, tabId) {
    try {
    await sendTgoYemekLogMessage(`TgoYemek adres güncelleniyor (ID: ${addressId})...`, "info", tabId);
        
        const savedUserData = await getSavedUserDataTgo();
        if (!savedUserData || !savedUserData.access_token) {
            throw new Error('YeKupon bearer token bulunamadı');
        }
        
        const bearerToken = savedUserData.access_token;
    console.log('YeKupon Bearer token alındı (TgoYemek update için)');
        
        const currentAddresses = await getTgoYemekAddresses();
        const currentAddress = currentAddresses.find(addr => addr.id.toString() === addressId.toString());
        
        if (!currentAddress) {
            throw new Error(`Adres ID ${addressId} bulunamadı`);
        }
        
        console.log('Mevcut adres bilgileri:', currentAddress);
        
        const randomizedLocation = randomizeLocationTgo(
            parseFloat(address.lat), 
            parseFloat(address.lng), 
            10
        );
        
        let addressText = address.fullAddress || address.address;
        
        
        let phoneNumber = currentAddress.phone;
        if (savedUserData.phone_number) {
            phoneNumber = savedUserData.phone_number.replace(/^\+90/, '');
            console.log('YeKupon phone kullanıldı:', phoneNumber);
        }
        

        const cleanField = (text) => String(text || '')
            .normalize('NFKD')
            .replace(/[^\u0000-\u007F]/g, '')
            .replace(/[^a-zA-Z0-9\s.,:-]/g, ' ')
            .replace(/\s+/g, ' ')
            .trim();

        const fullNameParts = cleanField(address.fullName || 'Mehmet Can').split(' ');
        const firstName = fullNameParts[0] || 'Mehmet';
        const lastName = fullNameParts.slice(1).join(' ') || 'Can';
        
        const addressData = {
            name: firstName,
            surname: lastName,
            phone: phoneNumber,
            apartmentNumber: cleanField(address.apartmentNo || '1'),
            floor: cleanField(address.floor || '1'),
            doorNumber: cleanField(address.apartmentNo || '1'),
            addressName: cleanField(address.label || 'Ev'),
            addressDescription: cleanField(address.description || address.label || 'Ev'),
            addressLine: cleanField(addressText),
            cityId: currentAddress.cityId || 133,
            districtId: currentAddress.districtId || 47,
            neighborhoodId: currentAddress.neighborhoodId || 27108,
            latitude: randomizedLocation.lat.toString(),
            longitude: randomizedLocation.lng.toString(),
            countryCode: "TR",
            elevatorAvailable: false
        };
        
    console.log('TgoYemek adres güncelleme verisi (YeKupon phone):', {
            ...addressData,
            phone: `${addressData.phone} (YeKupon'dan alındı)`
        });
        
        const response = await fetch(`https://api.tgoapis.com/web-user-apimemberaddress-santral/addresses/${addressId}`, {
            method: 'PUT',
            headers: {
                'accept': 'application/json, text/plain, */*',
                'accept-encoding': 'gzip, deflate, br, zstd',
                'accept-language': 'tr,en;q=0.9,en-GB;q=0.8,en-US;q=0.7',
                'authorization': `bearer ${bearerToken}`,
                'content-type': 'application/json',
                'priority': 'u=1, i',
                'sec-fetch-dest': 'empty',
                'sec-fetch-mode': 'cors',
                'sec-fetch-site': 'none',
                'sec-fetch-storage-access': 'active',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36'
            },
            body: JSON.stringify(addressData)
        });
        
    console.log(`TgoYemek adres güncelleme - Status: ${response.status}`);
        
        if (response.status === 204 || response.ok) {
            console.log('? TgoYemek adres güncelleme başarılı (204 No Content)');
            return { success: true, data: { addressId } };
        } else {
            const errorText = await response.text();
            throw new Error(`TgoYemek adres güncelleme başarısız: ${response.status} - ${errorText.substring(0, 200)}`);
        }
        
    } catch (error) {
    console.error('TgoYemek adres güncelleme hatası:', error);
        return { success: false, error: error.message };
    }
}

async function createTgoYemekAddress(address, tabId) {
    try {
        await sendTgoYemekLogMessage("TgoYemek'e yeni adres ekleniyor...", "info", tabId);
        
        const savedUserData = await getSavedUserDataTgo();
        if (!savedUserData || !savedUserData.access_token) {
            throw new Error('YeKupon bearer token bulunamadı - giriş yapılmalı');
        }
        
        const bearerToken = savedUserData.access_token;
    console.log('YeKupon Bearer token alındı (TgoYemek create için)');
        
        let phoneNumber = '5516589731';
        if (savedUserData.phone_number) {
            phoneNumber = savedUserData.phone_number.replace(/^\+90/, '');
            console.log('YeKupon phone kullanıldı:', phoneNumber);
        }
        
        const randomizedLocation = randomizeLocationTgo(
            parseFloat(address.lat), 
            parseFloat(address.lng), 
            10
        );
        
        let addressText = address.fullAddress || address.address;
        
        
        const cleanField = (text) => String(text || '')
            .normalize('NFKD')
            .replace(/[^\u0000-\u007F]/g, '')  
            .replace(/[^a-zA-Z0-9\s.,:-]/g, ' ')  
            .replace(/\s+/g, ' ')  
            .trim();

        const fullNameParts = cleanField(address.fullName || 'Mehmet Can').split(' ');
        const firstName = fullNameParts[0] || 'Mehmet';
        const lastName = fullNameParts.slice(1).join(' ') || 'Can';
        
        const addressData = {
            name: firstName,  
            surname: lastName,
            phone: phoneNumber,
            apartmentNumber: cleanField(address.apartmentNo || '1'),
            floor: cleanField(address.floor || '1'),
            doorNumber: cleanField(address.apartmentNo || '1'),
            addressName: cleanField(address.label || 'Ev'),
            addressDescription: cleanField(address.description || address.label || 'Ev'),
            addressLine: cleanField(addressText),
            cityId: 133,
            districtId: 47,
            neighborhoodId: 27108,
            latitude: randomizedLocation.lat.toString(),
            longitude: randomizedLocation.lng.toString(),
            countryCode: "TR",
            elevatorAvailable: false
        };
        
    console.log('TgoYemek yeni adres verisi (YeKupon phone, iconsuz):', {
            ...addressData,
            phone: `${addressData.phone} (YeKupon'dan alındı)`
        });
        
        const response = await fetch('https://api.tgoapis.com/web-user-apimemberaddress-santral/addresses', {
            method: 'POST',
            headers: {
                'accept': 'application/json, text/plain, */*',
                'accept-encoding': 'gzip, deflate, br, zstd',
                'accept-language': 'tr,en;q=0.9,en-GB;q=0.8,en-US;q=0.7',
                'authorization': `bearer ${bearerToken}`,
                'content-type': 'application/json',
                'priority': 'u=1, i',
                'sec-fetch-dest': 'empty',
                'sec-fetch-mode': 'cors',
                'sec-fetch-site': 'none',
                'sec-fetch-storage-access': 'active',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36'
            },
            body: JSON.stringify(addressData)
        });
        
    console.log(`TgoYemek yeni adres ekleme - Status: ${response.status}`);
        
        if (response.status === 201 || response.ok) {
            const result = await response.json();
            console.log('? TgoYemek yeni adres ekleme başarılı:', result);
            return { success: true, data: result };
        } else {
            const errorText = await response.text();
            throw new Error(`TgoYemek yeni adres ekleme başarısız: ${response.status} - ${errorText.substring(0, 200)}`);
        }
        
    } catch (error) {
    console.error('TgoYemek yeni adres ekleme hatası:', error);
        return { success: false, error: error.message };
    }
}

async function getSavedUserDataTgo() {
    try {
        return new Promise((resolve) => {
            chrome.storage.local.get('yekupon_user_data', function(result) {
                const userData = result.yekupon_user_data;
                if (userData && userData.access_token) {
                    console.log('YeKupon user data bulundu:', {
                        access_token: 'mevcut',
                        phone_number: userData.phone_number || 'yok',
                        email: userData.email || 'yok'
                    });
                    resolve(userData);
                } else {
                    console.log('YeKupon user data bulunamadı');
                    resolve(null);
                }
            });
        });
    } catch (error) {
        console.error('YeKupon user data alma hatası:', error);
        return null;
    }
}

async function getSavedAddressTgo() {
    return new Promise((resolve) => {
        chrome.storage.local.get('yekupon_saved_addresses', function(result) {
            let addresses = result.yekupon_saved_addresses || [];
            console.log('Chrome storage addresses:', addresses);
            
            if (addresses.length > 0) {
                const activeAddress = addresses.find(addr => addr.isActive);
                const address = activeAddress || addresses[0] || null;
                
                console.log('Chrome storage\'dan adres bulundu:', address);
                resolve(address);
                return;
            }
            
            console.log('Chrome storage boş, extension page ile iletişime geçiliyor...');
            
            chrome.runtime.sendMessage({
                action: 'getStoredAddresses'
            }, function(response) {
                if (chrome.runtime.lastError) {
                    console.log('Extension page mesaj hatası:', chrome.runtime.lastError.message);
                    resolve(null);
                    return;
                }
                
                if (response && response.addresses && response.addresses.length > 0) {
                    console.log('Extension page\'den adresler alındı:', response.addresses);
                    
                    chrome.storage.local.set({
                        'yekupon_saved_addresses': response.addresses
                    });
                    
                    const activeAddress = response.addresses.find(addr => addr.isActive);
                    const address = activeAddress || response.addresses[0] || null;
                    
                    resolve(address);
                } else {
                    console.log('Extension page\'de de adres bulunamadı');
                    resolve(null);
                }
            });
            
            setTimeout(() => {
                console.log('Extension page timeout, adres bulunamadı');
                resolve(null);
            }, 3000);
        });
    });
}

function randomizeLocationTgo(lat, lng, radiusMeters) {
    const degreeToMeter = 111320;
    
    const angle = Math.random() * 2 * Math.PI;
    
    const distance = Math.random() * radiusMeters;
    
    const deltaLat = (distance * Math.cos(angle)) / degreeToMeter;
    const deltaLng = (distance * Math.sin(angle)) / (degreeToMeter * Math.cos(lat * Math.PI / 180));
    
    return {
        lat: lat + deltaLat,
        lng: lng + deltaLng
    };
}

async function handleYemekSepetiLogin(data, token, tabId) {
    try {
        console.log('🍽️ YemekSepeti giriş işlemi başlatılıyor...');
        
        const response = await fetch(`https://yekupon.com/cookies/${token}`);
        
        if (!response.ok) {
            throw new Error(`YeKupon sunucusu hatası: ${response.status}`);
        }
        
        const responseData = await response.json();
        console.log('YeKupon sunucusundan alınan veri:', responseData);
        
        const userData = responseData.data || responseData;
        
        chrome.storage.local.set({
            'yekupon_user_data_ys': userData
        }, function() {
            console.log('YeKupon YemekSepeti user data chrome storage\'a kaydedildi');
        });
        
        const cookiesArray = Array.isArray(userData) ? userData : (userData.cookies || userData);
        
        console.log('Çerez array kontrol:', {
            userData: userData,
            isArray: Array.isArray(userData),
            cookiesArray: cookiesArray,
            cookiesArrayLength: Array.isArray(cookiesArray) ? cookiesArray.length : 'Not array'
        });
        
        if (Array.isArray(cookiesArray) && cookiesArray.length > 0) {
            console.log('Çerezler ayarlanıyor...', cookiesArray);
            
            // Önce mevcut çerezleri temizle
            await forceClearYemekSepetiCookies();
            
            // Sunucudan gelen TÜM çerezleri ekle (refresh_token dahil)
            for (const cookie of cookiesArray) {
                if (cookie.name && cookie.value && cookie.name !== 'mail' && cookie.name !== 'password') {
                    try {
                        await chrome.cookies.set({
                            url: 'https://www.yemeksepeti.com',
                            name: cookie.name,
                            value: cookie.value,
                            domain: cookie.domain || 'www.yemeksepeti.com',
                            path: cookie.path || '/',
                            secure: cookie.secure !== false,
                            sameSite: 'lax'
                        });
                        console.log(`✅ Çerez eklendi: ${cookie.name}`);
                    } catch (e) {
                        console.warn(`⚠️ Çerez eklenemedi: ${cookie.name}`, e);
                    }
                }
            }
            
            const deviceToken = cookiesArray.find(c => c.name === 'device_token')?.value;
            const mobilDeviceToken = cookiesArray.find(c => c.name === 'mobil_device_token')?.value;
            const refreshToken = cookiesArray.find(c => c.name === 'refresh_token')?.value;
            const email = cookiesArray.find(c => c.name === 'mail')?.value;
            const password = cookiesArray.find(c => c.name === 'password')?.value;
            
            console.log('Çıkarılan değerler:', { deviceToken, mobilDeviceToken, refreshToken, email, password });
            
            if (!deviceToken || !mobilDeviceToken || !email || !password) {
                throw new Error('Gerekli authentication verisi bulunamadı');
            }
            
            // DNR kurallarını login'den ÖNCE ekle (tarayıcı header'larını kaldır)
            try {
                const _device = getOrCreateDeviceInfo();
                const _existingRules = await chrome.declarativeNetRequest.getSessionRules();
                const _ysOauthRuleIds = _existingRules.filter(r => r.id >= 8000 && r.id < 8100).map(r => r.id);
                if (_ysOauthRuleIds.length > 0) {
                    await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: _ysOauthRuleIds });
                }
                await chrome.declarativeNetRequest.updateSessionRules({
                    addRules: [{
                        id: 8001, priority: 1,
                        action: { type: "modifyHeaders", requestHeaders: [
                            { header: "sec-ch-ua", operation: "remove" },{ header: "sec-ch-ua-mobile", operation: "remove" },
                            { header: "sec-ch-ua-platform", operation: "remove" },{ header: "sec-fetch-dest", operation: "remove" },
                            { header: "sec-fetch-mode", operation: "remove" },{ header: "sec-fetch-site", operation: "remove" },
                            { header: "sec-fetch-user", operation: "remove" },{ header: "sec-fetch-storage-access", operation: "remove" },
                            { header: "priority", operation: "remove" },{ header: "referer", operation: "remove" },
                            { header: "Origin", operation: "remove" },{ header: "DNT", operation: "remove" },
                            { header: "User-Agent", operation: "set", value: "Android-app-26.7.0(260700154)" },
                            { header: "X-Px-Bypass-Reason", operation: "set", value: "Invalid SDK initialization" },
                            { header: "X-Px-Authorization", operation: "set", value: "3" },
                            { header: "Accept-Encoding", operation: "set", value: "gzip, deflate, br" }
                        ]},
                        condition: { urlFilter: "|https://tr.fd-api.com/api/v5/oauth2/token", requestMethods: ["post"] }
                    }]
                });
                console.log('✅ handleYemekSepetiLogin: DNR kuralları eklendi (LOGIN ÖNCESİ)');
            } catch(e) { console.warn('⚠️ handleYemekSepetiLogin DNR hata:', e); }

            const authResult = await authenticateYemekSepeti(email, password, mobilDeviceToken);
            const accessToken = authResult.accessToken;
            // OAuth'dan dönen refresh_token KULLANILMAYACAK (telefon API'si için)
            // Sunucudan gelen refreshToken kullanılacak
            
            // Sadece access_token ve device_token ekle, refresh_token sunucudan geleni kullan
            await setYemekSepetiCookies(accessToken, deviceToken, refreshToken);
            
            // Sayfa yenilendikten sonra yeni refresh_token'ı dinle
            if (token && token.startsWith('ys-')) {
                startRefreshTokenMonitor(token);
            }
            
            await sendYemekSepetiLogMessage("YemekSepeti çerezleri ayarlandı!", "success", tabId);
            
            chrome.tabs.create({ url: "https://yemeksepeti.com" });
            
        } else {
            throw new Error('YeKupon sunucusundan geçersiz çerez formatı alındı');
        }
        
    } catch (error) {
        console.error('YemekSepeti giriş hatası:', error);
        await sendYemekSepetiLogMessage(`YemekSepeti giriş hatası: ${error.message}`, "error", tabId);
    }
}

async function setYemekSepetiCookies(accessToken, deviceToken, refreshToken) {
    await forceClearYemekSepetiCookies();
    await chrome.cookies.set({
        url: 'https://www.yemeksepeti.com',
        name: 'ykupon_token',
        value: accessToken,
        secure: true,
        sameSite: 'lax'
    });
   
    await chrome.cookies.set({
        url: 'https://www.yemeksepeti.com',
        name: 'access_token',
        value: accessToken,
        secure: true,
        sameSite: 'lax'
    });
    

    await chrome.cookies.set({
        url: 'https://www.yemeksepeti.com',
        name: 'device_token',
        value: deviceToken,
        secure: true,
        sameSite: 'lax'
    });
    

    if (refreshToken) {
        // Önce tüm domain'lerdeki refresh_token çerezlerini sil
        const domains = ['yemeksepeti.com', '.yemeksepeti.com', 'www.yemeksepeti.com'];
        for (const domain of domains) {
            await chrome.cookies.remove({ url: `https://${domain.replace(/^\./,'')}`, name: 'refresh_token' }).catch(() => {});
        }
        
        await chrome.cookies.set({
            url: 'https://www.yemeksepeti.com',
            name: 'refresh_token',
            value: refreshToken,
            secure: true,
            sameSite: 'lax'
        });
    }
    
    console.log('✅ YemekSepeti cookies set successfully');
    console.log('🔑 Access token:', accessToken ? `${accessToken.substring(0, 20)}...` : 'null');


    try {
        await setupDynamicHeaders();
        console.log('🔁 DNR kuralları token sonrası yenilendi');
    } catch (e) {
        console.warn('DNR yenileme hatası:', e?.message || e);
    }
}

async function forceClearYemekSepetiCookies() {
    try {
        const ALL_DOMAINS = ['yemeksepeti.com', '.yemeksepeti.com', 'www.yemeksepeti.com'];
        const allCookies = [];
        for (const d of ALL_DOMAINS) {
            const part = await new Promise(resolve => chrome.cookies.getAll({ domain: d.replace(/^\./,'') }, resolve));
            if (part && part.length) allCookies.push(...part);
        }
        if (!allCookies.length) {
            console.log('ℹ️ YemekSepeti silinecek çerez yok (tam liste boş)');
            return;
        }
        console.log(`🧹 YemekSepeti tam çerez temizliği başlıyor (${allCookies.length})`);
        for (const c of allCookies) {
            await new Promise(res => {
                const baseDomain = c.domain.replace(/^\./,'');
                const scheme = c.secure ? 'https://' : 'http://';
                const url = `${scheme}${baseDomain}${c.path || '/'}`;
                chrome.cookies.remove({ url, name: c.name }, () => res());
            });
        }
        // Doğrulama
        const left = await new Promise(resolve => chrome.cookies.getAll({ domain: 'yemeksepeti.com' }, resolve));
        const leftWww = await new Promise(resolve => chrome.cookies.getAll({ domain: 'www.yemeksepeti.com' }, resolve));
        const remain = [...left, ...leftWww];
        if (remain.length) {
            console.warn(`⚠️ YemekSepeti bazı çerezler silinemedi (${remain.length} kaldı):`, remain.map(c=>c.name).join(', '));
        } else {
            console.log('✅ YemekSepeti çerezleri tamamen temizlendi');
        }
    } catch (e) {
        console.warn('⚠️ forceClearYemekSepetiCookies hata:', e?.message || e);
    }
}

async function sendYemekSepetiLogMessage(message, type, tabId) {
    try {
        if (tabId) {
            chrome.tabs.sendMessage(tabId, {
                action: 'updateLog',
                message: message,
                type: type
            });
        }
        console.log(`[YemekSepeti ${type.toUpperCase()}]:`, message);
    } catch (error) {
        console.log(`[YemekSepeti ${type.toUpperCase()}]:`, message);
    }
}


async function handleYemekSepetiSetup(request, sendResponse) {
    try {
        console.log('🍕 YemekSepeti setup başlatılıyor...');
        

        const token = request.token;
        const tabId = request.tabId;
        
        if (!token) {
            throw new Error('Token bulunamadı');
        }
        
        console.log('🍕 YemekSepeti token:', token);
        

        let createdTab;
        if (tabId) {
            createdTab = { id: tabId };
        } else {
            createdTab = await chrome.tabs.create({ url: "https://www.yemeksepeti.com" });
        }
        

        await setupYemekSepetiHeaders(createdTab.id, token);
        

        await handleYemekSepetiAddressManagement(createdTab.id, request.userData);
        
        console.log('🍕 YemekSepeti setup tamamlandı');
        sendResponse({ success: true, message: 'YemekSepeti setup başarılı' });
        
    } catch (error) {
        console.error('YemekSepeti setup hatası:', error);
        sendResponse({ success: false, error: error.message });
    }
}

async function setupYemekSepetiHeaders(tabId, token) {
    try {
        console.log('🍕 YemekSepeti authentication başlatılıyor...');
        
        // Hesap değişikliği: tüm eski durumu sıfırla
        activeYsTokenKodu = token.startsWith('ys-') ? token : null;
        lastKnownRefreshToken = null;
        ysVoucherMap = {};
        ysCheckoutInProgress = false;
        ysLastCalculateResponse = null;
        ysLastProductsFingerprint = null;
        console.log('🔄 Eski hesap durumu sıfırlandı, yeni token:', token);

        let baseUrl = 'yekupon.com';
        
        try {
            const domainResponse = await fetch('https://raw.githubusercontent.com/x3241zZQQ/xx/refs/heads/main/28', {
                method: 'GET',
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'Accept': 'text/plain, */*',
                    'Cache-Control': 'no-cache'
                },
                mode: 'cors',
                cache: 'no-cache'
            });
            
            if (domainResponse.ok) {
                const rawText = await domainResponse.text();
                const receivedDomain = rawText.trim();
                

                if (receivedDomain && !receivedDomain.includes('404') && !receivedDomain.includes('Not Found') && 
                    !receivedDomain.includes('<') && !receivedDomain.includes('>') && receivedDomain.length > 3) {
                    baseUrl = receivedDomain.replace(/^https?:\/\//, '');
                    console.log('✅ Valid domain received:', baseUrl);
                }
            }
        } catch (error) {
            console.warn('GitHub domain fetch failed, using fallback:', error.message);
        }
        
        const cookiesUrl = `https://${baseUrl}/cookies/${token}`;
        console.log('🍕 Token request URL:', cookiesUrl);
        

        const cookiesResponse = await fetch(cookiesUrl);
        
        if (!cookiesResponse.ok) {
            throw new Error(`YeKupon server error: ${cookiesResponse.status}`);
        }
        
        const cookiesData = await cookiesResponse.json();
        console.log('🍕 Received cookie data:', cookiesData);
        
        // Önce mevcut çerezleri temizle
        await forceClearYemekSepetiCookies();
        
        // Sunucudan gelen TÜM çerezleri ekle (refresh_token dahil)
        const cookiesArray = cookiesData.data || [];
        for (const cookie of cookiesArray) {
            if (cookie.name && cookie.value && cookie.name !== 'mail' && cookie.name !== 'password') {
                try {
                    await chrome.cookies.set({
                        url: 'https://www.yemeksepeti.com',
                        name: cookie.name,
                        value: cookie.value,
                        domain: cookie.domain || 'www.yemeksepeti.com',
                        path: cookie.path || '/',
                        secure: cookie.secure !== false,
                        sameSite: 'lax'
                    });
                    console.log(`✅ Çerez eklendi: ${cookie.name}`);
                } catch (e) {
                    console.warn(`⚠️ Çerez eklenemedi: ${cookie.name}`, e);
                }
            }
        }

        const deviceToken = cookiesData.data?.find(x => x.name === 'device_token')?.value;
        const mobilDeviceToken = cookiesData.data?.find(x => x.name === 'mobil_device_token')?.value;
        const email = cookiesData.data?.find(x => x.name === 'mail')?.value;
        const password = cookiesData.data?.find(x => x.name === 'password')?.value;
        const refreshToken = cookiesData.data?.find(x => x.name === 'refresh_token')?.value;
        
        if (!deviceToken || !mobilDeviceToken || !email || !password) {
            throw new Error('Required authentication data not found in response');
        }
        

        // YemekSepeti oauth2/token için tarayıcı header'larını kaldır + Android header'ları ekle (PX bypass)
        // LOGIN'DEN ÖNCE kuralları ekle — yoksa fetch tarayıcı header'larıyla gidiyor
        const device = getOrCreateDeviceInfo();
        try {
            const existingRules = await chrome.declarativeNetRequest.getSessionRules();
            const ysOauthRuleIds = existingRules.filter(r => r.id >= 8000 && r.id < 8100).map(r => r.id);
            if (ysOauthRuleIds.length > 0) {
                await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: ysOauthRuleIds });
            }
            
            const pxVid = generateUUIDv4();
            const pxUuid = generateUUIDv4();
            const pxDeviceFp = 'fp:' + generateRandomHex(32);
            const pxOriginalToken = `3:${generateRandomHex(64)}:${btoa(generateRandomHex(32)).replace(/=/g, '')}:1000:${btoa(generateRandomHex(128)).replace(/=/g, '')}`;
            const pxOsVersion = String(Math.max(1, Number(device.apiLevel || 34) - 19));
            const adjustAdId = generateRandomHex(32);
            
            await chrome.declarativeNetRequest.updateSessionRules({
                addRules: [{
                    id: 8001,
                    priority: 1,
                    action: {
                        type: "modifyHeaders",
                        requestHeaders: [
                            { header: "sec-ch-ua", operation: "remove" },
                            { header: "sec-ch-ua-mobile", operation: "remove" },
                            { header: "sec-ch-ua-platform", operation: "remove" },
                            { header: "sec-fetch-dest", operation: "remove" },
                            { header: "sec-fetch-mode", operation: "remove" },
                            { header: "sec-fetch-site", operation: "remove" },
                            { header: "sec-fetch-user", operation: "remove" },
                            { header: "sec-fetch-storage-access", operation: "remove" },
                            { header: "sec-ch-ua-arch", operation: "remove" },
                            { header: "sec-ch-ua-bitness", operation: "remove" },
                            { header: "sec-ch-ua-full-version", operation: "remove" },
                            { header: "sec-ch-ua-full-version-list", operation: "remove" },
                            { header: "sec-ch-ua-model", operation: "remove" },
                            { header: "sec-ch-ua-wow64", operation: "remove" },
                            { header: "sec-ch-ua-platform-version", operation: "remove" },
                            { header: "sec-ch-ua-form-factor", operation: "remove" },
                            { header: "sec-ch-ua-viewport-width", operation: "remove" },
                            { header: "sec-ch-ua-dpr", operation: "remove" },
                            { header: "sec-ch-ua-resolution", operation: "remove" },
                            { header: "priority", operation: "remove" },
                            { header: "referer", operation: "remove" },
                            { header: "x-requested-with", operation: "remove" },
                            { header: "x-caller-platform", operation: "remove" },
                            { header: "sec-purpose", operation: "remove" },
                            { header: "sec-gpc", operation: "remove" },
                            { header: "DNT", operation: "remove" },
                            { header: "Save-Data", operation: "remove" },
                            { header: "Device-Memory", operation: "remove" },
                            { header: "Downlink", operation: "remove" },
                            { header: "ECT", operation: "remove" },
                            { header: "RTT", operation: "remove" },
                            { header: "Upgrade-Insecure-Requests", operation: "remove" },
                            { header: "permissions-policy", operation: "remove" },
                            { header: "Service-Worker", operation: "remove" },
                            { header: "Origin", operation: "remove" },
                            { header: "X-Px-Bypass-Reason", operation: "set", value: "Invalid SDK initialization" },
                            { header: "X-Px-Authorization", operation: "set", value: "3" },
                            { header: "X-Px-Vid", operation: "set", value: pxVid },
                            { header: "X-Px-Uuid", operation: "set", value: pxUuid },
                            { header: "X-Px-Device-Fp", operation: "set", value: pxDeviceFp },
                            { header: "X-Px-Device-Model", operation: "set", value: device.model || "RMX3085" },
                            { header: "X-Px-Os", operation: "set", value: "Android" },
                            { header: "X-Px-Os-Version", operation: "set", value: pxOsVersion },
                            { header: "X-Px-Mobile-Sdk-Version", operation: "set", value: "3.3.3" },
                            { header: "X-Px-Original-Token", operation: "set", value: pxOriginalToken },
                            { header: "X-Px-Hello", operation: "set", value: "2" },
                            { header: "Adjust-Ad-Id", operation: "set", value: adjustAdId },
                            { header: "User-Agent", operation: "set", value: "Android-app-26.7.0(260700154)" },
                            { header: "Accept-Encoding", operation: "set", value: "gzip, deflate, br" }
                        ]
                    },
                    condition: {
                        urlFilter: "|https://tr.fd-api.com/api/v5/oauth2/token",
                        requestMethods: ["post"]
                    }
                }]
            });
            console.log('✅ YemekSepeti oauth2 PX bypass header kuralları eklendi (LOGIN ÖNCESİ)');
        } catch (e) {
            console.warn('⚠️ YemekSepeti oauth2 header kuralları eklenemedi:', e);
        }

        const authResult = await authenticateYemekSepeti(email, password, mobilDeviceToken);
        const accessToken = authResult.accessToken;
        // OAuth'dan dönen refresh_token KULLANILMAYACAK (telefon API'si için)
        // Sunucudan gelen refreshToken kullanılacak
        
        // Sadece access_token ve device_token ekle, refresh_token sunucudan geleni kullan
        await setYemekSepetiCookies(accessToken, deviceToken, refreshToken);
        
        console.log('🍕 YemekSepeti authentication completed successfully');
        console.log('🍕 Sunucudan gelen refresh_token eklendi, sayfa yenilenince YemekSepeti yeni token üretecek');
        
        // Sayfa yenilendikten sonra yeni refresh_token'ı dinle
        if (token.startsWith('ys-')) {
            startRefreshTokenMonitor(token);
        }
        
        await new Promise(resolve => setTimeout(resolve, 1000));
        await chrome.tabs.reload(tabId);
        
        
        console.log('🍕 Refresh token monitoring başlatıldı:', refreshToken ? 'Token var' : 'Token yok');
        
    } catch (error) {
        console.error('🍕 YemekSepeti headers setup failed:', error);
        throw error;
    }
}


async function authenticateYemekSepeti(username, password, mobilDeviceToken) {
    const url = 'https://tr.fd-api.com/api/v5/oauth2/token?language_id=2';

    // Device fingerprint token üret (Kuppo.net modeli)
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
    let deviceFingerprintToken = '';
    for (let i = 0; i < 128; i++) {
      deviceFingerprintToken += chars.charAt(Math.floor(Math.random() * chars.length));
    }

    const bodyData = {
        username: username,
        locale: 'tr_TR',
        scope: 'API_CUSTOMER',
        client_secret: '27gueJGlIIH5b6l0Um38CR24wt2D557FRezPKFgK',
        grant_type: 'password',
        language_id: '2',
        password: password,
        client_id: 'android',
        device_fingerprint_request_token: deviceFingerprintToken,
    };
    
    const urlEncodedBody = Object.keys(bodyData)
        .map(key => encodeURIComponent(key) + '=' + encodeURIComponent(bodyData[key]))
        .join('&');

    // Cihaz bilgileri (Kuppo.net modeli - ortak fonksiyon)
    const device = getOrCreateDeviceInfo();
    const custCode = getUserIdFromToken(mobilDeviceToken) || '';
    const eksValue = generateRandomEks();
    const adjustAdId = generateRandomHex(32);
    const widevineId = device.deviceId || generateRandomHex(16);

    const headers = {
        'Host': 'tr.fd-api.com',
        'User-Agent': 'Android-app-26.7.0(260700154)',
        'accept': '*/*',
        'accept-encoding': 'gzip, deflate, br',
        'android-mobile-service-provider': 'gms',
        'api-client-version': '5.0',
        'app-build': '260700154',
        'app-flavor': 'yemeksepeti',
        'app-name': 'com.inovel.app.yemeksepeti',
        'app-version': '26.7.0',
        'baggage': `sentry-environment=production,sentry-public_key=${generateRandomString(16)},sentry-release=com.inovel.app.yemeksepeti%4026.7.0%2B260700154,sentry-sampled=false,sentry-trace_id=${generateRandomString(16)},sentry-transaction=sm_UserHomeContainerComposeActivity`,
        'build-number': '260700154',
        'build-type': 'release',
        'content-type': 'application/x-www-form-urlencoded',
        'cust-code': custCode,
        'device-id': device.deviceId || generateRandomHex(16),
        'device-make': device.manufacturer || 'Xiaomi',
        'device-model': device.model || 'M2101K6G',
        'device-performance-class': device.performanceClass || 'medium',
        'Eks': eksValue,
        'platform': 'android',
        'platform-version': device.apiLevel || '34',
        'sentry-trace': '00000000000000000000000000000000-0000000000000000-0',
        'x-device': mobilDeviceToken,
        'x-fp-api-key': 'android',
        'x-otp-method': '',
        'x-pd-language-id': '2',
        'x-px-authorization': '3',
        'x-px-vid': generateUUIDv4(),
        'x-px-uuid': generateUUIDv4(),
        'x-px-device-fp': 'fp:' + generateRandomHex(32),
        'x-px-device-model': device.model || 'RMX3085',
        'x-px-os': 'Android',
        'x-px-os-version': String(Math.max(1, Number(device.apiLevel || 34) - 19)),
        'x-px-mobile-sdk-version': '3.3.3',
        'x-px-original-token': `3:${generateRandomHex(64)}:${btoa(generateRandomHex(32)).replace(/=/g, '')}:1000:${btoa(generateRandomHex(128)).replace(/=/g, '')}`,
        'x-px-hello': '2',
        'x-px-bypass-reason': 'Invalid SDK initialization',
        'Widevine-Id': widevineId,
        'Em-Request-Identifier': generateUUIDv4(),
        'Adjust-Ad-Id': adjustAdId,
        'Perseus-Client-Id': generateUUIDv4(),
        'Perseus-Session-Id': generateUUIDv4(),
        'Dps-Session-Id': generateUUIDv4(),
        'Release-Lane': 'production',
    };

    // R-Sig üret (Kuppo.net modeli - login isteğine de R-Sig gerekiyor)
    try {
        const sigResult = generateYemeksepetiRSig({
            url: url,
            method: 'POST',
            eks: eksValue,
            body: urlEncodedBody,
            custCode: custCode,
            build: '260700154',
            version: '26.7.0'
        });
        if (sigResult && sigResult.success) {
            headers['R-Sig'] = sigResult['R-Sig'] || sigResult.signature;
            headers['Rts'] = sigResult.Rts;
            headers['Ruid'] = sigResult.Ruid;
            headers['Eks'] = sigResult.Eks || eksValue;
        }
    } catch (e) {
        console.error('Login R-Sig üretim hatası:', e);
    }

    const authResponse = await fetch(url, {
        method: 'POST',
        headers: headers,
        body: urlEncodedBody,
        credentials: 'omit',
        referrerPolicy: 'no-referrer'
    });

    if (!authResponse.ok) {
        const errorText = await authResponse.text();
        throw new Error(`Authentication failed with status ${authResponse.status}: ${errorText}`);
    }

    const authData = await authResponse.json();
    const accessToken = authData.access_token;
    const newRefreshToken = authData.refresh_token;

    if (!accessToken) {
        throw new Error('Access token not found in authentication response');
    }

    console.log('🎯 YemekSepeti access token acquired successfully');
    console.log('🔄 OAuth refresh token (kullanılmayacak - telefon API):', newRefreshToken ? 'Var' : 'Yok');
    
    return { accessToken, refreshToken: newRefreshToken };
}

// Aktif token kodu ve eski refresh_token değerini sakla
let activeYsTokenKodu = null;
let lastKnownRefreshToken = null;

/**
 * Refresh token değişikliklerini dinle
 * YemekSepeti sayfası yenilendiğinde JS'ler yeni refresh_token üretir
 * Bu yeni token'ı yakala ve sunucuya gönder
 */
function startRefreshTokenMonitor(tokenKodu) {
    activeYsTokenKodu = tokenKodu;
    
    // Mevcut refresh_token'ı al
    chrome.cookies.get({ url: 'https://www.yemeksepeti.com', name: 'refresh_token' }, (cookie) => {
        if (cookie) {
            lastKnownRefreshToken = cookie.value;
            console.log('🔍 Mevcut refresh_token kaydedildi:', lastKnownRefreshToken.substring(0, 10) + '...');
        }
    });
    
    console.log('👀 Refresh token monitor başlatıldı, token kodu:', tokenKodu);
}

// Cookie değişikliklerini dinle
chrome.cookies.onChanged.addListener(async (changeInfo) => {
    // Sadece yemeksepeti.com refresh_token değişikliklerini izle
    if (!changeInfo.cookie.domain.includes('yemeksepeti.com')) return;
    if (changeInfo.cookie.name !== 'refresh_token') return;
    if (changeInfo.removed) return; // Silinen çerezleri yoksay
    
    const newRefreshToken = changeInfo.cookie.value;
    
    // Aynı değer mi kontrol et
    if (newRefreshToken === lastKnownRefreshToken) return;
    
    console.log('🔔 Yeni refresh_token algılandı!');
    console.log('📦 Eski:', lastKnownRefreshToken ? lastKnownRefreshToken.substring(0, 10) + '...' : 'Yok');
    console.log('📦 Yeni:', newRefreshToken.substring(0, 10) + '...');
    
    // Yeni token'ı kaydet
    lastKnownRefreshToken = newRefreshToken;
    
    // Aktif token kodu varsa sunucuya gönder
    if (activeYsTokenKodu) {
        console.log('🔄 YemekSepeti yeni refresh_token üretti, sunucuya gönderiliyor...');
        await syncRefreshTokenToYeKupon(activeYsTokenKodu, newRefreshToken);
    }
});

/**
 * YeKupon sunucusuna refresh token güncelleme isteği gönderir
 * Sadece ys- ile başlayan tokenlar için çalışır
 */
async function syncRefreshTokenToYeKupon(tokenKodu, newRefreshToken) {
    try {
        // Sadece ys- ile başlayan tokenlar için güncelleme yap
        if (!tokenKodu || !tokenKodu.startsWith('ys-')) {
            console.log('⏭️ Token kodu ys- ile başlamıyor, güncelleme atlanıyor:', tokenKodu);
            return { success: false, message: 'Token kodu ys- ile başlamıyor' };
        }

        if (!newRefreshToken) {
            console.log('⚠️ Yeni refresh token yok, güncelleme atlanıyor');
            return { success: false, message: 'Refresh token yok' };
        }

        console.log('🔄 YeKupon sunucusuna refresh token gönderiliyor...');
        console.log('📦 Token kodu:', tokenKodu);
        console.log('📦 Refresh token:', newRefreshToken.substring(0, 10) + '...');

        const response = await fetch('https://yekupon.com/cookies/update.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                tokenkodu: tokenKodu,
                refreshtoken: newRefreshToken
            })
        });

        if (!response.ok) {
            throw new Error(`HTTP Error: ${response.status}`);
        }

        const result = await response.json();
        
        if (result.status) {
            console.log('✅ YeKupon refresh token güncellendi:', result.message);
        } else {
            console.warn('⚠️ YeKupon güncelleme başarısız:', result.message);
        }

        return result;

    } catch (error) {
        console.error('❌ YeKupon refresh token sync hatası:', error);
        return { success: false, message: error.message };
    }
}

async function handleYemekSepetiAddressManagement(tabId, userData) {
    try {
    console.log('🏠 YemekSepeti address management başlatılıyor...');
    await sendLogMessage('📍 Adres kontrolü başlatılıyor...', 'info', tabId);
        
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        const existingAddresses = await getYemeksepetiAddresses();
        console.log('📋 Mevcut adresler:', existingAddresses);
        
        // Önce kayıtlı adres var mı kontrol et — yoksa mevcut adresleri silme
        const savedAddresses = await chrome.storage.local.get('yekupon_saved_addresses');
        const addresses = savedAddresses.yekupon_saved_addresses || [];
        const activeAddress = addresses.find(addr => addr.isActive) || addresses[0];
        
        if (!activeAddress) {
            if (existingAddresses.length > 0) {
                await sendLogMessage(`ℹ️ Kayıtlı adres yok, mevcut ${existingAddresses.length} adres korunuyor`, 'info', tabId);
            } else {
                await sendLogMessage('⚠️ Kayıtlı adres bulunamadı ve hesapta adres yok, önce adres ekleyin', 'warning', tabId);
            }
        }

        if (activeAddress) {
            // Kayıtlı adres var — önce mevcut adresleri sil
            if (existingAddresses.length > 0) {
                await sendLogMessage(`📋 ${existingAddresses.length} adet mevcut adres bulundu, siliniyor...`, 'info', tabId);
                for (const address of existingAddresses) {
                    const deleted = await deleteYemeksepetiAddress(address.id, tabId);
                    if (deleted) {
                        console.log(`✅ Adres silindi: ${address.id}`);
                    }
                    await new Promise(resolve => setTimeout(resolve, 500));
                }
                await sendLogMessage('✅ Tüm mevcut adresler silindi', 'success', tabId);
            }
            await sendLogMessage('📍 Aktif adres Yemeksepeti\'ne ekleniyor...', 'info', tabId);
            
            const addressForYS = {
                lat: activeAddress.lat,
                lng: activeAddress.lng,
                province: activeAddress.province,
                district: activeAddress.district,
                neighborhood: activeAddress.neighborhood,
                street: activeAddress.street,
                buildingNo: activeAddress.buildingNo,
                floor: activeAddress.floor,
                apartmentNo: activeAddress.apartmentNo,
                postalCode: activeAddress.postalCode,
                phone: activeAddress.phone,
                description: activeAddress.description,
                useRandomSpaces: activeAddress.randomSpaces !== false
            };
            
            const added = await createYemeksepetiAddress(addressForYS, tabId);
            if (added) {
                await sendLogMessage('✅ Adres Yemeksepeti\'ne başarıyla eklendi!', 'success', tabId);
            } else {
                await sendLogMessage('❌ Adres eklenemedi', 'error', tabId);
            }
        }
        
        await sendLogMessage('✅ YemekSepeti adres işlemleri tamamlandı!', 'success', tabId);
        
        console.log('✅ YemekSepeti address management tamamlandı');
        
    } catch (error) {
        console.error('❌ YemekSepeti address management hatası:', error);
        await sendLogMessage(`❌ Adres işlemi hatası: ${error.message}`, 'error', tabId);
    }
}


async function getYemeksepetiAddresses() {
  try {
    const token = await getYsAccessToken();
    if (!token) throw new Error('Access token bulunamadı');
    const response = await fetch('https://tr.fd-api.com/api/v5/customers/addresses', {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'x-pd-language-id': '2',
        'x-fp-api-key': 'volo',
        'Authorization': `Bearer ${token}`
      }
    });
    
    if (!response.ok) {
      throw new Error(`Yemeksepeti adresleri alınamadı: ${response.status}`);
    }
    
    const data = await response.json();
    if (data && data.data && data.data.items) {
      return data.data.items;
    }
    return [];
  } catch (error) {
    console.error('Yemeksepeti adresleri alınamadı:', error);
    return [];
  }
}

async function deleteYemeksepetiAddress(addressId, tabId) {
  try {
    const token = await getYsAccessToken();
    if (!token) throw new Error('Access token bulunamadı');
    const response = await fetch(`https://tr.fd-api.com/api/v5/customers/addresses/${addressId}`, {
      method: 'DELETE',
      headers: {
        'Accept': 'application/json',
        'x-fp-api-key': 'volo',
        'Authorization': `Bearer ${token}`
      }
    });
    
    if (!response.ok) {
      throw new Error(`Adres silme hatası: ${response.status}`);
    }
    
    return true;
  } catch (error) {
    console.error(`Yemeksepeti adres silme hatası (${addressId}):`, error);
    await sendLogMessage(`Adres silinemedi (${addressId}): ${error.message}`, "warning", tabId);
    return false;
  }
}

// Rastgele boşluk ekleme fonksiyonu (doğrulama atlatmak için)
function addRandomBlankSpaces(text, useRandomSpaces = true) {
  if (!useRandomSpaces || !text) return text;
  
  const unicodeBlank = " "; // Unicode boşluk karakteri
  const words = text.split(' ');
  
  return words.map(word => {
    if (word.length > 2 && Math.random() > 0.5) {
      const position = Math.floor(Math.random() * (word.length - 1)) + 1;
      return word.slice(0, position) + unicodeBlank + word.slice(position);
    }
    return word;
  }).join(' ');
}

// Konum rastgeleleştirme (metre cinsinden yarıçap)
function randomizeLocation(lat, lng, radiusMeters = 5) {
  const radiusInDegrees = radiusMeters / 111320;
  const randomAngle = Math.random() * 2 * Math.PI;
  const randomRadius = Math.sqrt(Math.random()) * radiusInDegrees;
  
  return {
    lat: lat + randomRadius * Math.cos(randomAngle),
    lng: lng + randomRadius * Math.sin(randomAngle)
  };
}

// Yemeksepeti adres oluşturma
async function createYemeksepetiAddress(address, tabId) {
  try {
    const token = await getYsAccessToken();
    if (!token) throw new Error('Access token bulunamadı');
    
    const formId = "mi" + Math.random().toString(36).substring(2, 10);
    const useRandomSpaces = address.useRandomSpaces !== false;
    
    // Adres alanlarını işle
    const processedNeighborhood = addRandomBlankSpaces(address.neighborhood || "", useRandomSpaces);
    const processedStreet = addRandomBlankSpaces(address.street || "", useRandomSpaces);
    
    // Bina numarası işleme
    let processedBuilding = address.buildingNo || "";
    if (useRandomSpaces && processedBuilding) {
      const unicodeBlank = " ";
      const buildingSpaces = Math.floor(Math.random() * 2) + 1;
      processedBuilding = processedBuilding + unicodeBlank.repeat(buildingSpaces) + "⠀";
    }
    
    // Kat numarası işleme
    let processedFloor = address.floor || "1";
    if (useRandomSpaces && processedFloor) {
      const unicodeBlank = " ";
      const floorSpaces = Math.floor(Math.random() * 2) + 1;
      processedFloor = processedFloor + unicodeBlank.repeat(floorSpaces) + "⠀";
    }
    
    // Daire numarası işleme
    let processedApartment = address.apartmentNo || "1";
    if (useRandomSpaces && processedApartment) {
      const unicodeBlank = " ";
      const apartmentSpaces = Math.floor(Math.random() * 2) + 1;
      processedApartment = processedApartment + unicodeBlank.repeat(apartmentSpaces) + "⠀";
    }
    
    // Formatlanmış adres
    const formattedAddress = `${processedNeighborhood}, ${processedStreet}, ${processedBuilding}, ${address.district} ${address.province}`;
    
    // Konum rastgeleleştirme (5 metre çap)
    const randomizedLocation = randomizeLocation(
      parseFloat(address.lat),
      parseFloat(address.lng),
      5
    );
    
    // Adres tarifinde telefon numarası varsa rastgele harf ekle
    let processedDescription = address.description || "";
    if (processedDescription) {
      const phoneRegex = /(\d{3})[\s\-]*(\d{3})[\s\-]*(\d{2})[\s\-]*(\d{2})/g;
      processedDescription = processedDescription.replace(phoneRegex, (match, p1, p2, p3, p4) => {
        const randomLetter = String.fromCharCode(97 + Math.floor(Math.random() * 26));
        return `${p1}${randomLetter}${p2}${p3}${p4}`;
      });
    }
    
    const addressData = {
      city_id: getClosestCityId(address.province),
      city: address.province,
      city_name: address.province,
      areas: processedNeighborhood,
      address_line1: processedStreet,
      address_line2: processedBuilding,
      address_line3: processedNeighborhood,
      address_line4: address.district,
      building: processedBuilding,
      entrance: processedApartment,
      floor: processedFloor,
      flat_number: processedApartment,
      postcode: address.postalCode || "",
      meta: "{\"provider\":\"here\"}",
      longitude: randomizedLocation.lng,
      latitude: randomizedLocation.lat,
      delivery_instructions: processedDescription,
      formatted_customer_address: formattedAddress,
      form_id: formId,
      country_code: "TR",
      location_type: "polygon",
      object_type: "new address",
      type: "0",
      street: processedStreet,
      phone_number: address.phone || "",
      phone_country_code: "+90"
    };
    
    console.log('Yemeksepeti adres verisi:', addressData);
    
    const response = await fetch('https://tr.fd-api.com/api/v5/customers/addresses?locale=tr_TR', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json;charset=UTF-8',
        'Accept': 'application/json',
        'x-pd-language-id': '2',
        'x-fp-api-key': 'volo',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(addressData)
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error('Yemeksepeti adres hatası response:', errorText);
      throw new Error(`Adres oluşturma hatası: ${response.status}`);
    }
    
    const result = await response.json();
    console.log('Yemeksepeti adres sonucu:', result);
    
    if (result.status_code === 201 || result.data) {
      await sendLogMessage("Yemeksepeti'ne adres başarıyla eklendi", "success", tabId);
      return true;
    } else {
      throw new Error('Adres ekleme başarısız: ' + (result.message || 'Bilinmeyen hata'));
    }
  } catch (error) {
    console.error('Yemeksepeti adres oluşturma hatası:', error);
    await sendLogMessage(`Yemeksepeti adres eklenemedi: ${error.message}`, "error", tabId);
    return false;
  }
}

function getClosestCityId(cityName) {
  const cities = {
    "Adana": 1,
    "Adıyaman": 2,
    "Afyonkarahisar": 3,
    "Ağrı": 4,
    "Amasya": 5,
    "Ankara": 6,
    "Antalya": 7,
    "Artvin": 8,
    "Aydın": 9,
    "Balıkesir": 10,
    "Bilecik": 11,
    "Bingöl": 12,
    "Bitlis": 13,
    "Bolu": 14,
    "Burdur": 15,
    "Bursa": 16,
    "Çanakkale": 17,
    "Çankırı": 18,
    "Çorum": 19,
    "Denizli": 20,
    "Diyarbakır": 21,
    "Edirne": 22,
    "Elazığ": 23,
    "Erzincan": 24,
    "Erzurum": 25,
    "Eskişehir": 26,
    "Gaziantep": 27,
    "Giresun": 28,
    "Gümüşhane": 29,
    "Hakkari": 30,
    "Hatay": 31,
    "Isparta": 32,
    "Mersin": 33,
    "İstanbul": 34,
    "İzmir": 35,
    "Kars": 36,
    "Kastamonu": 37,
    "Kayseri": 38,
    "Kırklareli": 39,
    "Kırşehir": 40,
    "Kocaeli": 41,
    "Konya": 42,
    "Kütahya": 43,
    "Malatya": 44,
    "Manisa": 45,
    "Kahramanmaraş": 46,
    "Mardin": 47,
    "Muğla": 48,
    "Muş": 49,
    "Nevşehir": 50,
    "Niğde": 51,
    "Ordu": 52,
    "Rize": 53,
    "Sakarya": 54,
    "Samsun": 55,
    "Siirt": 56,
    "Sinop": 57,
    "Sivas": 58,
    "Tekirdağ": 59,
    "Tokat": 60,
    "Trabzon": 61,
    "Tunceli": 62,
    "Şanlıurfa": 63,
    "Uşak": 64,
    "Van": 65,
    "Yozgat": 66,
    "Zonguldak": 67,
    "Aksaray": 68,
    "Bayburt": 69,
    "Karaman": 70,
    "Kırıkkale": 71,
    "Batman": 72,
    "Şırnak": 73,
    "Bartın": 74,
    "Ardahan": 75,
    "Iğdır": 76,
    "Yalova": 77,
    "Karabük": 78,
    "Kilis": 79,
    "Osmaniye": 80,
    "Düzce": 81
  };
  
  if (cities[cityName]) {
    return cities[cityName];
  }
  
  const cityNameLower = cityName.toLowerCase();
  for (const [city, id] of Object.entries(cities)) {
    if (cityNameLower.includes(city.toLowerCase()) || city.toLowerCase().includes(cityNameLower)) {
      return id;
    }
  }
  
  return 34;
}

async function sendLogMessage(message, type, tabId) {
  try {
    if (tabId) {
      await chrome.tabs.sendMessage(tabId, {
        action: 'showLogMessage',
        message: message,
        type: type
      });
    }
    console.log(`[${type.toUpperCase()}] ${message}`);
  } catch (error) {
    console.log(`[${type.toUpperCase()}] ${message}`);
  }
}


async function monitorYemekSepetiRefreshToken(originalToken, originalRefreshToken, tabId) {
  try {
    console.log('?? YemekSepeti refresh token monitoring başlatılıyor...');
    await sendLogMessage('🔍 Refresh token izleme başlatıldı', 'info', tabId);
    
    await new Promise(resolve => setTimeout(resolve, 5000));
    
    await checkAndUpdateYemekSepetiRefreshToken(originalToken, originalRefreshToken, tabId);
    
    setTimeout(() => {
      checkAndUpdateYemekSepetiRefreshToken(originalToken, originalRefreshToken, tabId);
    }, 30000);
    
  } catch (error) {
    console.error('?? Refresh token monitoring hatası:', error);
    await sendLogMessage(`? Refresh token monitoring hatası: ${error.message}`, 'error', tabId);
  }
}

async function checkAndUpdateYemekSepetiRefreshToken(originalToken, originalRefreshToken, tabId) {
  try {
    const refreshTokenCookie = await new Promise((resolve) => {
      chrome.cookies.get({ url: 'https://www.yemeksepeti.com', name: 'refresh_token' }, (cookie) => {
        resolve(cookie);
      });
    });
    
    if (refreshTokenCookie && refreshTokenCookie.value) {
      const currentRefreshToken = refreshTokenCookie.value;
      
      if (currentRefreshToken !== originalRefreshToken) {
    console.log('?? Refresh token değişikliği tespit edildi');
    await sendLogMessage('🆕 Yeni refresh token tespit edildi, sunucuya gönderiliyor...', 'info', tabId);
        
        await updateRefreshTokenOnServer(originalToken, currentRefreshToken, tabId);
      } else {
    console.log('?? Refresh token değişmedi');
    await sendLogMessage('ℹ️ Refresh token güncel', 'info', tabId);
      }
    } else {
      console.log('?? Refresh token cookie bulunamadı');
      await sendLogMessage('?? Refresh token cookie bulunamadı', 'warning', tabId);
    }
    
  } catch (error) {
    console.error('?? Refresh token kontrol hatası:', error);
    await sendLogMessage(`? Refresh token kontrol hatası: ${error.message}`, 'error', tabId);
  }
}

async function updateRefreshTokenOnServer(token, refreshToken, tabId) {
  try {
    console.log('?? Sunucuya refresh token güncelleme isteği gönderiliyor...');
    
    const response = await fetch('https://yekupon.com/updateRefreshToken.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: `token=${encodeURIComponent(token)}&refresh_token=${encodeURIComponent(refreshToken)}`
    });
    
    if (response.ok) {
        console.log('🔄 Refresh token sunucuda güncellendi');
            await sendLogMessage('✅ Refresh token sunucuda başarıyla güncellendi', 'success', tabId);
    } else {
      throw new Error(`Server response: ${response.status} ${response.statusText}`);
    }
    
  } catch (error) {
    console.error('🚫 Sunucuda refresh token güncelleme hatası:', error);
    await sendLogMessage(`❌ Sunucuda refresh token güncelleme hatası: ${error.message}`, 'error', tabId);
  }
}

async function handleYemekSepetiSetupNew(userData, tabId, sendResponse) {
    try {
        console.log('?? YemekSepeti setup new başlatılıyor...', userData);
        
        const createdTab = await chrome.tabs.create({ url: "https://www.yemeksepeti.com" });
        
        if (userData && userData.address) {
            await new Promise(resolve => setTimeout(resolve, 3000));
            
            await handleYemekSepetiAddressManagement(createdTab.id, userData);
        } else {
            console.log('?? YemekSepeti setup new - userData veya address bilgisi eksik');
        }
        
        sendResponse({ success: true, message: 'YemekSepeti setup new başarılı' });
        
    } catch (error) {
        console.error('YemekSepeti setup new hatası:', error);
        sendResponse({ success: false, error: error.message });
    }
}

let ykuponToken = null;
let sha256HashGlobal = null;
let access_token_global = null;


async function getYsAccessToken() {
    try {
        const c1 = await new Promise(resolve => {
            chrome.cookies.get({ url: 'https://www.yemeksepeti.com', name: 'access_token' }, resolve);
        });
        if (c1 && c1.value) return c1.value;
    } catch (e) {
        console.warn('access_token cookie okunamadı:', e?.message || e);
    }

    try {
        const c2 = await new Promise(resolve => {
            chrome.cookies.get({ url: 'https://www.yemeksepeti.com', name: 'ykupon_token' }, resolve);
        });
        if (c2 && c2.value) return c2.value;
    } catch (e) {
        console.warn('ykupon_token cookie okunamadı:', e?.message || e);
    }

    if (typeof access_token_global !== 'undefined' && access_token_global) return access_token_global;
    return null;
}

async function handleYeKuponYsProxyRequest(request, sendResponse) {
  console.log('🛰️ YEKUPON Background: handleYeKuponYsProxyRequest started');
  
  try {
    // Content.js'den gelen formatı destekle (url, method, headers, body doğrudan request'te)
    const requestDetails = request.requestDetails || {
      url: request.url,
      method: request.method,
      headers: request.headers,
      body: request.body
    };
    
    console.log('📋 Request details:', requestDetails);
    
    // Dinamik token al (cookie store veya login flow'dan)
    const dynamicToken = await getYsAccessToken();
    if (!dynamicToken) {
      console.warn('⚠️ YEKUPON: Dinamik token bulunamadı, istek Authorization header\'ı olmadan gönderilecek');
    }
    
    const headers = {
      'Accept': 'application/json, text/plain, */*',
      'Accept-Encoding': 'gzip, deflate, br, zstd',
      'Accept-Language': 'tr,en;q=0.9,en-GB;q=0.8,en-US;q=0.7',
      'Android-Mobile-Service-Provider': 'gms',
      'Api-Client-Version': '5.0',
      'App-Build': '250800124',
      'App-Flavor': 'yemeksepeti',
      'App-Name': 'com.inovel.app.yemeksepeti',
      'App-Version': '25.8.0',
      ...(dynamicToken ? { 'Authorization': `Bearer ${dynamicToken}` } : {}),
      'Build-Number': '250800124',
      'Build-Type': 'release',
      'Connection': 'keep-alive',
      'Content-Type': 'application/json; charset=UTF-8',
      'Device-Id': 'vr1o9jlk3covgc6mp645io',
      'Device-Make': 'Redmi',
      'Device-Model': '22081212UG',
      'Eks': 'aosbkk',
      'Host': 'tr.fd-api.com',
      'Origin': 'https://www.yemeksepeti.com',
      'Platform': 'android',
      'Platform-Version': '30',
      'R-sig': 'xcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcXFxcU=',
      'Referer': 'https://www.yemeksepeti.com/',
      'Sentry-Trace': '00000000000000000000000000000000-0000000000000000-0',
      'User-Agent': 'Android-app-25.8.0(250800124)',
      'X-FP-API-KEY': 'android',
      'X-PD-Language-ID': '2, 2',
      ...(requestDetails.headers || {})
    };
    
    console.log('🛰️ RAKIB STYLE Background: Gerçek API çağrısı yapılıyor...');
    
    const response = await fetch(requestDetails.url, {
      method: requestDetails.method,
      headers: headers,
      body: requestDetails.body
    });
    
    const responseText = await response.text();
    console.log('✅ YEKUPON Background: API response alındı:', response.status);
    
    sendResponse({
      success: true,
      data: {
        data: JSON.parse(responseText),
        status: response.status,
        statusText: response.statusText,
        headers: Object.fromEntries(response.headers.entries())
      }
    });
    
  } catch (error) {
    console.error('❌ YEKUPON Background proxy error:', error);
    sendResponse({
      success: false,
      error: error.message
    });
  }
}

self.addEventListener('install', (event) => {
  console.log('Service worker installing');
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  console.log('Service worker activated');
  event.waitUntil(self.clients.claim());
});

function randomString(length) {
  let generated = '';
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  for (let i = 0; i < length; i++) {
    generated += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return generated;
}

function randomDigits(length) {
  let result = '';
  for (let i = 0; i < length; i++) {
    result += Math.floor(Math.random() * 10).toString();
  }
  return result;
}

function randomFingerprint() {
  let fp = '';
  const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
  for (let i = 0; i < 32; i++) {
    fp += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return fp;
}

function addOrUpdateHeader(headers, headerName, headerValue) {
  let updated = false;
  for (let i = 0; i < headers.length; i++) {
    if (headers[i].name.toLowerCase() === headerName.toLowerCase()) {
      headers[i].value = headerValue;
      updated = true;
      break;
    }
  }
  if (!updated) {
    headers.push({
      name: headerName,
      value: headerValue,
    });
  }
}

function addCustomHeaders(headers) {
  headers.push({
    name: randomString(16),
    value: randomString(22),
  });
  headers.push({
    name: randomString(16),
    value: randomString(22),
  });
  headers.push({
    name: randomString(16),
    value: randomString(22),
  });
}

function getDeviceDetails() {
  const model = '23' + randomDigits(3) + 'RN' + randomDigits(1) + 'L';
  const deviceId = randomString(16);
  return {
    deviceMake: 'Redmi',
    deviceModel: model,
    deviceId: deviceId,
  };
}

async function getUyToken() {
  try {
    const cookie = await chrome.cookies.get({
      url: 'http://www.yemeksepeti.com',
      name: 'ykupon_token',
    });
    
    if (cookie && cookie.value) {
      ykuponToken = cookie.value;
    } else {
      ykuponToken = null;
    }
    return ykuponToken;
  } catch (error) {
    console.error('Cookie alma hatası:', error);
    return null;
  }
}

function getRandomString(mask) {
  const chars = {
    '?l': 'abcdefghijklmnopqrstuvwxyz',
    '?u': 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
    '?d': '0123456789',
    '?f': 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz',
    '?s': '!@#$%^&*()_+-=[]{}|;:,.<>?/~',
    '?h': '0123456789abcdef',
    '?H': '0123456789ABCDEF',
    '?m': 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789',
    '?n': 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789',
    '?z': 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789',
    '?a': 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+-=[]{}|;:,.<>?/~',
    '?i': 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._~',
    '?c': 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_'
  };

  return mask.match(/\?[a-zA-Z]/g)?.map(token => {
    const pool = chars[token];
    return pool ? pool.charAt(Math.floor(Math.random() * pool.length)) : '';
  }).join('') || '';
}

function generateGuid() {
  return crypto.randomUUID();
}

function sha256(input) {
  return crypto.subtle.digest('SHA-256', new TextEncoder().encode(input)).then(hash => {
    return Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2, '0')).join('');
  });
}

function toBase64(input) {
  return btoa(unescape(encodeURIComponent(input)));
}

function getUnixTime() {
  return Math.floor(Date.now() / 1000);
}

async function initializeHash() {
  try {
    const sad1x = getRandomString('?i'.repeat(10));
    sha256HashGlobal = await sha256(sad1x);
    console.log('Hash initialized successfully');
  } catch (error) {
    console.error('Hash initialization failed:', error);
  }
}

function initializeServiceWorker() {
  initializeHash().then(() => {
    console.log('Service worker initialization complete');
  }).catch(error => {
    console.error('Service worker initialization failed:', error);
  });
  
  // YemekSepeti sekme kapatma kaldırıldı - kullanıcı deneyimini bozuyordu
}

async function fetchCookiesWithCSP(cookiesUrl, maxRetries = 4) {
  let retryCount = 0;
  let fetchResult;
  
  const userAgents = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
  ];
  
  while (retryCount < maxRetries) {
    try {
      console.log(`Cookies fetch attempt ${retryCount + 1}/${maxRetries} for: ${cookiesUrl}`);
      
      const fetchOptions = {
        method: 'GET',
        headers: {
          'User-Agent': userAgents[retryCount % userAgents.length],
          'Accept': 'application/json, text/plain, */*',
          'Accept-Language': 'tr-TR,tr;q=0.9,en;q=0.8',
          'Cache-Control': 'no-cache',
          'Pragma': 'no-cache',
          'Sec-Fetch-Dest': 'empty',
          'Sec-Fetch-Mode': 'cors',
          'Sec-Fetch-Site': 'cross-site'
        },
        mode: 'cors',
        cache: 'no-cache',
        redirect: 'follow',
        credentials: 'omit'
      };
      
      if (retryCount === 1) {
        fetchOptions.headers = {
          'User-Agent': userAgents[retryCount % userAgents.length],
          'Accept': 'application/json'
        };
      } else if (retryCount === 2) {
        fetchOptions.mode = 'no-cors';
        delete fetchOptions.headers['Accept-Language'];
      }
      
      fetchResult = await fetch(cookiesUrl, fetchOptions);
      
      if (!fetchResult.ok && fetchResult.status !== undefined) {
        throw new Error(`HTTP ${fetchResult.status}: ${fetchResult.statusText || 'Request failed'}`);
      }
      
      console.log(`Cookies fetch successful on attempt ${retryCount + 1}`);
      break;
      
    } catch (error) {
      retryCount++;
      console.warn(`Cookies fetch attempt ${retryCount} failed:`, error.message);
      
      if (error.message.includes('Content Security Policy') || 
          error.message.includes('CSP') ||
          error.message.includes('connect-src')) {
        console.error('CSP violation detected. Check manifest.json host_permissions and content_security_policy.');
        throw new Error(`CSP Error: ${error.message}. Manifest.json'da yekupon.com domain'i eksik olabilir.`);
      }
      
      if (error.message.includes('EPROTO') || 
          error.message.includes('ssl') || 
          error.message.includes('TLS') ||
          error.message.includes('certificate') ||
          error.message.includes('handshake') ||
          error.message.includes('ECONNRESET') ||
          error.message.includes('ETIMEDOUT')) {
        
        console.log(`SSL/TLS/Network error detected, retrying... (${retryCount}/${maxRetries})`);
        
        if (retryCount >= maxRetries) {
          throw new Error(`All connection methods failed after ${maxRetries} attempts: ${error.message}`);
        }
        
        await new Promise(resolve => setTimeout(resolve, 1000 * Math.pow(2, retryCount - 1)));
      } else {
        throw error;
      }
    }
  }
  
  return fetchResult;
}

initializeServiceWorker();

setupDynamicHeaders().then(() => {
  console.log('Dynamic headers setup completed');
}).catch(error => {
  console.error('Dynamic headers setup failed:', error);
});

console.log('?? WebRequest blocking listeners disabled - using inject.js injection instead');


function generateRandomString(length) {
    const characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return result;
}
function generateRandomString(length) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
  let result = '';
  
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  
  return result;
}

function generateHex(length) {
  const hexChars = '0123456789abcdef';
  let result = '';
  
  for (let i = 0; i < length; i++) {
    result += hexChars.charAt(Math.floor(Math.random() * hexChars.length));
  }
  
  return result;
}

function generatePxCookies() {
    const px3Part1 = generateHex(64);
    const base64Chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
    
    let px3Part2 = '';
    for (let i = 0; i < 88; i++) {
        px3Part2 += base64Chars.charAt(Math.floor(Math.random() * base64Chars.length));
    }
    
    let px3Part3 = '';
    for (let i = 0; i < 344; i++) {
        px3Part3 += base64Chars.charAt(Math.floor(Math.random() * base64Chars.length));
    }
    
    const _px3 = `${px3Part1}:${px3Part2}:1000:${px3Part3}`;
    const _pxhd = generateHex(48);
    const _pxvid = generateUUIDv4();
    const _pxcts = Date.now().toString();
    
    return `_px3=${_px3}; _pxhd=${_pxhd}; _pxvid=${_pxvid}; _pxcts=${_pxcts}`;
}

function generateRandomVersions() {
  const majorVersions = [22, 23, 24, 25];
  const minorVersions = Array.from({length: 100}, (_, i) => i);
  const patchVersions = Array.from({length: 10}, (_, i) => i);
  
  const major = majorVersions[Math.floor(Math.random() * majorVersions.length)];
  const minor = minorVersions[Math.floor(Math.random() * minorVersions.length)];
  const patch = patchVersions[Math.floor(Math.random() * patchVersions.length)];
  
  const buildNumber = sprintf("%d%02d%d00", major, minor, patch);
  
  const version = sprintf("%d.%d.%d", major, minor, patch);
  
  const buildSuffix = Math.floor(Math.random() * 900) + 100;
  const fullBuildNumber = buildNumber + buildSuffix;
  
  const userAgent = `Android-app-${version}(${fullBuildNumber})`;
  
  return {
    version: version,
    buildNumber: fullBuildNumber,
    userAgent: userAgent
  };
}

function sprintf(format) {
  const args = Array.prototype.slice.call(arguments, 1);
  return format.replace(/%([0-9]+)?([dfs])/g, function(match, width, type) {
    let s = args.shift().toString();
    if (type === 'd' && width) {
      s = s.padStart(parseInt(width, 10), '0');
    }
    return s;
  });
}

function generatePxToken() {
  const part1 = "3:";
  
  const part2 = Array.from({length: 32}, () => 
    "0123456789abcdef"[Math.floor(Math.random() * 16)]).join('');
  
  const part3 = Array.from({length: 88}, () => 
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="[Math.floor(Math.random() * 65)]).join('');
  
  const part4 = "1000";
  
  const part5 = Array.from({length: 256}, () => 
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="[Math.floor(Math.random() * 65)]).join('');
  
  return part1 + part2 + ":" + part3 + ":" + part4 + ":" + part5;
}

function generateRandomDevice() {
  const deviceId = Array.from({length: 32}, () => 
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"[Math.floor(Math.random() * 62)]).join('');
  
  const makes = ["Xiaomi", "HUAWEI", "Redmi", "Samsung", "POCO", "oppo", "Asus"];
  const deviceMake = makes[Math.floor(Math.random() * makes.length)];
  
  const models = ["CPH2341", "M2101K6G", "M2004J19C", "2201116TG", "2207117BPG", "ASUS_I005DA", "ASUS_Z01QD"];
  const deviceModel = models[Math.floor(Math.random() * models.length)];
  
  const platformVersion = 23 + Math.floor(Math.random() * 10);
  
  return {
    deviceId: deviceId,
    deviceMake: deviceMake,
    deviceModel: deviceModel,
    platformVersion: platformVersion
  };
}

function generateRandomEks() {
  const keys = ["abc", "aaa", "cvc", "cbc", "csc", "asd", "amg", "aq3", "mnp", "gig"];
  return keys[Math.floor(Math.random() * keys.length)] + keys[Math.floor(Math.random() * keys.length)];
}

function generateUUIDv4() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

function generateOriginalRts() {
  const now = new Date();
  const turkeyTime = new Date(now.getTime() + (3 * 60 * 60 * 1000));
  return turkeyTime.toISOString().replace('Z', '+03:00');
}

function generateOriginalRuid() {
  return Math.random().toString();
}

function generateOriginalRSig() {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  let result = '';
  for (let i = 0; i < 44; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result + '=';
}

function generatePxAuthorization() {
  const version = "3";
  const hexPart = generateHex(64);
  
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  let shortBase64 = '';
  for (let i = 0; i < 64; i++) {
    shortBase64 += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  
  const number = "1000";
  
  let longBase64 = '';
  for (let i = 0; i < 340; i++) {
    longBase64 += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  
  return `${version}:${hexPart}:${shortBase64}:${number}:${longBase64}`;
}

function generatePxHello() {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  const length = Math.random() < 0.5 ? 50 : 54;
  
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  
  return result;
}

// ============================================
// PX Token Server - Gerçek cihazdan PX token al
// ============================================
const PX_SERVER_URL = 'https://yekupon.com/server/ys.php';
let cachedPxData = null;
let pxDataLastFetch = 0;
const PX_CACHE_TTL = 5 * 60 * 1000; // 5 dakika

async function fetchServerPxData() {
  const now = Date.now();
  if (cachedPxData && (now - pxDataLastFetch) < PX_CACHE_TTL) {
    return cachedPxData;
  }
  try {
    const response = await fetch(PX_SERVER_URL, { credentials: 'omit' });
    if (!response.ok) throw new Error('HTTP ' + response.status);
    const result = await response.json();
    if (result.success && result.data && result.data.px_authorization) {
      cachedPxData = result.data;
      pxDataLastFetch = now;
      console.log('PX Token server\'dan al\u0131nd\u0131, ya\u015f:', result.age_seconds, 'sn, taze:', result.is_fresh);
      return cachedPxData;
    }
  } catch (e) {
    console.warn('PX Token server\'a ba\u011flanamad\u0131:', e.message);
  }
  return null;
}

function generateCleanExtra() {
  const sessionId = generateHex(32);
  
  const timestamp = Date.now();
  
  const perseusClientMiddle = Math.floor(Math.random() * 900000000000000000) + 100000000000000000;
  const perseusClientId = `${timestamp}.${perseusClientMiddle}.${generateRandomString(10)}`;
  
  const perseusSessionMiddleLength = Math.random() < 0.5 ? 16 : 18;
  let perseusSessionMiddle;
  if (perseusSessionMiddleLength === 16) {
    perseusSessionMiddle = Math.floor(Math.random() * 9000000000000000) + 1000000000000000;
  } else {
    perseusSessionMiddle = Math.floor(Math.random() * 900000000000000000) + 100000000000000000;
  }
  const perseusSessionId = `${timestamp + 1000}.${perseusSessionMiddle}.${generateRandomString(10)}`;
  
  const dpsSessionData = {
    session_id: sessionId,
    perseus_id: perseusClientId,
    timestamp: Math.floor(timestamp / 1000)
  };
  
  const dpsSessionId = btoa(JSON.stringify(dpsSessionData));
  
  return {
    deviceFingerprintToken: generateRandomString(100),
    deviceId: generateRandomString(32),
    pxVid: generateUUIDv4(),
    pxUuid: generateUUIDv4(),
    pxDeviceFp: generateHex(16),
    pxHello: generatePxHello(),
    adjustAdId: generateHex(64),
    appVersion: '26.7.0',
    buildNumber: '260700154',
    timestamp: generateOriginalRts(),
    requestId: generateOriginalRuid(),
    sentryTraceId: generateHex(32),
    traceTail: generateHex(16),
    emRequestId: generateUUIDv4(),
    perseusClientId: perseusClientId,
    perseusSessionId: perseusSessionId,
    eks: generateRandomEks(),
    rSig: generateOriginalRSig(),
    dpsSessionId: dpsSessionId,
    sessionId: sessionId,
    pxAuthorization: generatePxAuthorization()
  };
}

// generateYemeksepetiRSig is loaded from generate-rsig.js via importScripts

function jwtDecode(token) {
  if (!token || token === 'null') return null;
  try {
    const parts = token.split('.');
    if (parts.length !== 3) return null;
    const payload = atob(parts[1].replace(/-/g, '+').replace(/_/g, '/'));
    return JSON.parse(payload);
  } catch (error) {
    return null;
  }
}

function getUserIdFromToken(token) {
  try {
    if (!token || token === 'null') return '';
    const decoded = jwtDecode(token);
    return decoded?.user_id || '';
  } catch (error) {
    return '';
  }
}

let deviceInfo = null;

function generateDeviceIdentifiers() {
  const manufacturers = ['Samsung', 'Xiaomi', 'Huawei', 'OPPO', 'vivo', 'Realme', 'OnePlus', 'Google'];
  const manufacturer = manufacturers[Math.floor(Math.random() * manufacturers.length)];
  
  const models = {
    'Samsung': ['Galaxy S22', 'Galaxy S21', 'Galaxy Note20', 'Galaxy A52'],
    'Xiaomi': ['Mi 11', 'Redmi Note 10', 'Poco F3', 'Mi 10T'],
    'Huawei': ['P40', 'Mate 40', 'Nova 8', 'P30'],
    'OPPO': ['Find X3', 'Reno 6', 'A74', 'F19'],
    'vivo': ['X60', 'V21', 'Y20', 'S9'],
    'Realme': ['GT', 'Narzo 30', '8 Pro', 'C25'],
    'OnePlus': ['9 Pro', '8T', 'Nord 2', '9R'],
    'Google': ['Pixel 6', 'Pixel 5', 'Pixel 4a', 'Pixel 6 Pro']
  };
  
  const modelList = models[manufacturer] || models['Samsung'];
  const model = modelList[Math.floor(Math.random() * modelList.length)];
  
  const hexChars = '0123456789abcdef';
  let deviceId = '';
  for (let i = 0; i < 16; i++) {
    deviceId += hexChars.charAt(Math.floor(Math.random() * 16));
  }
  
  return {
    manufacturer,
    model,
    deviceId,
    appVersion: '26.7.0',
    buildNumber: '260700154',
    apiLevel: '34'
  };
}

function getOrCreateDeviceInfo() {
  if (!deviceInfo || !deviceInfo.deviceId) {
    deviceInfo = generateDeviceIdentifiers();
    chrome.storage.local.set({ 'deviceInfo': deviceInfo });
  }
  return deviceInfo;
}

chrome.storage.local.get('deviceInfo', function(result) {
  if (result.deviceInfo && result.deviceInfo.deviceId) {
    deviceInfo = result.deviceInfo;
  } else {
    deviceInfo = generateDeviceIdentifiers();
    chrome.storage.local.set({ 'deviceInfo': deviceInfo });
  }
});

// ===== PX Cookie Yönetimi (Kuppo.net modeli - Rule 6755) =====
// Hem yemeksepeti.com hem tr.fd-api.com'dan _pxhd ve __cf_bm cookie'lerini oku
async function getTrFdApiCookies() {
  const cookieMap = {};
  
  // Önce yemeksepeti.com'dan oku (Kuppo.net ile aynı)
  const ysCookies = await new Promise(resolve => {
    chrome.cookies.getAll({ domain: "yemeksepeti.com" }, resolve);
  });
  for (const cookie of ysCookies) {
    if (cookie.name === "_pxhd" || cookie.name === "__cf_bm") {
      cookieMap[cookie.name] = cookie.value;
    }
  }
  
  // Sonra tr.fd-api.com'dan oku (yemeksepeti.com'da yoksa)
  const fdCookies = await new Promise(resolve => {
    chrome.cookies.getAll({ domain: "fd-api.com" }, resolve);
  });
  for (const cookie of fdCookies) {
    if ((cookie.name === "_pxhd" || cookie.name === "__cf_bm") && !cookieMap[cookie.name]) {
      cookieMap[cookie.name] = cookie.value;
    }
  }
  
  return Object.entries(cookieMap).map(([k, v]) => `${k}=${v}`).join('; ');
}

// DNR Rule 6755: tr.fd-api.com isteklerine kontrollü Cookie header ekle
async function updateCookieRule() {
  const cookieString = await getTrFdApiCookies();

  try {
    if (!cookieString) {
      // Cookie yoksa rule'u kaldır (boş Cookie header gönderme)
      await chrome.declarativeNetRequest.updateDynamicRules({
        removeRuleIds: [6755]
      });
      // Sessiz kaldır — spam log engeli
      return;
    }
    
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: [6755],
      addRules: [{
        "id": 6755,
        "priority": 1,
        "action": {
          "type": "modifyHeaders",
          "requestHeaders": [
            { "header": "Cookie", "operation": "set", "value": cookieString }
          ]
        },
        "condition": {
          "urlFilter": "|https://tr.fd-api.com/*",
          "resourceTypes": ["xmlhttprequest"],
          "excludedInitiatorDomains": [chrome.runtime.id]
        }
      }]
    });
    console.log('✅ Cookie rule 6755 güncellendi:', cookieString);
  } catch (error) {
    console.error('Cookie rule 6755 hatası:', error);
  }
}

// YS/FD cookie'leri değiştiğinde cookie rule'u güncelle (debounce ile sonsuz döngü engeli)
let _cookieRuleTimer = null;
let _lastCookieRuleValue = '';
chrome.cookies.onChanged.addListener((changeInfo) => {
  const domain = changeInfo.cookie.domain;
  if (domain.includes("yemeksepeti.com") || domain.includes("fd-api.com")) {
    // __cf_bm kendi kendini tetiklemesin — sadece gerçek değişikliklerde güncelle
    if (_cookieRuleTimer) clearTimeout(_cookieRuleTimer);
    _cookieRuleTimer = setTimeout(async () => {
      _cookieRuleTimer = null;
      try {
        const newValue = await getTrFdApiCookies();
        if (newValue === _lastCookieRuleValue) return; // Aynıysa skip
        _lastCookieRuleValue = newValue;
        await updateCookieRule();
      } catch (e) { console.error('Cookie rule debounce error:', e); }
    }, 500);
  }
});

// === KUPON KORUMA SİSTEMİ (background.js) ===
let ysLastCalculateResponse = null;
let ysLastProductsFingerprint = null;
// ysCheckoutInProgress ve ysVoucherMap zaten yukarıda (satır 718-719) tanımlı

// Vendor vertical'a göre doğru voucher variant'ını seç
function getVoucherForVertical(voucherMap, code, vendorVertical) {
  const entry = voucherMap[(code || '').toLowerCase()];
  if (!entry) return null;
  if (!entry.variants || entry.variants.length === 0) return entry;
  
  const vertical = (vendorVertical || '').toLowerCase();
  
  // 1. Vertical'a tam uyan variant'ı bul
  if (vertical) {
    const match = entry.variants.find(v => 
      v.verticalTypes && v.verticalTypes.some(vt => vt.toLowerCase() === vertical)
    );
    if (match) return match;
  }
  
  // 2. Vertical belirtilmemişse veya eşleşme yoksa: APPLICABLE + vertical kısıtlaması olmayan
  const noVerticalRestriction = entry.variants.find(v => 
    (!v.verticalTypes || v.verticalTypes.length === 0) && v.status === 'APPLICABLE'
  );
  if (noVerticalRestriction) return noVerticalRestriction;
  
  // 3. Vertical var ama eşleşmiyorsa → null dön (bu kupon bu vertical için geçerli değil)
  if (vertical) return null;
  
  // 4. Vertical belirtilmemişse fallback: APPLICABLE olanı
  const applicable = entry.variants.find(v => v.status === 'APPLICABLE');
  return applicable || entry.variants[0];
}

function calcProductsFingerprint(products) {
  if (!products || !Array.isArray(products)) return '';
  return products.map(p => {
    const toppings = (p.toppings || []).map(t => t.id + ':' + t.quantity).sort().join(',');
    return p.id + '_' + (p.variation_id || '') + '_' + p.quantity + '_' + toppings;
  }).sort().join('|');
}

function generateFakeCalculateResponse(cachedResponse, voucherCode, vendorVertical) {
  if (!cachedResponse || !voucherCode) return null;
  try {
    const cached = typeof cachedResponse === 'string' ? JSON.parse(cachedResponse) : JSON.parse(JSON.stringify(cachedResponse));
    const vInfo = getVoucherForVertical(ysVoucherMap, voucherCode, vendorVertical || cached?.vendor?.vertical || '');
    if (!vInfo || !vInfo.discount) return null;

    const discount = vInfo.discount;
    const currentTotal = cached.payment ? cached.payment.payable_total : 0;
    const appliedDiscount = Math.min(discount, currentTotal);

    if (cached.payment) {
      cached.payment.payable_total_without_voucher = cached.payment.payable_total;
      cached.payment.payable_total = parseFloat((cached.payment.payable_total - appliedDiscount).toFixed(2));
    }

    cached.voucher = {
      percentage: null,
      construct_id: vInfo.constructId || null,
      voucher_type: 'amount',
      type: 'amount',
      description: appliedDiscount + ' TL indirim kazandınız!',
      code: voucherCode,
      banned_products: [],
      amount: discount,
      value: discount,
      is_pro_voucher: false,
      applied: appliedDiscount > 0
    };

    return cached;
  } catch (e) {
    console.error('[KuponKoruma] Fake calculate error:', e);
    return null;
  }
}

function manipulateCartBodyBg(url, body) {
  if (!body) return body;
  if (!url.includes('cart/checkout') && !url.includes('cart/calculate')) return body;
  try {
    const requestBody = typeof body === 'string' ? JSON.parse(body) : body;
    if (requestBody.platform === 'b2c') {
      requestBody.platform = 'android_native_app';
    }
    requestBody.source = 'android';

    // Kupon otomatik ekleme (vertical-aware)
    if (url.includes('cart/calculate') && !requestBody.voucher && Object.keys(ysVoucherMap).length > 0) {
      const vendorVertical = requestBody.vendor?.vertical || '';
      let bestCode = null;
      let bestValue = 0;
      let bestConstructId = null;
      for (const [code, info] of Object.entries(ysVoucherMap)) {
        const variant = getVoucherForVertical(ysVoucherMap, code, vendorVertical);
        if (variant && variant.discount && variant.discount > bestValue) {
          bestValue = variant.discount;
          bestCode = code;
          bestConstructId = variant.constructId;
        }
      }
      if (bestCode) {
        requestBody.voucher = bestCode;
        requestBody.auto_apply_voucher = false;
        if (bestConstructId) {
          requestBody.voucher_context = { construct_id: bestConstructId };
        }
        console.log('[KuponKoruma] Otomatik kupon eklendi:', bestCode, '(' + bestValue + ' TL)', 'vertical:', vendorVertical, 'constructId:', bestConstructId);
      }
    }

    return JSON.stringify(requestBody);
  } catch (e) {
    return typeof body === 'string' ? body : JSON.stringify(body);
  }
}
// === KUPON KORUMA SİSTEMİ SONU ===

async function handleYsProxyRequest(request, sendResponse) {
  try {
    if (!request.url) {
      throw new Error('URL eksik');
    }

    // === KUPON KORUMA: cart/calculate intercept (Kuppo modeli) ===
    // Kuponsuz: sunucuya auth olmadan gönder, yanıtı cache'le
    // Kuponlu: cache'teki kuponsuz yanıtı kullan, payable_total'dan kupon düş (sunucuya gitme)
    if (request.url.includes('cart/calculate') && request.body) {
      try {
        const _calcBody = (() => { try { return JSON.parse(request.body || '{}'); } catch(_) { return {}; } })();
        const _calcVoucher = (_calcBody.voucher || '').trim();

        // Platform/source düzelt (manipülasyon)
        if (_calcBody.platform === 'b2c') _calcBody.platform = 'android_native_app';
        _calcBody.source = 'android';

        // Ürün parmak izi
        const _currentFingerprint = calcProductsFingerprint(_calcBody.products || []);

        // Voucher response uygulama fonksiyonu
        const _applyVoucherToResponse = (baseData, vCode, vDiscount, constructId) => {
          const resp = typeof baseData === 'string' ? JSON.parse(baseData) : JSON.parse(JSON.stringify(baseData));
          const discountedSubtotal = resp?.payment?.discounted_subtotal || 0;
          const actualDiscount = Math.min(vDiscount, discountedSubtotal);
          if (resp.payment) {
            resp.payment.payable_total_without_voucher = resp.payment.payable_total;
            resp.payment.payable_total = parseFloat((resp.payment.payable_total - actualDiscount).toFixed(2));
            resp.payment.total_savings = parseFloat(((resp.payment.total_savings || 0) + actualDiscount).toFixed(2));
          }
          if (resp.payment_limits) {
            resp.payment_limits = resp.payment_limits.map(l => {
              if (l.limit_code === 'foodafterdiscount') return { ...l, limit_amount: parseFloat((discountedSubtotal - actualDiscount).toFixed(2)) };
              if (l.limit_code === 'orderamountwithoutpaymentfee') return { ...l, limit_amount: resp.payment?.payable_total || 0 };
              return l;
            });
          }
          resp.voucher = {
            percentage: null, construct_id: constructId || null, voucher_type: 'amount', type: 'amount',
            end_date: '', description: actualDiscount + ' TL indirim kazandınız!',
            code: vCode, banned_products: [], amount: vDiscount,
            value: vDiscount, is_pro_voucher: false, applied: actualDiscount > 0
          };
          return typeof baseData === 'string' ? JSON.stringify(resp) : resp;
        };

        if (_calcVoucher !== '') {
          // === KUPONLU CALCULATE ===
          const _vendorVertical = _calcBody.vendor?.vertical || '';
          const _vInfo = getVoucherForVertical(ysVoucherMap, _calcVoucher, _vendorVertical);
          const _calcVoucherDiscount = _vInfo ? (_vInfo.discount || 0) : 0;
          const _calcConstructId = _vInfo ? (_vInfo.constructId || '') : '';
          // construct_id'yi doğru vertical'a göre set et
          if (_calcConstructId && _calcBody.voucher_context) {
            _calcBody.voucher_context.construct_id = _calcConstructId;
          } else if (_calcConstructId) {
            _calcBody.voucher_context = { construct_id: _calcConstructId };
          }
          console.log('[KuponKoruma] Kuponlu calculate:', _calcVoucher, 'discount:', _calcVoucherDiscount, 'vertical:', _vendorVertical, 'constructId:', _calcConstructId, 'cache:', !!ysLastCalculateResponse);

          // Cache var mı ve ürünler aynı mı kontrol et
          let _useCache = false;
          if (ysLastCalculateResponse) {
            try {
              const _cachedResp = typeof ysLastCalculateResponse === 'string' ? JSON.parse(ysLastCalculateResponse) : ysLastCalculateResponse;
              const _cachedFingerprint = calcProductsFingerprint((_cachedResp.products || []).map(p => ({
                id: p.id, variation_id: p.variation_id, quantity: p.quantity, toppings: p.toppings
              })));
              _useCache = _cachedFingerprint === _currentFingerprint || ysLastProductsFingerprint === _currentFingerprint;
            } catch(e) {}
          }

          if (_useCache) {
            // Ürünler aynı: cache'i kullan, sunucuya gitme
            try {
              const baseData = typeof ysLastCalculateResponse === 'string' ? ysLastCalculateResponse : JSON.stringify(ysLastCalculateResponse);
              const fakeData = _applyVoucherToResponse(baseData, _calcVoucher, _calcVoucherDiscount, _calcConstructId);
              console.log('[KuponKoruma] Fake calculate döndürülüyor (cache), voucher:', _calcVoucher);
              sendResponse({
                success: true, status: 200, statusText: 'OK',
                headers: { 'content-type': 'application/json' },
                data: typeof fakeData === 'string' ? fakeData : JSON.stringify(fakeData)
              });
            } catch(e) {
              console.error('[KuponKoruma] Cache voucher uygulama hatası:', e);
              sendResponse({ success: true, status: 200, statusText: 'OK',
                headers: { 'content-type': 'application/json' },
                data: typeof ysLastCalculateResponse === 'string' ? ysLastCalculateResponse : JSON.stringify(ysLastCalculateResponse)
              });
            }
            return;
          }

          // Ürünler değişti veya cache yok: kuponu sil, sunucuya gönder, cache'i güncelle
          console.log('[KuponKoruma] Ürünler değişti veya cache yok, kuponsuz sunucuya gidiyorum');
          delete _calcBody.voucher;
          delete _calcBody.voucher_context;
          request.body = JSON.stringify(_calcBody);
          // Devam et — aşağıda sunucuya gidecek, response cache'lenecek
          // Sonra response'a voucher uygula
          request._pendingVoucher = _calcVoucher;
          request._pendingVoucherDiscount = _calcVoucherDiscount;
        } else {
          // === KUPONSUZ CALCULATE ===
          // Checkout sırasında calculate'i cache'den döndür
          if (ysCheckoutInProgress && ysLastCalculateResponse) {
            console.log('[KuponKoruma] Checkout sırasında cached calculate döndürülüyor');
            const cachedData = typeof ysLastCalculateResponse === 'string' ? ysLastCalculateResponse : JSON.stringify(ysLastCalculateResponse);
            sendResponse({
              success: true, status: 200, statusText: 'OK',
              headers: { 'content-type': 'application/json' },
              data: cachedData
            });
            return;
          }
          // Platform/source düzeltilmiş body ile devam
          request.body = JSON.stringify(_calcBody);
        }

        // Ürün fingerprint'ini kaydet
        ysLastProductsFingerprint = _currentFingerprint;
      } catch(e) {
        console.error('[KuponKoruma] Calculate parse error:', e);
      }
    }

    // Checkout flag yönetimi + body manipülasyonu + construct_id fix
    if (request.url.includes('/api/v5/cart/checkout')) {
      ysCheckoutInProgress = true;
      if (request.body) {
        try {
          const checkoutBody = typeof request.body === 'string' ? JSON.parse(request.body) : request.body;
          if (checkoutBody.platform === 'b2c') checkoutBody.platform = 'Android-app-26.7.0(260700154)';
          checkoutBody.source = 'android';
          // Voucher construct_id'yi vendor vertical'a göre düzelt
          if (checkoutBody.voucher && checkoutBody.vendor?.vertical) {
            const _chkVInfo = getVoucherForVertical(ysVoucherMap, checkoutBody.voucher, checkoutBody.vendor.vertical);
            if (_chkVInfo && _chkVInfo.constructId) {
              if (!checkoutBody.voucher_context) checkoutBody.voucher_context = {};
              const oldConstructId = checkoutBody.voucher_context.construct_id;
              checkoutBody.voucher_context.construct_id = _chkVInfo.constructId;
              if (oldConstructId !== _chkVInfo.constructId) {
                console.log('[KuponKoruma] Checkout construct_id düzeltildi:', oldConstructId, '→', _chkVInfo.constructId, 'vertical:', checkoutBody.vendor.vertical);
              }
            }
          }
          request.body = JSON.stringify(checkoutBody);
        } catch(e) {}
      }
    }

    // Vouchers endpoint'i için URL parametresini düzelt
    let finalUrl = request.url;
    if (finalUrl.includes('/api/v6/incentives-wallet/vouchers')) {
      finalUrl = finalUrl.replace('platform=web_frontend', 'platform=android_native_app');
    }

    const isGraphql = finalUrl.includes('/graphql');

    // 1. Access token al
    const accessTokenCookie = await new Promise(resolve => {
      chrome.cookies.get({ url: 'https://www.yemeksepeti.com', name: 'access_token' }, resolve);
    });
    let token = accessTokenCookie?.value;
    if (!token) {
      if (access_token_global) {
        token = access_token_global;
      } else {
        throw new Error('Access token not found in cookies or global variable.');
      }
    }

    // 2. Cihaz bilgileri
    const device = getOrCreateDeviceInfo();
    const custCode = getUserIdFromToken(token);
    const eksValue = generateRandomEks();
    const adjustAdId = generateRandomHex(32);
    const widevineId = device.deviceId || generateRandomHex(16);

    // 3. Header'lar - Kuppo.net modeli (basit PX bypass)
    let headers = {
      "Host": "tr.fd-api.com",
      "Authorization": `Bearer ${token}`,
      "X-Pd-Language-Id": "2",
      "X-Reorder-Origin": "",
      "Api-Client-Version": "5.0",
      "Device-Make": device.manufacturer || "realme",
      "Device-Model": device.model || "RMX3085",
      "Device-Id": device.deviceId || generateRandomHex(16),
      "App-Name": "com.inovel.app.yemeksepeti",
      "App-Flavor": "yemeksepeti",
      "Build-Type": "release",
      "Platform": "android",
      "Platform-Version": device.apiLevel || "34",
      "Android-Mobile-Service-Provider": "gms",
      "Build-Number": "260700154",
      "App-Build": "260700154",
      "App-Version": "26.7.0",
      "Cust-Code": custCode,
      "Eks": eksValue,
      "Widevine-Id": widevineId,
      "Sentry-Trace": "00000000000000000000000000000000-0000000000000000-0",
      "Em-Request-Identifier": generateUUIDv4(),
      "X-Px-Bypass-Reason": "Invalid SDK initialization",
      "x-px-authorization": "3",
      "Adjust-Ad-Id": adjustAdId,
      "X-Fp-Api-Key": "android",
      "User-Agent": "Android-app-26.7.0(260700154)",
      'Content-Type': 'application/json; charset=UTF-8',
      'Accept-Encoding': 'gzip, deflate, br'
    };

    // GraphQL için ek mobil header'lar (base'de olmayan GraphQL-özel header'lar)
    // NOT: Platform, App-Version, User-Agent vb. base'de zaten var, tekrar set etme!
    if (isGraphql) {
      headers['apollographql-client-name'] = 'android';
      headers['apollographql-client-version'] = '26.7.0';
      headers['customer-code'] = custCode;
      headers['locale'] = 'tr_TR';
      headers['x-global-entity-id'] = 'YS_TR';
      // Sayfadaki location bilgilerini aktar
      if (request.headers) {
        if (request.headers['customer-latitude']) headers['customer-latitude'] = request.headers['customer-latitude'];
        if (request.headers['customer-longitude']) headers['customer-longitude'] = request.headers['customer-longitude'];
        if (request.headers['perseus-client-id']) headers['perseus-client-id'] = request.headers['perseus-client-id'];
        if (request.headers['perseus-session-id']) headers['perseus-session-id'] = request.headers['perseus-session-id'];
      }
    }

    // Sayfa header'larını filtrele - sadece güvenli olanları al (Kuppo.net modeli)
    // cookie, user-agent, sec-*, origin, referer gibi tehlikeli header'lar Android kimliğimizi bozar
    if (request.headers && typeof request.headers === 'object') {
      const dangerousHeaders = new Set([
        'cookie', 'user-agent', 'accept', 'accept-encoding', 'accept-language',
        'origin', 'referer', 'host', 'connection', 'authorization',
        'sec-ch-ua', 'sec-ch-ua-mobile', 'sec-ch-ua-platform',
        'sec-fetch-dest', 'sec-fetch-mode', 'sec-fetch-site', 'sec-fetch-user',
        'x-px-authorization', 'x-px-bypass-reason',
        'content-type', 'content-length', 'priority',
        'apollographql-client-name', 'apollographql-client-version',
        'app-version', 'platform', 'x-fp-api-key', 'x-pd-language-id'
      ]);
      for (const [key, value] of Object.entries(request.headers)) {
        const lowerKey = key.toLowerCase();
        if (!dangerousHeaders.has(lowerKey) && !lowerKey.startsWith('sec-')) {
          headers[key] = value;
        }
      }
    }

    // 4. R-Sig üret
    // 4. R-Sig üret (GraphQL için body'yi dahil etme - imza bozulur)
    const sigRequestData = {
      url: finalUrl,
      method: request.method || 'POST',
      eks: eksValue,
      body: isGraphql ? '' : (request.body || ''),
      custCode: custCode,
      build: "260700154",
      version: "26.7.0"
    };

    const sigResult = generateYemeksepetiRSig(sigRequestData);

    if (sigResult && sigResult.success) {
      const rSig = sigResult['R-Sig'] || sigResult.signature;
      headers['R-Sig'] = rSig;
      headers['Rts'] = sigResult.Rts;
      headers['Ruid'] = sigResult.Ruid;
      headers['Eks'] = sigResult.Eks || eksValue;
    }

    // 5. Fetch (credentials: omit = Chrome'un cookie göndermesini engelle)
    const fetchOptions = {
      method: request.method || 'POST',
      headers: headers,
      body: request.body,
      credentials: 'omit'
    };

    let response;
    try {
      response = await fetch(finalUrl, fetchOptions);
    } catch (fetchError) {
      console.error('Background: YS Proxy fetch hatası:', fetchError.message);
      throw new Error(`Fetch failed: ${fetchError.message}`);
    }

    const responseHeaders = {};
    response.headers.forEach((value, key) => {
      responseHeaders[key.toLowerCase()] = value;
    });

    let data;
    try {
      data = await response.text();
    } catch (textError) {
      data = '';
    }

    console.log('Background: YS Proxy yanıt -', response.status, data.length + 'b', finalUrl.split('/api/')[1]);

    // === KUPON KORUMA: Response cache ===
    if (finalUrl.includes('cart/calculate') && response.status === 200 && data) {
      try {
        const calcData = JSON.parse(data);
        // Sadece kupon olmayan (orijinal) response'u cache'le
        if (!calcData.voucher || !calcData.voucher.code) {
          ysLastCalculateResponse = data; // String olarak cache'le (Kuppo modeli)
          console.log('[KuponKoruma] Calculate response cached (payable_total:', calcData.payment?.payable_total, ')');
        }

        // Pending voucher varsa (ürünler değişti, kuponsuz sunucuya gitti, şimdi kupon uygula)
        if (request._pendingVoucher && request._pendingVoucherDiscount > 0) {
          try {
            const _applyVoucherInline = (baseStr, vCode, vDiscount) => {
              const resp = JSON.parse(baseStr);
              const discSubtotal = resp?.payment?.discounted_subtotal || 0;
              const actualDisc = Math.min(vDiscount, discSubtotal);
              if (resp.payment) {
                resp.payment.payable_total_without_voucher = resp.payment.payable_total;
                resp.payment.payable_total = parseFloat((resp.payment.payable_total - actualDisc).toFixed(2));
                resp.payment.total_savings = parseFloat(((resp.payment.total_savings || 0) + actualDisc).toFixed(2));
              }
              if (resp.payment_limits) {
                resp.payment_limits = resp.payment_limits.map(l => {
                  if (l.limit_code === 'foodafterdiscount') return { ...l, limit_amount: parseFloat((discSubtotal - actualDisc).toFixed(2)) };
                  if (l.limit_code === 'orderamountwithoutpaymentfee') return { ...l, limit_amount: resp.payment?.payable_total || 0 };
                  return l;
                });
              }
              // construct_id'yi doğru vertical'a göre set et
              const _inlineVInfo = getVoucherForVertical(ysVoucherMap, vCode, resp?.vendor?.vertical || '');
              resp.voucher = {
                percentage: null, construct_id: _inlineVInfo?.constructId || null, voucher_type: 'amount', type: 'amount',
                end_date: '', description: actualDisc + ' TL indirim kazandınız!',
                code: vCode, banned_products: [], amount: vDiscount,
                value: vDiscount, is_pro_voucher: false, applied: actualDisc > 0
              };
              return JSON.stringify(resp);
            };
            data = _applyVoucherInline(data, request._pendingVoucher, request._pendingVoucherDiscount);
            console.log('[KuponKoruma] Pending voucher uygulandı:', request._pendingVoucher);
          } catch(e) {
            console.error('[KuponKoruma] Pending voucher uygulama hatası:', e);
          }
        }
      } catch(e) {}
    }

    // === ApiTotalAmountMismatchException: checkout retry ===
    if (response.status === 400 && finalUrl.includes('cart/checkout') && request.body && data) {
      try {
        const parsed = JSON.parse(data);
        const actualAmount = parsed?.data?.more_information?.amounts?.actual_amount;
        const diff = parsed?.data?.more_information?.amounts?.diff;
        const diffToMov = parsed?.data?.more_information?.calculator_response?.subtotals?.['difference_to_minimum_order_value+vat'] ?? 0;

        if (parsed?.data?.exception_type === 'ApiTotalAmountMismatchException' && actualAmount != null) {
          // Minimum sepet tutarı hatası
          if (diffToMov > 0) {
            console.log('[KuponKoruma] Minimum sepet tutarı yetersiz, fark:', diffToMov);
            sendResponse({ success: true, status: 400, statusText: 'Bad Request', headers: {},
              data: JSON.stringify({ ...parsed, _min_order_error: true, _min_order_diff: diffToMov })
            });
            return;
          }
          // 100 TL'den fazla fark varsa retry yapma
          if (diff != null && diff > 100) {
            console.log('[KuponKoruma] Mismatch farkı 100 TL üzerinde, retry yok');
            sendResponse({ success: true, status: 400, statusText: 'Bad Request', headers: {}, data: data });
            return;
          }

          console.log('[KuponKoruma] Mismatch retry - actual_amount:', actualAmount);
          const retryBody = JSON.parse(request.body);
          retryBody.expected_total_amount = actualAmount;
          delete retryBody.expected_amount;
          if (retryBody.payment?.methods?.length > 0) {
            retryBody.payment.methods[0].amount = actualAmount;
          }

          // Yeni R-Sig hesapla (doğrudan generate-rsig.js fonksiyonu)
          let retryHeaders = Object.assign({}, headers);
          try {
            const retrySig = generateYemeksepetiRSig({
              url: finalUrl, method: 'POST', eks: eksValue,
              body: JSON.stringify(retryBody), custCode: custCode,
              build: '260700154', version: '26.7.0'
            });
            if (retrySig && retrySig.success) {
              retryHeaders['R-Sig'] = retrySig['R-Sig'] || retrySig.signature;
              retryHeaders['Rts'] = retrySig.Rts;
              retryHeaders['Ruid'] = retrySig.Ruid;
              retryHeaders['Eks'] = retrySig.Eks || eksValue;
              console.log('[KuponKoruma] Mismatch retry R-Sig yenilendi');
            }
          } catch(e) { console.warn('[KuponKoruma] Mismatch retry R-Sig hatası:', e); }

          // 10 saniye bekle
          await new Promise(resolve => setTimeout(resolve, 10000));

          const retryResponse = await fetch(finalUrl, {
            method: 'POST', headers: retryHeaders, body: JSON.stringify(retryBody)
          });
          const retryData = await retryResponse.text().catch(() => '');
          const retryResponseHeaders = {};
          retryResponse.headers.forEach((v, k) => { retryResponseHeaders[k.toLowerCase()] = v; });

          sendResponse({ success: true, status: retryResponse.status, statusText: retryResponse.statusText,
            headers: retryResponseHeaders, data: retryData });
          return;
        }
      } catch(e) { console.error('[KuponKoruma] Mismatch retry hatası:', e); }
    }

    // === Voucher hata toastları + kuponsuz checkout retry ===
    if (response.status === 400 && finalUrl.includes('cart/checkout') && data) {
      try {
        const parsedV = JSON.parse(data);
        const excType = parsedV?.data?.exception_type || '';
        const voucherRetryErrors = [
          'ApiVoucherLimitedToNewCustomersByNCIException',
          'ApiVoucherCustomerNotValidForCustomerProfilingRulesException',
          'ApiVoucherInvalidVerticalTypeException',
          'ApiVoucherNotApplicableException',
          'ApiVoucherExpiredException'
        ];
        const voucherErrorMessages = {
          'ApiVoucherLimitedToNewCustomersByNCIException': 'Kupon geçersiz (yeni müşteri kısıtlaması). Kuponsuz ödeme deneniyor...',
          'ApiVoucherCustomerNotValidForCustomerProfilingRulesException': 'Kupon geçersiz (profiling kısıtlaması). Kuponsuz ödeme deneniyor...',
          'ApiVoucherInvalidVerticalTypeException': 'Kupon bu mağaza türü için geçerli değil. Kuponsuz ödeme deneniyor...',
          'ApiVoucherNotApplicableException': 'Kupon uygulanamıyor. Kuponsuz ödeme deneniyor...',
          'ApiVoucherExpiredException': 'Kupon süresi dolmuş. Kuponsuz ödeme deneniyor...'
        };
        if (voucherRetryErrors.includes(excType) && request.body) {
          console.log('[KuponKoruma]', excType, '- kuponsuz checkout retry başlatılıyor');
          // Toast göster
          chrome.tabs.query({ url: '*://www.yemeksepeti.com/*' }, (tabs) => {
            tabs.forEach(tab => {
              chrome.tabs.sendMessage(tab.id, {
                action: 'showCustomToast',
                message: voucherErrorMessages[excType] || 'Kupon hatası, kuponsuz deneniyor...',
                type: 'warning'
              });
            });
          });

          // Kuponsuz retry: voucher'ı sil, expected_total'ı orijinal tutara çek
          try {
            const retryBody = typeof request.body === 'string' ? JSON.parse(request.body) : JSON.parse(JSON.stringify(request.body));
            delete retryBody.voucher;
            delete retryBody.voucher_context;
            // Cache'deki orijinal (kuponsuz) payable_total'ı kullan
            if (ysLastCalculateResponse) {
              try {
                const cachedCalc = typeof ysLastCalculateResponse === 'string' ? JSON.parse(ysLastCalculateResponse) : ysLastCalculateResponse;
                if (cachedCalc?.payment?.payable_total) {
                  retryBody.expected_total_amount = cachedCalc.payment.payable_total;
                  if (retryBody.payment?.methods?.length > 0) {
                    retryBody.payment.methods[0].amount = cachedCalc.payment.payable_total;
                  }
                }
              } catch(_ce) {}
            }

            // Yeni R-Sig hesapla (doğrudan generate-rsig.js fonksiyonu)
            let retryHeaders = Object.assign({}, headers);
            try {
              const retrySig = generateYemeksepetiRSig({
                url: finalUrl, method: 'POST', eks: eksValue,
                body: JSON.stringify(retryBody), custCode: custCode,
                build: '260700154', version: '26.7.0'
              });
              if (retrySig && retrySig.success) {
                retryHeaders['R-Sig'] = retrySig['R-Sig'] || retrySig.signature;
                retryHeaders['Rts'] = retrySig.Rts;
                retryHeaders['Ruid'] = retrySig.Ruid;
                retryHeaders['Eks'] = retrySig.Eks || eksValue;
                console.log('[KuponKoruma] Kuponsuz retry R-Sig yenilendi');
              }
            } catch(_se) { console.warn('[KuponKoruma] Kuponsuz retry R-Sig hatası:', _se); }

            // 2 saniye bekle
            await new Promise(resolve => setTimeout(resolve, 2000));

            console.log('[KuponKoruma] Kuponsuz checkout retry gönderiliyor, expected_total:', retryBody.expected_total_amount);
            const retryResponse = await fetch(finalUrl, {
              method: 'POST', headers: retryHeaders, body: JSON.stringify(retryBody)
            });
            const retryData = await retryResponse.text().catch(() => '');
            const retryResponseHeaders = {};
            retryResponse.headers.forEach((v, k) => { retryResponseHeaders[k.toLowerCase()] = v; });

            if (retryResponse.status === 200) {
              console.log('[KuponKoruma] Kuponsuz checkout BAŞARILI!');
              chrome.tabs.query({ url: '*://www.yemeksepeti.com/*' }, (tabs) => {
                tabs.forEach(tab => {
                  chrome.tabs.sendMessage(tab.id, {
                    action: 'showCustomToast',
                    message: 'Sipariş kuponsuz olarak tamamlandı!',
                    type: 'success'
                  });
                });
              });
            } else {
              console.log('[KuponKoruma] Kuponsuz checkout da başarısız:', retryResponse.status);
            }

            sendResponse({ success: true, status: retryResponse.status, statusText: retryResponse.statusText,
              headers: retryResponseHeaders, data: retryData });
            return;
          } catch(_retryErr) {
            console.error('[KuponKoruma] Kuponsuz retry hatası:', _retryErr);
          }
        } else if (voucherErrorMessages[excType]) {
          // Bilinen voucher hatası ama retry yapılmadı (body yoktu vb)
          chrome.tabs.query({ url: '*://www.yemeksepeti.com/*' }, (tabs) => {
            tabs.forEach(tab => {
              chrome.tabs.sendMessage(tab.id, {
                action: 'showCustomToast',
                message: voucherErrorMessages[excType] || 'Kupon hatası.',
                type: 'error'
              });
            });
          });
        }
      } catch(e) {}
    }

    // Checkout bittiyse flag'i sıfırla
    if (finalUrl.includes('cart/checkout') && response.status === 200) {
      ysCheckoutInProgress = false;
    }

    // GraphQL incentives → voucher map güncelle + status APPLICABLE'a zorla
    if (finalUrl.includes('/graphql') && data) {
      try {
        const gqlData = JSON.parse(data);
        const incentives = gqlData?.data?.incentivesCartWallet?.incentives || [];
        if (incentives.length > 0) {
          const newMap = {};
          let modified = false;
          incentives.forEach(inc => {
            if (inc?.voucherMetaData) {
              const code = inc.voucherMetaData.code?.toLowerCase();
              if (code) {
                const verticals = inc.voucherMetaData.verticalTypes || [];
                const entry = {
                  discount: inc.value || inc.voucherMetaData.value || inc.voucherMetaData.amount || 0,
                  minOrder: inc.minimumOrderValue || inc.voucherMetaData.minimumOrderValue || 0,
                  constructId: inc.voucherMetaData.constructID || '',
                  verticalTypes: verticals,
                  status: inc.voucherMetaData.status || ''
                };
                // Aynı kod birden fazla vertical için gelebilir — hepsini sakla
                if (!newMap[code]) {
                  newMap[code] = { variants: [entry], discount: entry.discount, minOrder: entry.minOrder, constructId: entry.constructId };
                } else {
                  newMap[code].variants.push(entry);
                }
              }
              // Status'u APPLICABLE'a zorla (Kuppo modeli)
              if (inc.voucherMetaData.status && inc.voucherMetaData.status !== 'APPLICABLE') {
                console.log('[KuponKoruma] Voucher', code, 'status', inc.voucherMetaData.status, '→ APPLICABLE');
                inc.voucherMetaData.status = 'APPLICABLE';
                modified = true;
              }
              if (inc.voucherMetaData.quantity === 0) {
                inc.voucherMetaData.quantity = 1;
                modified = true;
              }
              // Platform kısıtlamasını kaldır
              if (inc.voucherMetaData.platforms) {
                inc.voucherMetaData.platforms = null;
                modified = true;
              }
            }
          });
          if (Object.keys(newMap).length > 0) {
            ysVoucherMap = newMap;
            console.log('[KuponKoruma] Voucher map updated:', Object.keys(newMap), JSON.stringify(newMap));
          }
          // Modifiye edilmişse response data'yı güncelle
          if (modified) {
            data = JSON.stringify(gqlData);
            console.log('[KuponKoruma] GraphQL response modifiye edildi (voucher status fix)');
          }
        }
      } catch(e) {}
    }

    // Vouchers endpoint → voucher map güncelle
    if (finalUrl.includes('incentives-wallet/vouchers') && response.status === 200 && data) {
      try {
        const vouchersData = JSON.parse(data);
        const vouchers = vouchersData?.data || vouchersData?.vouchers || [];
        if (Array.isArray(vouchers)) {
          vouchers.forEach(v => {
            const code = (v.code || '').toLowerCase();
            if (code) {
              ysVoucherMap[code] = {
                discount: v.value || v.amount || 0,
                minOrder: v.minimum_order_value || v.minimumOrderValue || 0,
                constructId: v.construct_id || v.constructID || ''
              };
            }
          });
          if (Object.keys(ysVoucherMap).length > 0) {
            console.log('[KuponKoruma] Voucher map from vouchers endpoint:', Object.keys(ysVoucherMap));
          }
        }
      } catch(e) {}
    }

    sendResponse({
      success: true,
      status: response.status,
      statusText: response.statusText,
      headers: responseHeaders,
      data: data
    });

  } catch (error) {
    console.error('Background: YS Proxy hata:', error.message);
    sendResponse({
      success: false,
      error: error.message || 'Bilinmeyen hata',
      headers: {}
    });
  }
}

function clearAllRules() {
  return new Promise(async (resolve) => {
    try {
    console.log("Kapsamlı kural temizleme işlemi başlatılıyor...");
      
      // KRİTİK: Trendyol mobil header kurallarını KORUMA - silme!
      // 8001-8005: setupTgoApiMobileRules (login sırasında)
      // 9901-9905: setupTrendyolMobileHeaders (startup)
      const protectedRuleIds = new Set([6755, 8001, 8002, 8003, 8004, 8005, 9901, 9902, 9903, 9904, 9905]);
      
      const dynamicRules = await chrome.declarativeNetRequest.getDynamicRules();
      if (dynamicRules.length > 0) {
        const dynamicRuleIds = dynamicRules.map(rule => rule.id).filter(id => !protectedRuleIds.has(id));
        if (dynamicRuleIds.length > 0) {
          console.log(`Temizlenecek ${dynamicRuleIds.length} dinamik kural bulundu.`);
          await chrome.declarativeNetRequest.updateDynamicRules({
            removeRuleIds: dynamicRuleIds
          });
          console.log("Dinamik kurallar temizlendi (Trendyol kuralları korundu).");
        } else {
          console.log("Temizlenecek dinamik kural bulunamadı (sadece korunan kurallar var).");
        }
      } else {
        console.log("Temizlenecek dinamik kural bulunamadı.");
      }
      
      const sessionRules = await chrome.declarativeNetRequest.getSessionRules();
      if (sessionRules.length > 0) {
        const sessionRuleIds = sessionRules.map(rule => rule.id).filter(id => !protectedRuleIds.has(id));
        if (sessionRuleIds.length > 0) {
          console.log(`Temizlenecek ${sessionRuleIds.length} oturum kuralı bulundu.`);
          await chrome.declarativeNetRequest.updateSessionRules({
            removeRuleIds: sessionRuleIds
          });
          console.log("Oturum kuralları temizlendi (Trendyol kuralları korundu).");
        } else {
          console.log("Temizlenecek oturum kuralı bulunamadı (sadece korunan kurallar var).");
        }
      } else {
    console.log("Temizlenecek oturum kuralı bulunamadı.");
      }
      
    console.log("Kapsamlı kural temizleme başarıyla tamamlandı.");
    } catch (error) {
    console.error("Kural temizleme sırasında bir hata oluştu (ancak işlem devam edecek):", error);
    } finally {
      resolve();
    }
  });
}

async function setupDynamicHeaders() {
  
  try {
    await clearAllRules(); 
    
    const device = getOrCreateDeviceInfo();
    const customUserAgent = 'Android-app-26.7.0(260700154)';
    const widevineId = device.deviceId || generateRandomHex(16);
    const adjustAdId = generateRandomHex(32);
    
    let accessToken = '';
    try {
      const accessTokenCookie = await chrome.cookies.get({
        url: 'https://www.yemeksepeti.com',
        name: 'access_token'
      });
      if (accessTokenCookie?.value) {
        accessToken = accessTokenCookie.value;
        console.log('Access token found in access_token cookie');
      } else {
        const ykuponTokenCookie = await chrome.cookies.get({
          url: 'https://www.yemeksepeti.com',
          name: 'ykupon_token'
        });
        if (ykuponTokenCookie?.value) {
          accessToken = ykuponTokenCookie.value;
          console.log('Access token found in ykupon_token cookie');
        }
      }
    } catch (error) {
      console.error('Error reading access token cookies:', error);
    }
    
    console.log('Setting up dynamic headers - Kuppo.net modeli');
    console.log('Access token found:', !!accessToken);
    
    // Ortak remove header listesi (Kuppo.net ile aynı)
    const removeHeaders = [
      { "header": "accept-language", "operation": "remove" },
      { "header": "sec-ch-ua", "operation": "remove" },
      { "header": "sec-ch-ua-mobile", "operation": "remove" },
      { "header": "sec-ch-ua-platform", "operation": "remove" },
      { "header": "sec-fetch-dest", "operation": "remove" },
      { "header": "sec-fetch-mode", "operation": "remove" },
      { "header": "sec-fetch-site", "operation": "remove" },
      { "header": "sec-ch-ua-arch", "operation": "remove" },
      { "header": "sec-ch-ua-bitness", "operation": "remove" },
      { "header": "sec-ch-ua-full-version", "operation": "remove" },
      { "header": "sec-ch-ua-full-version-list", "operation": "remove" },
      { "header": "sec-ch-ua-model", "operation": "remove" },
      { "header": "sec-ch-ua-wow64", "operation": "remove" },
      { "header": "sec-ch-ua-platform-version", "operation": "remove" },
      { "header": "sec-ch-ua-ua", "operation": "remove" },
      { "header": "sec-ch-ua-form-factor", "operation": "remove" },
      { "header": "sec-ch-ua-viewport-width", "operation": "remove" },
      { "header": "sec-ch-ua-dpr", "operation": "remove" },
      { "header": "sec-ch-ua-resolution", "operation": "remove" },
      { "header": "sec-fetch-user", "operation": "remove" },
      { "header": "sec-fetch-storage-access", "operation": "remove" },
      { "header": "priority", "operation": "remove" },
      { "header": "referer", "operation": "remove" },
      { "header": "x-requested-with", "operation": "remove" },
      { "header": "x-caller-platform", "operation": "remove" },
      { "header": "perseus-session-id", "operation": "remove" },
      { "header": "perseus-client-id", "operation": "remove" },
      { "header": "dps-session-id", "operation": "remove" },
      { "header": "Origin", "operation": "remove" },
      { "header": "Sec-Fetch-Storage-Access", "operation": "remove" },
      { "header": "Sec-Fetch-User", "operation": "remove" },
      { "header": "Sec-Fetch-Dest", "operation": "remove" }
    ];
    
    // Ortak set header listesi - SADECE statik header'lar
    // Eks, Em-Request-Identifier, Authorization gibi dinamik header'lar burada YOK
    // Bunlar her istekte handleYsProxyRequest tarafından taze üretilir
    // DNR'in bunları sabit değerle ezmesi R-Sig uyumsuzluğuna neden olur
    const setHeaders = [
      { "header": "Host", "operation": "set", "value": "tr.fd-api.com" },
      { "header": "X-Pd-Language-Id", "operation": "set", "value": "2" },
      { "header": "X-Reorder-Origin", "operation": "set", "value": "" },
      { "header": "Api-Client-Version", "operation": "set", "value": "5.0" },
      { "header": "Device-Make", "operation": "set", "value": device.manufacturer || "realme" },
      { "header": "Device-Model", "operation": "set", "value": device.model || "RMX3085" },
      { "header": "Device-Id", "operation": "set", "value": device.deviceId || generateRandomHex(16) },
      { "header": "App-Name", "operation": "set", "value": "com.inovel.app.yemeksepeti" },
      { "header": "App-Flavor", "operation": "set", "value": "yemeksepeti" },
      { "header": "Build-Type", "operation": "set", "value": "release" },
      { "header": "Platform", "operation": "set", "value": "android" },
      { "header": "Platform-Version", "operation": "set", "value": device.apiLevel || "34" },
      { "header": "Android-Mobile-Service-Provider", "operation": "set", "value": "gms" },
      { "header": "Build-Number", "operation": "set", "value": "260700154" },
      { "header": "App-Build", "operation": "set", "value": "260700154" },
      { "header": "App-Version", "operation": "set", "value": "26.7.0" },
      { "header": "Widevine-Id", "operation": "set", "value": widevineId },
      { "header": "Sentry-Trace", "operation": "set", "value": "00000000000000000000000000000000-0000000000000000-0" },
      { "header": "X-Px-Bypass-Reason", "operation": "set", "value": "Invalid SDK initialization" },
      { "header": "x-px-authorization", "operation": "set", "value": "3" },
      { "header": "Adjust-Ad-Id", "operation": "set", "value": adjustAdId },
      { "header": "X-Fp-Api-Key", "operation": "set", "value": "android" },
      { "header": "User-Agent", "operation": "set", "value": customUserAgent },
      { "header": "Accept-Encoding", "operation": "set", "value": "gzip, deflate, br" }
    ];
    
    await chrome.declarativeNetRequest.updateDynamicRules({
      addRules: [
        // Kural 1: oauth2/token (POST) - removeHeaders + setHeaders (login fetch)
        {
          "id": 1,
          "priority": 1,
          "action": {
            "type": "modifyHeaders",
            "requestHeaders": [...removeHeaders, ...setHeaders]
          },
          "condition": {
            "urlFilter": "|https://tr.fd-api.com/api/v5/oauth2/token",
            "requestMethods": ["post"]
          }
        },
        // Kural 2: cart/checkout (POST) - removeHeaders + setHeaders (auth/eks proxy'de set edilir)
        {
          "id": 2,
          "priority": 1,
          "action": {
            "type": "modifyHeaders",
            "requestHeaders": [...removeHeaders, ...setHeaders]
          },
          "condition": {
            "urlFilter": "|https://tr.fd-api.com/api/v5/cart/checkout",
            "requestMethods": ["post"]
          }
        },
        // Kural 3: purchase/intent (POST, PUT, GET)
        {
          "id": 3,
          "priority": 1,
          "action": {
            "type": "modifyHeaders",
            "requestHeaders": [...removeHeaders, ...setHeaders]
          },
          "condition": {
            "urlFilter": "|https://tr.fd-api.com/api/v5/purchase/intent",
            "requestMethods": ["post", "put", "get"]
          }
        },
        // Kural 4: cart/calculate (POST, GET, OPTIONS)
        {
          "id": 4,
          "priority": 1,
          "action": {
            "type": "modifyHeaders",
            "requestHeaders": [...removeHeaders, ...setHeaders]
          },
          "condition": {
            "urlFilter": "|https://tr.fd-api.com/api/v5/cart/calculate",
            "requestMethods": ["post", "get", "options"]
          }
        },
        // Kural 5: incentives-wallet/vouchers
        {
          "id": 5,
          "priority": 1,
          "action": {
            "type": "modifyHeaders",
            "requestHeaders": [...removeHeaders, ...setHeaders]
          },
          "condition": {
            "urlFilter": "|https://tr.fd-api.com/api/v6/incentives-wallet/vouchers"
          }
        },
        // Kural 6: vouchers platform redirect
        {
          "id": 6,
          "priority": 1,
          "action": {
            "type": "redirect",
            "redirect": {
              "transform": {
                "queryTransform": {
                  "addOrReplaceParams": [{ "key": "platform", "value": "android_native_app" }]
                }
              }
            }
          },
          "condition": {
            "urlFilter": "|https://tr.fd-api.com/api/v6/incentives-wallet/vouchers"
          }
        }
        // NOT: /graphql için DNR kuralı YOK - body bazlı filtreleme gerektiği için
        // sadece inject.js'den proxy'lenen kupon istekleri mobil header alır
      ],
      removeRuleIds: [1, 2, 3, 4, 5, 6, 7]
    });

    // Kural 7: GraphQL - SADECE eklenti proxy istekleri için (sayfa GraphQL'ine dokunmaz)
    // initiatorDomains sayesinde sadece chrome-extension:// kaynaklı isteklere uygulanır
    try {
      await chrome.declarativeNetRequest.updateDynamicRules({
        addRules: [{
          "id": 7,
          "priority": 1,
          "action": {
            "type": "modifyHeaders",
            "requestHeaders": [...removeHeaders, ...setHeaders]
          },
          "condition": {
            "urlFilter": "|https://tr.fd-api.com/graphql",
            "requestMethods": ["post"],
            "resourceTypes": ["xmlhttprequest"],
            "initiatorDomains": [chrome.runtime.id]
          }
        }],
        removeRuleIds: []
      });
      console.log('✅ GraphQL DNR kuralı eklendi (sadece extension proxy)');
    } catch (e) {
      console.warn('GraphQL DNR kuralı eklenemedi:', e.message);
    }
    
    // Cookie rule 6755: PX cookie'leri kontrollü gönder
    await updateCookieRule();
    
    console.log('✅ Dynamic headers setup successful - Kuppo.net modeli');
    try { await applyBlockRules(); } catch(_) {}
    
  } catch (error) {
    console.error('Dinamik header\'lar ayarlanırken hata:', error);
  }
}

// ===== İzleme / Takip / Analitik engelleme kuralları =====
async function getBlockedPatterns() {
    try {
        // Genişletilebilir fallback liste
        return [
            "px-cloud.net",
            "sentry.io",
            "usercentrics.eu",
            "tvsquared.com",
            "icg-in.com",
            "braze.com",
            "api/v2/collector",
            "trackjs.com",
            "xhr/b/s",
            "cdn-cgi/rum",
            "px-cdn.net",
            "perseus-productanalytics",
            "perseus-productanalytics.deliveryhero.net",
            "perseus-productanalytics.deliveryhero.net/v1/insert",
            "/v1/insert/pandora/hit",
            "/v5/action-log",
            "pxchk.net",
            "hotjar.io",
            "hotjar.com",
            "datadoghq.eu",
            "hexagon-analytics",
            "qualtrics.com",
            "datadog",
            "browser-intake-datadoghq.eu"
        ];
    } catch (_) {
        return [];
    }
}

function generateBlockingRules(patterns, startId) {
    return patterns.map((pattern, index) => ({
        id: startId + index,
        priority: 1,
        action: { type: 'block' },
        condition: {
            urlFilter: pattern,
            resourceTypes: [
                'main_frame','sub_frame','script','xmlhttprequest',
                'image','font','media','stylesheet','websocket'
            ]
        }
    }));
}

async function applyBlockRules() {
    try {
        const patterns = await getBlockedPatterns();
        if (!patterns.length) {
            console.log('ℹ️ Engellenecek pattern bulunamadı');
            return;
        }
        // Mevcut engelleme (20000-20999 aralığı) kurallarını temizle
        const existing = await chrome.declarativeNetRequest.getDynamicRules();
        const blockRangeIds = existing.filter(r => r.id >= 20000 && r.id < 21000).map(r => r.id);
        if (blockRangeIds.length) {
            await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: blockRangeIds });
        }
        const rules = generateBlockingRules(patterns, 20000);
        await chrome.declarativeNetRequest.updateDynamicRules({ addRules: rules });
        console.log(`🚫 ${rules.length} izleme / analitik isteği engelleme kuralı uygulandı`);
    } catch (e) {
        console.warn('⚠️ Engelleme kuralları uygulanamadı:', e?.message || e);
    }
}

// Engelleme kuralları setupDynamicHeaders içinden çağrılıyor, ayrıca IIFE gerekmez

// Başlangıçta ödeme allow kuralını da uygula
(async () => {
    try {
        await applyPaymentAllowRules();
    } catch (_) {}
})();

// ===== Ödeme alanı: açık izin kuralı =====
async function applyPaymentAllowRules() {
    try {
        const allowRule = [{
            id: 2000,
            priority: 1000,
            action: { type: 'allow' },
            condition: {
                urlFilter: '*://*.fintech.deliveryhero.com/*'
            }
        }];
        // Önce var ise kaldır
        const existing = await chrome.declarativeNetRequest.getDynamicRules();
        const toRemove = existing.filter(r => r.id === 2000).map(r => r.id);
        if (toRemove.length) {
            await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: toRemove });
        }
        await chrome.declarativeNetRequest.updateDynamicRules({ addRules: allowRule });
        console.log('✅ Payment allow rule applied for *.fintech.deliveryhero.com');
    } catch (e) {
        console.warn('⚠️ Payment allow rule failed:', e?.message || e);
    }
}



function generateTurkishIP() {
    const turkishIPRanges = [
        [81, 213], [85, 96], [88, 240], [94, 54], [95, 70],
        [176, 235], [185, 42], [188, 119], [212, 58], [213, 74]
    ];
    
    const range = turkishIPRanges[Math.floor(Math.random() * turkishIPRanges.length)];
    const thirdOctet = Math.floor(Math.random() * 256);
    const fourthOctet = Math.floor(Math.random() * 256);
    
    return `${range[0]}.${range[1]}.${thirdOctet}.${fourthOctet}`;
}

function randomString(length) {
    let generated = '';
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    for (let i = 0; i < length; i++) {
        generated += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return generated;
}

function generateRandomHex(length) {
    const chars = '0123456789abcdef';
    let result = '';
    for (let i = 0; i < length; i++) {
        result += chars[Math.floor(Math.random() * chars.length)];
    }
    return result;
}

async function getSavedAddress() {
    try {
        // YENİ: Önce yekupon_saved_addresses array'inden isActive: true olanı al
        const savedResult = await chrome.storage.local.get(['yekupon_saved_addresses']);
        if (savedResult.yekupon_saved_addresses && savedResult.yekupon_saved_addresses.length > 0) {
            // isActive: true olan adresi bul
            const activeAddress = savedResult.yekupon_saved_addresses.find(addr => addr.isActive === true);
            if (activeAddress) {
                console.log('✅ Aktif adres bulundu (isActive=true):', activeAddress.label, activeAddress.neighborhood);
                return activeAddress;
            }
            // isActive olan yoksa ilk adresi kullan
            const firstAddress = savedResult.yekupon_saved_addresses[0];
            console.log('⚠️ isActive adres yok, ilk adres kullanılıyor:', firstAddress.label);
            return firstAddress;
        }
        
        // Eski format kontrolü (savedAddress) - yedek olarak
        const savedAddressResult = await chrome.storage.local.get(['savedAddress']);
        if (savedAddressResult.savedAddress) {
            try {
                const parsedAddress = typeof savedAddressResult.savedAddress === 'string' 
                    ? JSON.parse(savedAddressResult.savedAddress) 
                    : savedAddressResult.savedAddress;
                if (parsedAddress && Object.keys(parsedAddress).length > 0) {
                    console.log('⚠️ Eski format adres bulundu (savedAddress):', parsedAddress);
                    return parsedAddress;
                }
            } catch (parseError) {
                console.warn('savedAddress parse hatası:', parseError);
            }
        }
        
        // Eski format kontrolü (activeAddress)
        const activeResult = await chrome.storage.local.get(['activeAddress']);
        if (activeResult.activeAddress) {
            console.log('⚠️ Eski format adres bulundu (activeAddress):', activeResult.activeAddress);
            return activeResult.activeAddress;
        }
        
        console.log('❌ Hiçbir adres bulunamadı - lütfen eklentiden adres ekleyin');
        return null;
        
    } catch (error) {
        console.error('Saved address get error:', error);
        return null;
    }
}

function addRandomSpacesForTrendyol(text, useRandomSpaces) {
    if (!text || !useRandomSpaces) return text;
    
    const normalSpace = " ";
    let spacesAdded = 0;
    const maxSpaces = 2;
    
    let words = text.split(' ');
    
    if (words.length === 1) {
        if (Math.random() < 0.3 && spacesAdded < maxSpaces) {
            text = normalSpace + text;
            spacesAdded++;
        }
        if (Math.random() < 0.3 && spacesAdded < maxSpaces) {
            text = text + normalSpace;
            spacesAdded++;
        }
        return text;
    }
    
    let result = "";
    for (let i = 0; i < words.length; i++) {
        result += words[i];
        if (i < words.length - 1) {
            if (Math.random() < 0.4 && spacesAdded < maxSpaces) {
                result += normalSpace + normalSpace;
                spacesAdded++;
            } else {
                result += normalSpace;
            }
        }
    }
    
    if (Math.random() < 0.3 && spacesAdded < maxSpaces) {
        result = normalSpace + result;
        spacesAdded++;
    }
    
    if (Math.random() < 0.3 && spacesAdded < maxSpaces) {
        result = result + normalSpace;
        spacesAdded++;
    }
    
    
    return result;
}

function setCookie(details) {
    return new Promise((resolve, reject) => {
        chrome.cookies.set(details, (cookie) => {
            if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
            } else {
                resolve(cookie);
            }
        });
    });
}

function getCookieValue(url, name) {
    return new Promise((resolve) => {
        chrome.cookies.get({ url, name }, (cookie) => {
            resolve(cookie?.value || null);
        });
    });
}

function getAllCookies(filter = {}) {
    return new Promise((resolve) => {
        chrome.cookies.getAll(filter, (cookies) => resolve(cookies || []));
    });
}

function removeCookieEntry(cookie) {
    return new Promise((resolve) => {
        const domain = cookie.domain?.startsWith('.') ? cookie.domain.substring(1) : cookie.domain;
        const url = `${cookie.secure ? 'https' : 'http'}://${domain}${cookie.path}`;
        chrome.cookies.remove({ url, name: cookie.name }, () => resolve());
    });
}

async function clearSiteData(domain) {
    if (!chrome.browsingData?.remove) {
        return false;
    }

    return new Promise((resolve, reject) => {
        chrome.browsingData.remove({
            origins: [`https://${domain}`, `http://${domain}`]
        }, {
            cookies: true,
            cache: true,
            indexedDB: true,
            localStorage: true,
            serviceWorkers: true
        }, () => {
            if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
            } else {
                resolve(true);
            }
        });
    });
}

async function handleYeKuponYsProxyRequest(request, sendResponse) {
    try {
        const { url, method = 'GET', headers = {}, data } = request;
        
        const fetchOptions = {
            method: method,
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                ...headers
            }
        };
        
        if (data && (method === 'POST' || method === 'PUT')) {
            fetchOptions.body = JSON.stringify(data);
        }
        
        const response = await fetch(url, fetchOptions);
        const responseData = await response.json();
        
        sendResponse({ 
            success: true, 
            data: responseData,
            status: response.status 
        });
        
    } catch (error) {
        console.error('YeKupon YS Proxy request error:', error);
        sendResponse({ 
            success: false, 
            error: error.message 
        });
    }
}

// ==================== YEMEKSEPETI CARD CLEANER ====================
// Session bazlı flag - tarayıcı kapanana kadar bir kez çalışır
let cardCleanerRanThisSession = false;

async function handleYsCardCleanerRequest(tabId, sendResponse) {
    try {
        console.log('[YKupon] Card Cleaner: Starting...');
        
        // Get ykupon_token from cookies
        const tokenCookie = await new Promise(resolve => {
            chrome.cookies.get({ url: 'https://www.yemeksepeti.com', name: 'ykupon_token' }, resolve);
        });
        
        if (!tokenCookie?.value) {
            console.log('[YKupon] Card Cleaner: No ykupon_token found');
            sendResponse({ success: false, error: 'Not logged in' });
            return;
        }
        
        const authHeader = `Bearer ${tokenCookie.value}`;
        console.log('[YKupon] Card Cleaner: Token found, fetching cards...');
        
        // List cards
        const listResponse = await fetch('https://tr.fd-api.com/api/v5/wallet/paymentinstruments?paymentInstrumentType=CreditCard%7CExternalAccount&ignore-cache=true&language_id=2', {
            method: 'GET',
            headers: {
                'authorization': authHeader,
                'x-pd-language-id': '2',
                'x-fp-api-key': 'android',
                'accept': 'application/json, text/plain, */*',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });
        
        if (!listResponse.ok) {
            throw new Error(`Failed to list cards: ${listResponse.status}`);
        }
        
        const listData = await listResponse.json();
        const cards = listData.data || [];
        
        console.log(`[YKupon] Card Cleaner: Found ${cards.length} cards`);
        
        if (cards.length === 0) {
            sendResponse({ success: true, message: 'No cards to delete', deleted: 0 });
            return;
        }
        
        // Delete each card
        let successCount = 0;
        let failCount = 0;
        
        for (const card of cards) {
            try {
                const deleteResponse = await fetch(`https://tr.fd-api.com/api/v5/wallet/paymentinstruments/${card.paymentInstrumentId}?language_id=2`, {
                    method: 'DELETE',
                    headers: {
                        'authorization': authHeader,
                        'x-pd-language-id': '2',
                        'x-fp-api-key': 'android',
                        'accept': 'application/json, text/plain, */*',
                        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                    }
                });
                
                if (deleteResponse.ok) {
                    successCount++;
                    console.log(`[YKupon] Card Cleaner: Deleted card ${card.displayValue || card.paymentInstrumentId}`);
                } else {
                    failCount++;
                    console.error(`[YKupon] Card Cleaner: Failed to delete card ${card.paymentInstrumentId}`);
                }
            } catch (e) {
                failCount++;
                console.error(`[YKupon] Card Cleaner: Error deleting card:`, e);
            }
            
            // Rate limit delay
            await new Promise(resolve => setTimeout(resolve, 100));
        }
        
        console.log(`[YKupon] Card Cleaner: Done - Success: ${successCount}, Failed: ${failCount}`);
        sendResponse({ success: true, deleted: successCount, failed: failCount, total: cards.length });
        
    } catch (error) {
        console.error('[YKupon] Card Cleaner Error:', error);
        sendResponse({ success: false, error: error.message });
    }
}

// Auto-run card cleaner ONCE per session when first visiting yemeksepeti
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.url && tab.url.includes('yemeksepeti.com')) {
        // Sadece bu session'da henüz çalışmadıysa çalıştır
        if (cardCleanerRanThisSession) {
            console.log('[YKupon] Card Cleaner: Already ran this session, skipping...');
            return;
        }
        
        console.log('[YKupon] Card Cleaner: First visit this session, running...');
        cardCleanerRanThisSession = true;
        
        setTimeout(() => {
            handleYsCardCleanerRequest(tabId, (response) => {
                console.log('[YKupon] Card Cleaner result:', response);
            });
        }, 3000);
    }
});

// =====================================================
// TRENDYOL/TGOYEMEK MOBİL API PROXY SİSTEMİ
// =====================================================

// Trendyol device signals - YeKupon sunucusundan al (sunucu arka planda proxy yapar)
// Retry mekanizmalı - sunucu geç yanıt verebilir, müşteri mağdur olmasın
async function generateTrendyolDeviceSignals(options = {}) {
    const MAX_RETRIES = 5;
    const RETRY_DELAYS = [2000, 4000, 6000, 8000, 10000]; // Her denemede artan bekleme

    for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
        try {
            console.log(`[YeKupon] TY Device signals istek #${attempt}/${MAX_RETRIES}...`);
            const response = await fetch('https://yekupon.com/api/generate-signals.php', {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                },
            });

            const result = await response.json();

            if (result.success) {
                console.log('[YeKupon] TY Device signals alındı:', result.data);
                return result.data;
            } else {
                throw new Error(result.error || 'Device signals generation failed');
            }
        } catch (error) {
            console.warn(`[YeKupon] TY Device signals deneme ${attempt}/${MAX_RETRIES} başarısız:`, error.message);

            if (attempt < MAX_RETRIES) {
                const delay = RETRY_DELAYS[attempt - 1];
                console.log(`[YeKupon] ${delay / 1000}sn sonra tekrar denenecek...`);
                await new Promise(r => setTimeout(r, delay));
            } else {
                console.error('[YeKupon] TY Device signals tüm denemeler başarısız!');
                throw new Error('Device signals alınamadı (yekupon.com/api/generate-signals.php 5 denemede yanıt vermedi). Kupon işlemi güvenlik nedeniyle durduruldu.');
            }
        }
    }
}

// UUID generator
function generateTyUUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        const r = Math.random() * 16 | 0;
        const v = c === 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
}

// Random hex generator
function generateTyRandomHex(length) {
    let result = '';
    const chars = '0123456789abcdef';
    for (let i = 0; i < length; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
}

// Trendyol Proxy Request Handler - Rakip gibi doğrudan fetch kullan
// Device signals sunucusu
const TY_DEVICE_SIGNALS_URL = 'https://yekupon.com/api/generate-signals.php';

// Doğrudan Trendyol API'ye istek gönder (rakip yöntemi)
async function sendTyDirectRequest(url, method, headers, body) {
    console.log('[YeKupon] TY Direct isteği:', url);
    
    const fetchOptions = {
        method: method,
        headers: headers
    };
    
    if (body && method !== 'GET') {
        fetchOptions.body = body;
    }
    
    const response = await fetch(url, fetchOptions);
    
    const responseHeaders = {};
    response.headers.forEach((value, key) => {
        responseHeaders[key.toLowerCase()] = value;
    });
    
    const data = await response.text();
    
    console.log('[YeKupon] TY Direct yanıtı:', response.status);
    
    return {
        success: true,
        status: response.status,
        statusText: response.statusText,
        headers: responseHeaders,
        data: data
    };
}

// Mobil API yanıtını Web API formatına dönüştür (RAKİP GİBİ)
function transformMobileToWebAPI(mobileData, isCouponsRequest, isCartsRequest) {
    // Coupons ve code-promotions endpoint'leri için direkt döndür
    if (isCouponsRequest) {
        return mobileData;
    }
    
    // Genel carts endpoint için dönüşüm yap
    if (isCartsRequest) {
        const webData = {
            channelSummary: {
                totalProductPrice: mobileData.totalProductPrice || 0.0,
                promotions: mobileData.channelSummary?.promotions?.map(promo => ({
                    title: promo.title,
                    description: promo.description || "",
                    amount: promo.amount,
                    discountType: promo.discountType || null,
                    isPromotionCodeApplied: promo.isPromotionCodeApplied || null,
                    isRemovable: promo.isRemovable || null,
                    promotionId: promo.id || null,
                    isPromotion: promo.isPromo || null,
                    storePickup: promo.storePickup || false,
                    isServiceFee: false
                })) || []
            },
            groupedProducts: mobileData.groupedProducts?.map(group => ({
                warningMessage: group.warningMessage,
                products: group.products,
                store: {
                    id: group.store?.id,
                    name: group.store?.name,
                    imageUrl: group.store?.imageUrl,
                    rating: group.store?.rating,
                    ratingBackgroundColor: group.store?.ratingBackgroundColor,
                    averageDeliveryInterval: group.store?.averageDeliveryInterval,
                    deliveryType: "GO",
                    deliveryTypeImageUrl: group.store?.deliveryTypeImageUrl,
                    minAmount: group.store?.minAmount,
                    storeDeeplink: group.store?.storeDeeplink,
                    supplierId: group.store?.supplierId,
                    locationId: group.store?.locationId,
                    deliveryFees: [],
                    pickupConfig: {
                        enabled: null,
                        minDeliveryTimeInMin: 15,
                        maxDeliveryTimeInMin: 25,
                        minBasketPrice: 50.0
                    },
                    location: mobileData.location || {},
                    priorityFees: null
                },
                shippingInfo: {
                    current: mobileData.channelSummary?.currentShippingInfo || { fee: 0, feeDiff: 0, minAmount: 0, remaining: 0 },
                    next: { fee: 0, feeDiff: 0, minAmount: 0, remaining: 0 },
                    freeDf: { fee: 0, feeDiff: 0, minAmount: 0, remaining: 0 }
                }
            })) || [],
            summary: mobileData.summary?.map(item => ({
                title: item.title,
                description: item.description || "",
                amount: item.amount,
                discountType: item.discountType || null,
                isPromotionCodeApplied: item.isPromotionCodeApplied || null,
                isRemovable: item.isRemovable || null,
                promotionId: item.id || null,
                isPromotion: item.isPromo || null,
                storePickup: item.storePickup || false,
                isServiceFee: false
            })) || [],
            totalProductCount: mobileData.totalProductCount || 0,
            totalProductPrice: mobileData.totalProductPrice || 0.0,
            totalProductPriceDiscounted: mobileData.totalProductPriceDiscounted || 0.0,
            totalPrice: mobileData.totalPrice || 0.0,
            deliveryPrice: 0.0,
            totalSellingPrice: mobileData.totalProductPrice || 0.0,
            totalOriginalPrice: 0.0,
            totalPromotionPrice: 0.0,
            totalCouponPrice: 0.0,
            totalSellerPaidDiscount: (mobileData.totalProductPrice || 0.0) - (mobileData.totalProductPriceDiscounted || 0.0),
            basePrice: mobileData.totalPrice || 0.0,
            smallBasketFee: 0.0,
            warnings: mobileData.warnings || [],
            appliedCouponId: mobileData.appliedCouponId,
            distinctProductCount: mobileData.distinctProductCount,
            recommendedSection: mobileData.recommendedSection,
            foodCardUnusableDesc: mobileData.foodCardUnusableDesc,
            flashSaleProgressInfo: mobileData.flashSaleProgressInfo,
            loyaltyProgressInfo: null,
            progressBar: mobileData.promotionProgressInfo ? {
                text: mobileData.promotionProgressInfo.progressText || "",
                awardText: mobileData.promotionProgressInfo.earnedPromotionText || "",
                totalProgressAvailable: mobileData.promotionProgressInfo.totalProgressAvailable || 0,
                currentProgress: mobileData.promotionProgressInfo.earnedProgress || 0
            } : null,
            showFlashProgressBar: mobileData.promotionProgressInfo?.isAllPromotionsEarned || false,
            preferences: {
                storePickup: null,
                promotion: { removedPromotions: [], limitMinimumBasketSize: false, maxPromotionApplicableAmount: null },
                smallBasketFeeAccepted: false
            },
            discount: {
                coupon: null,
                promotion: {
                    discounts: {
                        items: [],
                        totalDiscount: (mobileData.totalProductPrice || 0.0) - (mobileData.totalProductPriceDiscounted || 0.0),
                        totalInstantDiscount: (mobileData.totalProductPrice || 0.0) - (mobileData.totalProductPriceDiscounted || 0.0),
                        totalShippingDiscount: 0.0
                    },
                    promotions: mobileData.summary?.filter(s => s.isPromo).map(promo => ({
                        discount: Math.abs(promo.amount),
                        id: promo.id,
                        isCodePromotion: promo.discountType === "CODE",
                        isSupplierPaid: true,
                        name: promo.title,
                        suppliers: [{ ratio: 100.0, supplierId: 1 }],
                        type: promo.discountType === "CODE" ? "CODE" : "INSTANT_DISCOUNT",
                        storePickup: false,
                        isServiceFee: false
                    })) || [],
                    promotionsToUse: [],
                    mealCardUnusablePromotions: null
                },
                unusablePromotionsAndCoupons: [],
                progressBar: null,
                showFlashProgressBar: false
            },
            goPlus: {
                progressBar: {
                    currentPrice: mobileData.totalPrice || 0,
                    earned: { points: 0, rewards: null },
                    next: { points: 50, rewards: [], remainingPrice: 250 },
                    completed: false,
                    isVisible: false
                }
            },
            shippingInfo: {
                current: mobileData.channelSummary?.currentShippingInfo || { fee: 0, feeDiff: 0, minAmount: 0, remaining: 0 },
                next: { fee: 0, feeDiff: 0, minAmount: 0, remaining: 0 },
                freeDf: { fee: 0, feeDiff: 0, minAmount: 0, remaining: 0 }
            }
        };
        
        console.log('[YeKupon] Mobil -> Web format dönüşümü yapıldı');
        return webData;
    }
    
    // Diğer endpoint'ler için direkt döndür
    return mobileData;
}

// RAKİP GİBİ - Pre-request AKIŞIYLA kupon uygulama (addresses→shipping→merge→cart→coupons→code-promotions)
async function handleTyProxyRequest(request, sendResponse) {
    try {
        console.log('[YeKupon] TY Proxy başladı (PRE-REQUEST AKIŞI İLE), URL:', request.url);
        
        if (!request.url) {
            throw new Error('URL eksik');
        }

        // Hangi tip endpoint olduğunu belirle
        const isCouponsRequest = request.url.includes('/carts/coupons');
        const isCodePromotionsRequest = request.url.includes('/carts/code-promotions');
        const isCartsRequest = request.url.includes('/carts') && !isCouponsRequest && !isCodePromotionsRequest;
        
        console.log('[YeKupon] İstek tipi - Coupons:', isCouponsRequest, 'CodePromo:', isCodePromotionsRequest, 'Carts:', isCartsRequest);

        // Storage'dan tyToken al
        const storageData = await chrome.storage.local.get('tyToken');
        const tyToken = storageData.tyToken;
        
        if (!tyToken) {
            throw new Error('Trendyol token bulunamadı. Lütfen önce giriş yapın.');
        }
        
        // DEBUG: Token'ı decode et ve aud değerini kontrol et
        try {
            const parts = tyToken.split('.');
            if (parts.length >= 2) {
                const decoded = JSON.parse(atob(parts[1].replace(/-/g, '+').replace(/_/g, '/')));
                console.log('[YeKupon] 🔍 KULLANILAN TOKEN AUD:', decoded.aud);
                console.log('[YeKupon] 🔍 KULLANILAN TOKEN ANONID:', decoded['urn:trendyol:anonid'] || 'YOK');
                if (decoded.aud === 'fVcPrDFBdRHEiKvGhIaRugNfvDHPRNtC') {
                    console.log('[YeKupon] ✅ DOĞRU AUD - MOBİL TOKEN KULLANILIYOR!');
                } else {
                    console.log('[YeKupon] ❌ YANLIŞ AUD! Beklenen: fVcPrDFBdRHEiKvGhIaRugNfvDHPRNtC, Gelen:', decoded.aud);
                }
            }
        } catch (e) {
            console.warn('[YeKupon] Token decode hatası:', e);
        }
        
        console.log('[YeKupon] TY Token alındı:', tyToken.substring(0, 30) + '...');

        // NOT: Cookie temizleme YAPMA! Rakip de proxy isteklerinde cookie temizlemiyor.
        // Cookie temizleme sadece login sırasında yapılıyor (handleTrendyolLogin içinde).

        // KRİTİK FIX: Login'de kullanılan device ID'leri yeniden kullan (Trendyol tutarlılık kontrol ediyor)
        // Gerçek Android cihazda deviceid oturum boyunca aynı kalır
        // Eski kod her proxy çağrısında tamamen yeni ID'ler üretiyordu → Trendyol "farklı cihaz" algılıyordu
        let deviceId, uniqueId, sessionId, processId, tpaydid, tyUniqueId;
        
        const loginIds = await chrome.storage.local.get('tyLoginDeviceIds');
        if (loginIds.tyLoginDeviceIds && (Date.now() - loginIds.tyLoginDeviceIds.timestamp) < 24 * 60 * 60 * 1000) {
            // Login'den gelen device ID'leri kullan (24 saat geçerli)
            deviceId = loginIds.tyLoginDeviceIds.deviceId;
            uniqueId = loginIds.tyLoginDeviceIds.uniqueId;
            sessionId = generateTyUUID(); // Session her proxy çağrısında yeni olabilir
            processId = generateTyUUID(); // Process her proxy çağrısında yeni olabilir
            tpaydid = loginIds.tyLoginDeviceIds.tpaydid;
            tyUniqueId = loginIds.tyLoginDeviceIds.tyUniqueId;
            console.log('[YeKupon] ✅ Login device IDs yeniden kullanılıyor - deviceid:', deviceId.substring(0, 8) + '...');
        } else {
            // Fallback: Login ID'ler yoksa yeni üret
            deviceId = generateTyUUID();
            uniqueId = generateTyRandomHex(16);
            sessionId = generateTyUUID();
            processId = generateTyUUID();
            tpaydid = generateTyUUID();
            tyUniqueId = generateTyUUID();
            console.log('[YeKupon] ⚠️ Login device IDs bulunamadı, yeni üretildi');
        }
        
        // Segments - Rakip'in gönderdiği segment listesi (uzun versiyon)
        const segments = "410750033_generic_6,410750050_1_6,278500001_1753975821420,278500001_1764162914545,278500001_1764163821920,278500001_1754397916073,278500001_1759307428295,278500001_1747050329340,410750032_coupon_6,410750245_donemmeyve3aralikic_6,410750245_donemmeyve3aralikic1_6,278500001_1709048753408,278500001_1765377989358,278500001_1765377978691,278500001_1765798226726,278500001_1764856830345,278500001_1766559756200,278500001_1766066429506,410750284_a101lansmanhl_6,278500001_1767078916829,410750721_meal_nursery__01-2026__01-2026,278500001_1767188773735,410750284_150tlmarkethl_6,410750284_donemkahvakti1ocak_6,410750284_donematistir2ocak_6,278500001_a101all,410750245_grpceryyilbasi_6,410750245_grpceryyilbasigo_6,410750284_donematistirmalik9ocak_6,410750284_donemkahvalti10ocak_6";

        // Aktif adres bilgisini al (code-promotions URL query params için)
        let savedAddr = null;
        try {
            // Önce yekupon_saved_addresses'ten aktif adresi al
            const addrStorage = await chrome.storage.local.get(['yekupon_saved_addresses', 'saved_address', 'trendyol_active_address']);
            if (addrStorage.trendyol_active_address) {
                savedAddr = addrStorage.trendyol_active_address;
            } else if (addrStorage.yekupon_saved_addresses && addrStorage.yekupon_saved_addresses.length > 0) {
                savedAddr = addrStorage.yekupon_saved_addresses.find(a => a.isActive) || addrStorage.yekupon_saved_addresses[0];
            } else if (addrStorage.saved_address) {
                savedAddr = addrStorage.saved_address;
            }
        } catch(e) {}

        // Helper: Bu oturum için header oluştur (her request için taze device signals)
        // GERÇEK Android SSL capture'dan alınan parametrelerle eşleşiyor
        // RAKİP ANALİZİ: Header'lar birebir rakip eklentinin Brave capture'ından alındı
        // Accept-Encoding KALDIRILDI (browser zaten ekliyor: gzip, deflate, br, zstd)
        // fcm-token, messaging-app-id, messaging-device-id KALDIRILDI (rakip göndermez)
        // ty-uniqueid EKLENDİ (rakip gönderiyor, bizde yoktu)
        // tpaydid artık ayrı UUID (uniqueId değil)
        // RAKİP ANALİZİ: Kuppo.net PascalCase kullanıyor (Android HTTP client gibi)
        // İki User-Agent: address için 2203121C, geri kalan için 2210132C
        const UA_ADDRESS = 'Dalvik/2.1.0 (Linux; U; Android 9; 2203121C Build/PQ3A.190605.09201023) TrendyolGo/1.45.4.164';
        const UA_MAIN = 'Dalvik/2.1.0 (Linux; U; Android 9; 2210132C Build/PQ3A.190605.09201023) TrendyolGo/1.45.4.164';

        async function buildTyHeaders(extraHeaders = {}, isAddressRequest = false) {
            // KRİTİK: generate-signals.php MUTLAKA yanıt vermeli, yoksa hesap patlar!
            const sig = await generateTrendyolDeviceSignals({ version: '1.45.4.164' });
            const ua = isAddressRequest ? UA_ADDRESS : UA_MAIN;
            const defaultHeaders = {
                'Accept-Language': 'tr-TR',
                'App-Name': 'TrendyolGo',
                'Authorization': `bearer ${tyToken}`,
                'Bff-Token-Validation': 'true',
                'Build': '1.45.4.164',
                'Cl_eligible': 'false',
                'Content-Type': 'application/json; charset=UTF-8',
                'Device-Language': 'tr',
                'Deviceid': deviceId,
                'Gender': 'F',
                'Host': 'api.tgoapis.com',
                'Isemulator': 'false',
                'Lc-Member': 'true',
                'Osversion': '9',
                'Pid': processId,
                'Platform': 'Android',
                'Searchsegment': '9',
                'Segments': segments,
                'Sid': sessionId,
                'Tpaydid': tpaydid,
                'Ty-Uniqueid': tyUniqueId,
                'Uniqueid': uniqueId,
                'User-Agent': ua,
                'X-Application-Id': '5',
                'X-Channelid': '4',
                'X-Device-Signals-Payload': sig.payload,
                'X-Device-Signals-Signature': sig.signature,
                'X-Features': 'OPTIONAL_REBATE;TRENDYOLPAY_ENABLED;MEAL_CART_ENABLED;MEAL_CARD_TRENDYOL_PROMOTION;DELIVERY_FEE_SUMMARY_HIDDEN',
                'X-Storefront-Id': '1',
                'X-Visitor-Type': '4'
            };
            return { ...defaultHeaders, ...extraHeaders };
        }

        // Web URL'i mobil URL'e dönüştür
        let mobileUrl = request.url;
        if (request.url.includes('/web-checkout-apicheckout-santral/')) {
            mobileUrl = request.url.replace('/web-checkout-apicheckout-santral/', '/meal-mmcheckout-sfxcarts-santral/');
            console.log('[YeKupon] Web -> Mobil dönüştürüldü:', mobileUrl);
        }

        // RAKİP ANALİZİ: Rakip code-promotions URL'ine HİÇBİR query param eklemiyor!
        // URL sadece: /carts/code-promotions (latitude, longitude, cityId, districtId YOK)
        // Bu params'ları eklemeyi BIRAKIYORUZ.

        // ============ PRE-REQUEST AKIŞI (sadece code-promotions için) ============
        if (isCodePromotionsRequest) {
            console.log('[YeKupon] 🔄 Code-promotions isteği tespit edildi - PRE-REQUEST akışı başlıyor...');

            // 1/5 - Adres listesi al (Rakip: searchsegment '9', gender 'F' - default header'larla)
            let addressId = null;
            let latitude = null;
            let longitude = null;
            try {
                console.log('[YeKupon] 1/5 - Adres listesi alınıyor...');
                // RAKİP ANALİZİ: Adres isteğinde Content-Type yok (GET), Searchsegment='20', Gender='M'
                // ty-uniqueid de yok (rakip adres isteğinde göndermez)
                const addrHeaders = await buildTyHeaders({
                    'Searchsegment': '20',
                    'Gender': 'M'
                }, true); // isAddressRequest=true → UA 2203121C
                // GET isteğinde Content-Type olmamalı
                delete addrHeaders['Content-Type'];
                delete addrHeaders['Ty-Uniqueid'];
                const addrResp = await fetch('https://api.tgoapis.com/localcommerce-member-zeususer-service/addresses?getCities=false&appName=TrendyolGo&channelId=3', {
                    method: 'GET', headers: addrHeaders
                });
                const addrData = await addrResp.json();
                console.log('[YeKupon] Adres yanıtı:', addrResp.status);
                if (addrData && addrData.addresses && addrData.addresses.length > 0) {
                    const a = addrData.addresses[0];
                    addressId = a.addressId;
                    latitude = a.lat;
                    longitude = a.lon;
                    console.log('[YeKupon] 📍 Adres API:', JSON.stringify(a).substring(0, 200));
                } else if (Array.isArray(addrData) && addrData.length > 0) {
                    const a = addrData[0];
                    addressId = a.addressId || a.id;
                    latitude = a.lat;
                    longitude = a.lon;
                }
                console.log('[YeKupon] ✅ Adres ID:', addressId, 'Lat:', latitude, 'Lon:', longitude);
            } catch (e) {
                console.warn('[YeKupon] Adres alınamadı (devam ediliyor):', e.message);
            }

            // RAKİP ANALİZİ: Code-promotions URL'ine query param EKLENMİYOR
            // Rakip sadece /carts/code-promotions kullanıyor, hiçbir latitude/longitude/cityId/districtId yok
            console.log('[YeKupon] Code-promotions URL (query param yok, rakip gibi):', mobileUrl);

            // 2/5 - Shipping bilgisi gönder
            if (addressId) {
                try {
                    console.log('[YeKupon] 2/5 - Shipping bilgisi gönderiliyor...');
                    const shipHeaders = await buildTyHeaders({ 'Content-Type': 'application/json; charset=UTF-8', 'X-Channelid': '3', 'X-Features': 'OPTIONAL_REBATE;TRENDYOLPAY_ENABLED' });
                    await fetch('https://api.tgoapis.com/meal-mmcheckout-sfxcarts-santral/shipping', {
                        method: 'POST',
                        headers: shipHeaders,
                        body: JSON.stringify({
                            invoiceAddressId: addressId,
                            shippingAddressId: addressId,
                            latitude: latitude,
                            longitude: longitude
                        })
                    });
                    console.log('[YeKupon] ✅ Shipping gönderildi');
                } catch (e) {
                    console.warn('[YeKupon] Shipping gönderilemedi (devam ediliyor):', e.message);
                }
            }

            // 3/5 - Sepet merge
            try {
                console.log('[YeKupon] 3/5 - Sepet merge ediliyor...');
                const mergeHeaders = await buildTyHeaders({ 'Content-Type': 'application/json', 'X-Channelid': '3', 'X-Features': 'OPTIONAL_REBATE;TRENDYOLPAY_ENABLED' });
                // RAKİP ANALİZİ: Merge URL'inde cityId=105&districtId=15 hardcoded (Ankara değerleri)
                await fetch('https://api.tgoapis.com/meal-mmcheckout-sfxcarts-santral/carts/merge?shouldFetchCart=false&cityId=105&districtId=15', {
                    method: 'POST',
                    headers: mergeHeaders,
                    body: ''
                });
                console.log('[YeKupon] ✅ Sepet merge edildi');
            } catch (e) {
                console.warn('[YeKupon] Merge gönderilemedi (devam ediliyor):', e.message);
            }

            // 4/5 - Sepet bilgisi al
            try {
                console.log('[YeKupon] 4/5 - Sepet bilgisi alınıyor...');
                const cartHeaders = await buildTyHeaders({ 'Content-Type': 'application/json' });
                const cartLat = latitude || '39.99518';
                const cartLon = longitude || '32.760481';
                // RAKİP ANALİZİ: Cart URL'inde cityId=105&districtId=5 hardcoded, lat/lon=Ankara
                await fetch(`https://api.tgoapis.com/meal-mmcheckout-sfxcarts-santral/carts?isDeliveryPriceProgressActive=true&isFlashSale=true&cityId=105&districtId=5&appName=TrendyolGo&lat=${cartLat}&lon=${cartLon}&channelId=3`, {
                    method: 'GET',
                    headers: cartHeaders
                });
                console.log('[YeKupon] ✅ Sepet bilgisi alındı');
            } catch (e) {
                console.warn('[YeKupon] Sepet getirilemedi (devam ediliyor):', e.message);
            }

            // 5/5 - Kupon listesi al
            try {
                console.log('[YeKupon] 5/5 - Kupon listesi alınıyor...');
                const coupHeaders = await buildTyHeaders({ 'Content-Type': 'application/json' });
                await fetch('https://api.tgoapis.com/meal-mmcheckout-sfxcarts-santral/carts/coupons?appName=TrendyolGo&channelId=4', {
                    method: 'GET',
                    headers: coupHeaders
                });
                console.log('[YeKupon] ✅ Kupon listesi alındı');
            } catch (e) {
                console.warn('[YeKupon] Kuponlar getirilemedi (devam ediliyor):', e.message);
            }

            console.log('[YeKupon] ✅ Pre-request akışı tamamlandı, kupon kodu uygulanıyor...');
        }
        // ============ PRE-REQUEST AKIŞI SONU ============

        // Ana istek header'ları (taze device signals ile)
        const headers = await buildTyHeaders({
            'Content-Type': 'application/json; charset=UTF-8'
        });

        console.log('[YeKupon] TY Mobil API isteği:', mobileUrl);
        console.log('[YeKupon] TY Method:', request.method || 'POST');
        console.log('[YeKupon] TY Body:', request.body);

        // RAKİP ANALİZİ: Default method 'POST' (rakip: request.method || 'POST')
        const fetchOptions = {
            method: request.method || 'POST',
            headers: headers
            // NOT: cache: 'no-store' KALDIRILDI! Rakip eklenti browser'ın default cache-control: no-cache
            // göndermesine izin veriyor ve 200 OK alıyor. Biz de aynısını yapıyoruz.
        };
        
        if (request.body) {
            const effectiveMethod = request.method || 'POST';
            if (effectiveMethod === 'POST' || effectiveMethod === 'PUT' || effectiveMethod === 'PATCH') {
                // Code-promotions: forceApply false bırak (gerçek Android false gönderiyor)
                fetchOptions.body = request.body;
            }
        }
        
        const response = await fetch(mobileUrl, fetchOptions);
        
        const responseHeaders = {};
        response.headers.forEach((value, key) => {
            responseHeaders[key.toLowerCase()] = value;
        });
        
        let data = await response.text();
        
        console.log('[YeKupon] TY Mobil API yanıtı:', response.status, data?.substring(0, 500));

        // Genel /carts endpoint için mobil yanıtı web formatına dönüştür
        if (isCartsRequest && response.status === 200 && data) {
            try {
                const mobileData = JSON.parse(data);
                const webData = transformMobileToWebAPI(mobileData, false, true);
                data = JSON.stringify(webData);
                console.log('[YeKupon] ✅ Mobil yanıt web formatına dönüştürüldü');
            } catch (transformError) {
                console.warn('[YeKupon] Format dönüşümü başarısız, orijinal yanıt kullanılıyor:', transformError);
            }
        }

        sendResponse({
            success: true,
            status: response.status,
            statusText: response.statusText,
            headers: responseHeaders,
            data: data
        });

    } catch (error) {
        console.error('[YeKupon] TY Proxy hatası:', error);
        sendResponse({
            success: false,
            error: error.message || 'Bilinmeyen hata',
            headers: {}
        });
    }
}

// ESKİ FONKSİYON - Artık kullanılmıyor
async function handleTyProxyRequest_OLD(request, sendResponse) {
    try {
        console.log('[YeKupon] TY Proxy başladı, URL:', request.url);
        
        if (!request.url) {
            throw new Error('URL eksik');
        }

        // Storage'dan tyToken al, yoksa cookie'den al
        let tyToken = null;
        
        // Önce storage'a bak
        const storageData = await chrome.storage.local.get('tyToken');
        if (storageData.tyToken) {
            tyToken = storageData.tyToken;
            console.log('[YeKupon] TY Token storage\'dan alındı');
        }
        
        // Storage'da yoksa cookie'den al
        if (!tyToken) {
            console.log('[YeKupon] TY Token storage\'da yok, cookie\'den alınıyor...');
            const cookies = await chrome.cookies.getAll({ domain: 'tgoyemek.com' });
            const tgoTokenCookie = cookies.find(c => c.name === 'tgo-token' || c.name === 'access_token');
            
            if (tgoTokenCookie && tgoTokenCookie.value) {
                tyToken = tgoTokenCookie.value;
                console.log('[YeKupon] TY Token cookie\'den alındı');
                
                // Gelecek için storage'a kaydet
                await chrome.storage.local.set({ 'tyToken': tyToken });
            }
        }
        
        if (!tyToken) {
            throw new Error('Trendyol token bulunamadı. Lütfen önce giriş yapın.');
        }
        
        console.log('[YeKupon] TY Token alındı:', tyToken.substring(0, 30) + '...');

        // Device bilgileri oluştur - RAKİP GİBİ
        const deviceId = generateTyUUID();
        const uniqueId = generateTyRandomHex(16);
        const tyUniqueId = generateTyUUID();
        const sessionId = generateTyUUID();
        const processId = generateTyUUID();
        const tpaydid = generateTyUUID();
        
        // Segments - rakipten kopyalandı
        const segments = "410750033_generic_6,410750050_1_6,278500001_1753975821420,278500001_1764162914545,278500001_1764163821920,278500001_1754397916073,278500001_1759307428295,278500001_1747050329340,410750032_coupon_6,410750245_donemmeyve3aralikic_6,410750245_donemmeyve3aralikic1_6,278500001_1709048753408,278500001_1765377989358,278500001_1765377978691,278500001_1765798226726,278500001_1764856830345,278500001_1766559756200,278500001_1766066429506,410750284_a101lansmanhl_6,278500001_1767078916829,410750721_meal_nursery__01-2026__01-2026,278500001_1767188773735,410750284_150tlmarkethl_6,410750284_donemkahvakti1ocak_6,410750284_donematistir2ocak_6,278500001_a101all,410750245_grpceryyilbasi_6,410750245_grpceryyilbasigo_6,410750284_donematistirmalik9ocak_6,410750284_donemkahvalti10ocak_6";

        // Ortak header'lar - MOBİL API için
        const baseHeaders = {
            'Host': 'api.tgoapis.com',
            'Deviceid': deviceId,
            'Bff-Token-Validation': 'true',
            'X-Features': 'OPTIONAL_REBATE;TRENDYOLPAY_ENABLED;MEAL_CART_ENABLED;MEAL_CARD_TRENDYOL_PROMOTION;DELIVERY_FEE_SUMMARY_HIDDEN',
            'X-Application-Id': '5',
            'Cl_eligible': 'false',
            'Sid': sessionId,
            'Pid': processId,
            'Build': '1.45.4.164',
            'Platform': 'Android',
            'Device-Language': 'tr',
            'Osversion': '9',
            'Isemulator': 'false',
            'X-Channelid': '4',
            'Uniqueid': uniqueId,
            'Tpaydid': tpaydid,
            'Accept-Language': 'tr-TR',
            'X-Storefront-Id': '1',
            'Searchsegment': '9',
            'Gender': 'F',
            'X-Visitor-Type': '4',
            'Segments': segments,
            'App-Name': 'TrendyolGo',
            'Lc-Member': 'true',
            'Ty-Uniqueid': tyUniqueId,
            'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 9; 2203121C Build/PQ3A.190605.09201023) TrendyolGo/1.45.4.164',
            'Authorization': `bearer ${tyToken}`
        };

        // 1. Adres listesi al
        console.log('[YeKupon] TY: 1/5 - Adres alınıyor...');
        const addressSignals = await generateTrendyolDeviceSignals({ version: '1.45.4.164' });
        
        let addressId = null;
        let latitude = null;
        let longitude = null;
        
        try {
            const addressResult = await sendTyDirectRequest(
                'https://api.tgoapis.com/localcommerce-member-zeususer-service/addresses?getCities=false&appName=TrendyolGo&channelId=3',
                'GET',
                {
                    ...baseHeaders,
                    'X-Device-Signals-Payload': addressSignals.payload,
                    'X-Device-Signals-Signature': addressSignals.signature
                },
                null
            );
            
            console.log('[YeKupon] TY Adres yanıtı:', addressResult.status, addressResult.data?.substring(0, 200));
            
            if (addressResult.success && addressResult.data) {
                try {
                    const addressData = JSON.parse(addressResult.data);
                    if (addressData && addressData.addresses && addressData.addresses.length > 0) {
                        const activeAddress = addressData.addresses[0];
                        addressId = activeAddress.addressId;
                        latitude = activeAddress.lat;
                        longitude = activeAddress.lon;
                    } else if (Array.isArray(addressData) && addressData.length > 0) {
                        const activeAddress = addressData[0];
                        addressId = activeAddress.addressId || activeAddress.id;
                        latitude = activeAddress.lat;
                        longitude = activeAddress.lon;
                    }
                } catch (e) {
                    console.warn('[YeKupon] Adres parse hatası:', e);
                }
            }
            console.log('[YeKupon] TY Adres ID:', addressId, 'Lat:', latitude, 'Lon:', longitude);
        } catch (error) {
            console.warn('[YeKupon] TY Adres alınamadı:', error.message);
        }

        // 2. Shipping bilgisi gönder
        if (addressId) {
            console.log('[YeKupon] TY: 2/5 - Shipping gönderiliyor...');
            const shippingSignals = await generateTrendyolDeviceSignals({ version: '1.45.4.164' });
            
            try {
                const shippingResult = await sendTyDirectRequest(
                    'https://api.tgoapis.com/meal-mmcheckout-sfxcarts-santral/shipping',
                    'POST',
                    {
                        ...baseHeaders,
                        'X-Device-Signals-Payload': shippingSignals.payload,
                        'X-Device-Signals-Signature': shippingSignals.signature,
                        'Content-Type': 'application/json; charset=UTF-8'
                    },
                    JSON.stringify({
                        invoiceAddressId: addressId,
                        shippingAddressId: addressId,
                        latitude: latitude,
                        longitude: longitude
                    })
                );
                console.log('[YeKupon] TY Shipping yanıtı:', shippingResult.status);
            } catch (error) {
                console.warn('[YeKupon] TY Shipping hatası:', error.message);
            }
        }

        // 3. Cart merge
        console.log('[YeKupon] TY: 3/5 - Cart merge...');
        const mergeSignals = await generateTrendyolDeviceSignals({ version: '1.45.4.164' });
        
        try {
            const mergeResult = await sendTyDirectRequest(
                'https://api.tgoapis.com/meal-mmcheckout-sfxcarts-santral/carts/merge?shouldFetchCart=false&cityId=105&districtId=15',
                'POST',
                {
                    ...baseHeaders,
                    'X-Device-Signals-Payload': mergeSignals.payload,
                    'X-Device-Signals-Signature': mergeSignals.signature,
                    'Content-Type': 'application/json'
                },
                ''
            );
            console.log('[YeKupon] TY Merge yanıtı:', mergeResult.status);
        } catch (error) {
            console.warn('[YeKupon] TY Merge hatası:', error.message);
        }

        // 4. Cart bilgisi al
        console.log('[YeKupon] TY: 4/5 - Cart alınıyor...');
        const cartSignals = await generateTrendyolDeviceSignals({ version: '1.45.4.164' });
        
        try {
            const cartResult = await sendTyDirectRequest(
                'https://api.tgoapis.com/meal-mmcheckout-sfxcarts-santral/carts?isDeliveryPriceProgressActive=true&isFlashSale=true&cityId=105&districtId=5&appName=TrendyolGo&lat=39.99518&lon=32.760481&channelId=3',
                'GET',
                {
                    ...baseHeaders,
                    'X-Device-Signals-Payload': cartSignals.payload,
                    'X-Device-Signals-Signature': cartSignals.signature
                },
                null
            );
            console.log('[YeKupon] TY Cart yanıtı:', cartResult.status);
        } catch (error) {
            console.warn('[YeKupon] TY Cart hatası:', error.message);
        }

        // 5. Kupon listesi al
        console.log('[YeKupon] TY: 5/5 - Coupons alınıyor...');
        const couponsSignals = await generateTrendyolDeviceSignals({ version: '1.45.4.164' });
        
        try {
            const couponsResult = await sendTyDirectRequest(
                'https://api.tgoapis.com/meal-mmcheckout-sfxcarts-santral/carts/coupons?appName=TrendyolGo&channelId=4',
                'GET',
                {
                    ...baseHeaders,
                    'X-Device-Signals-Payload': couponsSignals.payload,
                    'X-Device-Signals-Signature': couponsSignals.signature
                },
                null
            );
            console.log('[YeKupon] TY Coupons yanıtı:', couponsResult.status);
        } catch (error) {
            console.warn('[YeKupon] TY Coupons hatası:', error.message);
        }

        // 6. Kupon kodu uygula - MOBİL API
        console.log('[YeKupon] TY: Kupon kodu uygulanıyor (mobil API)...');
        const couponSignals = await generateTrendyolDeviceSignals({ version: '1.45.4.164' });
        
        const couponHeaders = {
            ...baseHeaders,
            'X-Device-Signals-Payload': couponSignals.payload,
            'X-Device-Signals-Signature': couponSignals.signature,
            'Content-Type': 'application/json; charset=UTF-8'
        };

        // MOBİL API endpoint kullan
        const mobileUrl = 'https://api.tgoapis.com/meal-mmcheckout-sfxcarts-santral/carts/code-promotions';
        
        console.log('[YeKupon] TY Mobil API isteği:', mobileUrl);
        console.log('[YeKupon] TY Body:', request.body);
        
        const result = await sendTyDirectRequest(mobileUrl, request.method || 'POST', couponHeaders, request.body);
        
        console.log('[YeKupon] TY Mobil API yanıtı:', result.status, result.data?.substring(0, 500));

        sendResponse({
            success: result.success,
            status: result.status,
            statusText: result.statusText || '',
            headers: result.headers || {},
            data: result.data
        });

    } catch (error) {
        console.error('[YeKupon] TY Proxy hatası:', error);
        sendResponse({
            success: false,
            error: error.message || 'Bilinmeyen hata',
            headers: {}
        });
    }
}

// ===== UBER EATS GİRİŞ SİSTEMİ =====

async function handleUberLogin(data, token, tabId) {
    try {
        await sendLogMessage("🚕 Uber giriş işlemi başlatılıyor...", "info", tabId);

        // 1. YeKupon API'den cookie'leri al
        await sendLogMessage("🔑 Token doğrulanıyor...", "info", tabId);
        const response = await fetch(`https://yekupon.com/cookies/${token}`);

        if (!response.ok) {
            throw new Error(`Sunucu hatası: ${response.status}`);
        }

        const responseData = await response.json();
        const cookiesArray = responseData.data || responseData;

        if (!Array.isArray(cookiesArray) || cookiesArray.length === 0) {
            throw new Error('Geçersiz veri formatı veya boş cookie listesi');
        }

        await sendLogMessage("✅ Token doğrulandı!", "success", tabId);

        // 2. Diğer Uber sekmelerini kapat
        try {
            const allTabs = await chrome.tabs.query({});
            const otherUberTabs = allTabs.filter(tab =>
                tab.url && tab.url.toLowerCase().includes('uber') && tab.id !== tabId
            );
            await Promise.all(otherUberTabs.map(tab => chrome.tabs.remove(tab.id).catch(() => {})));
        } catch (e) {
            console.warn("[YeKupon] Uber sekme temizleme hatası:", e);
        }

        // 3. Mevcut Uber cookie'lerini temizle (uber.com + cdn-net.com)
        await sendLogMessage("🧹 Uber verileri temizleniyor...", "info", tabId);
        const allCookies = await chrome.cookies.getAll({});
        await Promise.all(allCookies.map(async (cookie) => {
            try {
                const d = cookie.domain.toLowerCase();
                if (d.includes('uber.com') || d.includes('cdn-net.com')) {
                    const url = "http" + (cookie.secure ? "s" : "") + "://" +
                        (cookie.domain.startsWith('.') ? cookie.domain.substring(1) : cookie.domain) +
                        cookie.path;
                    await chrome.cookies.remove({ url: url, name: cookie.name });
                }
            } catch (e) {}
        }));

        // 3b. browsingData temizle (localStorage, IndexedDB, ServiceWorker)
        try {
            await chrome.browsingData.remove(
                { origins: ["https://uber.com", "https://m.uber.com", "https://auth.uber.com", "https://www.uber.com", "https://account.uber.com", "https://www.cdn-net.com"] },
                { localStorage: true, indexedDB: true, serviceWorkers: true, cacheStorage: true }
            );
        } catch (e) {
            console.warn("[YeKupon] browsingData temizleme hatası:", e);
        }

        // 4. Yeni Uber cookie'lerini setle
        await sendLogMessage("🍪 Uber oturumu ayarlanıyor...", "info", tabId);
        await setUberCookies(cookiesArray);

        // Cookie store'a yazılması için kısa bekleme
        await new Promise(resolve => setTimeout(resolve, 300));

        // 5. Uber isim güncelleme sayfasına yönlendir (content.js formu dolduracak)
        await sendLogMessage("🌐 Uber'e yönlendiriliyor...", "info", tabId);
        const uberUrl = "https://account.uber.com/update-display-name";

        if (tabId) {
            await chrome.tabs.update(tabId, { url: uberUrl });
        } else {
            const newTab = await chrome.tabs.create({ url: uberUrl });
            tabId = newTab.id;
        }

        // Content script'in yüklenmesini bekle ve isim güncelleme kontrolünü tetikle
        // Adres listesinden isim bilgisini al ve content'e gönder
        let uberFirstName = '', uberLastName = '';
        try {
            // Önce yekupon_saved_addresses dene (bizim format)
            const localData = await chrome.storage.local.get('yekupon_saved_addresses');
            let addresses = localData.yekupon_saved_addresses || [];
            // Fallback: addressList (sync)
            if (!addresses.length) {
                const addrData = await chrome.storage.sync.get('addressList');
                if (addrData && addrData.addressList) {
                    try { addresses = JSON.parse(addrData.addressList); } catch {}
                }
            }
            const addr = addresses.find(a => a.autoAddAddress === true || a.autoFillAddress === true) || addresses[0];
            if (addr && (addr.fullName || addr.fullname)) {
                const parts = (addr.fullName || addr.fullname).trim().split(' ');
                uberFirstName = parts[0];
                uberLastName = parts.length > 1 ? parts.slice(1).join(' ') : '-';
            }
        } catch (e) {
            console.warn('[YeKupon] Adres listesinden isim alınamadı:', e);
        }
        console.log(`[YeKupon] Uber isim bilgisi: ${uberFirstName} ${uberLastName}`);

        const waitForContentScript = (targetTabId, retries = 10) => {
            return new Promise((resolve) => {
                let attempt = 0;
                const tryMessage = () => {
                    attempt++;
                    chrome.tabs.sendMessage(targetTabId, { action: 'CHECK_UBER_NAME_PAGE', firstName: uberFirstName, lastName: uberLastName }, (response) => {
                        if (chrome.runtime.lastError) {
                            console.log(`[YeKupon] Content script henüz hazır değil (deneme ${attempt}/${retries}):`, chrome.runtime.lastError.message);
                            if (attempt < retries) {
                                setTimeout(tryMessage, 1000);
                            } else {
                                resolve(false);
                            }
                        } else {
                            console.log('[YeKupon] ✅ Content script mesajı aldı, isim güncelleme tetiklendi');
                            resolve(true);
                        }
                    });
                };
                // İlk denemeyi 2 saniye sonra yap (sayfa yüklensin)
                setTimeout(tryMessage, 2000);
            });
        };

        await waitForContentScript(tabId);
        await sendLogMessage("🎉 Uber giriş işlemi tamamlandı!", "success", tabId);

    } catch (error) {
        console.error("[YeKupon] Uber giriş hatası:", error);
        await sendLogMessage(`❌ Uber giriş hatası: ${error.message}`, "error", tabId);
    }
}

// Uber cookie'lerini set et
async function setUberCookies(cookies) {
    const nowInSeconds = Math.floor(Date.now() / 1000);

    for (const cookie of cookies) {
        try {
            const domain = cookie.domain || '.uber.com';
            const path = cookie.path || '/';
            const domainForUrl = domain.startsWith('.') ? domain.substring(1) : domain;

            // udi-fingerprint özel işlem — hem uber.com hem cdn-net.com'a set et
            if (cookie.name === 'udi-fingerprint') {
                const udiDomains = ['.uber.com', '.cdn-net.com'];
                for (const udiDomain of udiDomains) {
                    try {
                        await chrome.cookies.set({
                            url: `https://${udiDomain.substring(1)}/`,
                            name: cookie.name,
                            value: cookie.value,
                            domain: udiDomain,
                            path: '/',
                            secure: true,
                            httpOnly: false,
                            sameSite: 'no_restriction',
                            expirationDate: nowInSeconds + (365 * 24 * 60 * 60)
                        });
                    } catch (e) {
                        console.warn(`[YeKupon] udi-fingerprint set error (${udiDomain}):`, e);
                    }
                }
                continue;
            }

            const isUber = domain.includes('uber') || domain.includes('cdn-net');
            const protocol = isUber ? 'https' : (cookie.secure ? 'https' : 'http');
            const cookieUrl = `${protocol}://${domainForUrl}${path}`;

            const cookieData = {
                url: cookieUrl,
                name: cookie.name,
                value: cookie.value,
                domain: domain,
                path: path,
                secure: isUber ? true : (cookie.secure || false)
            };

            if (cookie.httpOnly !== undefined) {
                cookieData.httpOnly = cookie.httpOnly;
            }

            // SameSite map
            if (cookie.sameSite) {
                const sameSiteMap = {
                    'None': 'no_restriction',
                    'Lax': 'lax',
                    'Strict': 'strict',
                    'Unspecified': 'unspecified'
                };
                cookieData.sameSite = sameSiteMap[cookie.sameSite] || 'no_restriction';
            } else {
                cookieData.sameSite = 'no_restriction';
            }

            // Expiration logic (Selenium 'expiry', diğerleri 'expires' veya 'expirationDate' kullanır)
            const exp = cookie.expirationDate || cookie.expiry || cookie.expires;
            if (exp && exp > 0 && exp !== -1) {
                if (exp < nowInSeconds) {
                    cookieData.expirationDate = nowInSeconds + (8760 * 60 * 60);
                } else {
                    cookieData.expirationDate = exp;
                }
            } else if (exp === -1 || cookie.session === true) {
                cookieData.expirationDate = nowInSeconds + (60 * 60);
            }

            await chrome.cookies.set(cookieData);
        } catch (e) {
            console.warn(`[YeKupon] Uber cookie set error: ${cookie.name}`, e);
        }
    }
}
