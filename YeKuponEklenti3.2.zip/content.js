function injectScript(file) {
  return new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.setAttribute('type', 'text/javascript');
    script.setAttribute('src', chrome.runtime.getURL(file));
    script.onload = () => { script.remove(); resolve(); };
    script.onerror = (e) => { reject(new Error('Script yüklenemedi: ' + file)); };
    (document.head || document.documentElement).appendChild(script);
  });
}

function injectStyles() {
  const currentDomain = window.location.hostname;
  if (currentDomain === 'migros.com.tr' || currentDomain === 'www.migros.com.tr') {
    return;
  }
  
  const styleContent = `
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');

    #ys-process-overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(17, 17, 17, 0.9);
      backdrop-filter: blur(10px);
      -webkit-backdrop-filter: blur(10px);
      z-index: 2147483647;
      display: flex;
      justify-content: center;
      align-items: center;
      opacity: 0;
      transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
      pointer-events: none;
      padding: 16px;
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
    }

    #ys-process-overlay.active {
      opacity: 1;
      pointer-events: all;
    }

    .ys-process-container {
      background: linear-gradient(145deg, #1a1a1a, #2a2a2a);
      border-radius: 24px;
      padding: 24px;
      width: 100%;
      max-width: 460px;
      box-shadow: 0 24px 48px rgba(0, 0, 0, 0.4);
      transform: translateY(20px) scale(0.98);
      transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
      border: 1px solid rgba(255, 255, 255, 0.1);
      position: relative;
      overflow: hidden;
      margin: 0 auto;
    }

    #ys-process-overlay.active .ys-process-container {
      transform: translateY(0) scale(1);
    }

    .ys-process-header {
      margin-bottom: 20px;
      padding-right: 40px;
    }

    .ys-header-content {
      display: flex;
      align-items: center;
      gap: 12px;
      color: #ffffff;
      font-size: 20px;
      font-weight: 600;
      letter-spacing: -0.5px;
    }

    .ys-status-dot {
      width: 10px;
      height: 10px;
      background: #22c55e;
      border-radius: 50%;
      animation: pulse 2s infinite;
      box-shadow: 0 0 12px rgba(34, 197, 94, 0.5);
      flex-shrink: 0;
    }

    .ys-close-button {
      background: rgba(255, 255, 255, 0.1);
      border: none;
      color: rgba(255, 255, 255, 0.8);
      font-size: 20px;
      cursor: pointer;
      padding: 8px;
      border-radius: 12px;
      transition: all 0.2s ease;
      line-height: 1;
      position: absolute;
      right: 16px;
      top: 16px;
      display: flex;
      align-items: center;
      justify-content: center;
      width: 32px;
      height: 32px;
      backdrop-filter: blur(4px);
      -webkit-backdrop-filter: blur(4px);
      z-index: 1;
    }

    .ys-close-button:hover {
      color: #fff;
      background: rgba(255, 255, 255, 0.2);
      transform: scale(1.05);
    }

    #ys-process-logs {
      max-height: min(70vh, 400px);
      overflow-y: auto;
      padding: 16px;
      background: rgba(0, 0, 0, 0.2);
      border-radius: 16px;
      font-family: 'SF Mono', 'Roboto Mono', monospace;
      scrollbar-width: thin;
      scrollbar-color: rgba(255, 255, 255, 0.2) transparent;
      border: 1px solid rgba(255, 255, 255, 0.05);
    }

    #ys-process-logs::-webkit-scrollbar {
      width: 6px;
    }

    #ys-process-logs::-webkit-scrollbar-track {
      background: transparent;
      margin: 4px;
    }

    #ys-process-logs::-webkit-scrollbar-thumb {
      background-color: rgba(255, 255, 255, 0.2);
      border-radius: 4px;
    }

    .ys-log-entry {
      padding: 12px 16px;
      margin: 8px 0;
      border-radius: 12px;
      font-size: 13px;
      line-height: 1.5;
      letter-spacing: 0.2px;
      border: 1px solid rgba(255, 255, 255, 0.08);
      animation: slideIn 0.3s ease forwards;
      opacity: 0;
      transform: translateX(-10px);
      display: flex;
      align-items: center;
      gap: 10px;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    }

    .ys-log-entry::before {
      content: '';
      display: inline-block;
      width: 8px;
      height: 8px;
      border-radius: 50%;
      flex-shrink: 0;
      box-shadow: 0 0 8px currentColor;
    }

    .ys-log-entry.info {
      background: rgba(59, 130, 246, 0.15);
      color: #93c5fd;
      border-color: rgba(59, 130, 246, 0.3);
    }

    .ys-log-entry.info::before {
      background: #93c5fd;
    }

    .ys-log-entry.success {
      background: rgba(34, 197, 94, 0.15);
      color: #86efac;
      border-color: rgba(34, 197, 94, 0.3);
    }

    .ys-log-entry.success::before {
      background: #86efac;
    }

    .ys-log-entry.error {
      background: rgba(239, 68, 68, 0.15);
      color: #fca5a5;
      border-color: rgba(239, 68, 68, 0.3);
    }

    .ys-log-entry.error::before {
      background: #fca5a5;
    }

    .ys-log-entry.warning {
      background: rgba(245, 158, 11, 0.15);
      color: #fcd34d;
      border-color: rgba(245, 158, 11, 0.3);
    }

    .ys-log-entry.warning::before {
      background: #fcd34d;
    }

    @keyframes slideIn {
      from {
        opacity: 0;
        transform: translateX(-10px);
      }
      to {
        opacity: 1;
        transform: translateX(0);
      }
    }

    @keyframes pulse {
      0% {
        transform: scale(0.95);
        box-shadow: 0 0 0 0 rgba(34, 197, 94, 0.7);
      }
      
      70% {
        transform: scale(1);
        box-shadow: 0 0 0 10px rgba(34, 197, 94, 0);
      }
      
      100% {
        transform: scale(0.95);
        box-shadow: 0 0 0 0 rgba(34, 197, 94, 0);
      }
    }

    @media (max-width: 480px) {
      #ys-process-overlay {
        padding: 12px;
      }

      .ys-process-container {
        border-radius: 20px;
        padding: 20px;
      }

      .ys-header-content {
        font-size: 18px;
      }

      #ys-process-logs {
        padding: 14px;
        max-height: 60vh;
      }

      .ys-log-entry {
        padding: 10px 14px;
        font-size: 12px;
      }

      .ys-close-button {
        right: 12px;
        top: 12px;
        width: 28px;
        height: 28px;
        font-size: 18px;
      }
    }
  `;

  const style = document.createElement('style');
  style.textContent = styleContent;
  
  if (document.head) {
    document.head.appendChild(style);
  } else {
    document.addEventListener('DOMContentLoaded', () => {
      document.head.appendChild(style);
    });
  }
}

// Known YemekSepeti domains for postMessage origin validation
const TRUSTED_YS_ORIGINS = [
  'https://www.yemeksepeti.com',
  'https://yemeksepeti.com',
  'https://www.tgoyemek.com',
  'https://tgoyemek.com',
  'https://www.yekupon.com',
  'https://yekupon.com',
  'https://www.migros.com.tr',
  'https://migros.com.tr',
  'http://localhost',
  'https://localhost'
];

function isTrustedOrigin(origin) {
  // Allow same-origin (for injected scripts)
  if (origin === window.location.origin) return true;
  // Allow localhost (any port)
  try {
    const url = new URL(origin);
    if (url.hostname === 'localhost' || url.hostname === '127.0.0.1') return true;
  } catch(e) {}
  return TRUSTED_YS_ORIGINS.some(trusted => origin === trusted);
}

window.addEventListener('message', async function(event) {
  // Validate origin
  if (!isTrustedOrigin(event.origin)) {
    return;
  }

  if (event.data.type === 'startTokenProcess') {
    const updateCheck = await checkForExtensionUpdates();
    
    if (updateCheck.needsUpdate) {
      showUpdatePopupOverlay(updateCheck.updateData);
      if (!updateCheck.updateData.is_mandatory) {
        const laterButton = document.querySelector('#update-later-button');
        if (laterButton) {
          laterButton.addEventListener('click', () => {
            proceedWithYsProcessOverlay(event.data.token);
          });
        }
      }
    } else {
      proceedWithYsProcessOverlay(event.data.token);
    }
  }
});

function proceedWithYsProcessOverlay(token) {
  const overlay = document.createElement('div');
  overlay.id = 'ys-process-overlay';
  overlay.innerHTML = `
    <div class="ys-process-container">
      <button class="ys-close-button">&times;</button>
      <div class="ys-process-header">
        <div class="ys-header-content">
          <div class="ys-status-dot"></div>
          <span>İşlem Durumu</span>
        </div>
      </div>
      <div id="ys-process-logs"></div>
    </div>
  `;
  document.body.appendChild(overlay);
  
  requestAnimationFrame(() => {
    overlay.classList.add('active');
  });
  
  const closeButton = overlay.querySelector('.ys-close-button');
  closeButton.addEventListener('click', () => {
    overlay.classList.remove('active');
    setTimeout(() => {
      overlay.remove();
    }, 300);
  });

  chrome.runtime.sendMessage({
    action: 'startExternalTokenProcess',
    token: token
  });
}

// === Consolidated onMessage listener ===
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'updateLog') {
    // Overlay log güncelleme (ys-process-overlay veya token-processing-overlay)
    const logsContainer = document.getElementById('ys-process-logs');
    if (logsContainer) {
      const logEntry = document.createElement('div');
      logEntry.className = `ys-log-entry ${message.type}`;
      logEntry.textContent = message.message;
      logsContainer.appendChild(logEntry);
      logsContainer.scrollTop = logsContainer.scrollHeight;
    }
    updateLogInOverlay(message.message, message.type);
  } else if (message.action === 'closeOverlay') {
    const overlay = document.getElementById('ys-process-overlay');
    if (overlay) {
      overlay.classList.remove('active');
      setTimeout(() => { overlay.remove(); }, 300);
    }
    closeTokenProcessingOverlay();
  } else if (message.action === 'showBottomWarning') {
    showBottomWarningInContent(message.message);
  } else if (message.action === 'updateYemekSepetiLocalStorage') {
    try {
      localStorage.setItem('location-model-1', JSON.stringify(message.locationData1));
      localStorage.setItem('location-model-v2', JSON.stringify(message.locationData2));
      console.log('[Content] localStorage güncellendi:', {
        'location-model-1': message.locationData1,
        'location-model-v2': message.locationData2
      });
      sendResponse({ success: true });
    } catch (error) {
      console.error('❌ YemekSepeti localStorage güncelleme hatası:', error);
      sendResponse({ success: false, error: error.message });
    }
    return true;
  } else if (message.action === 'CHECK_UBER_NAME_PAGE' || message.action === 'PERFORM_CHECKS') {
    console.log('[YeKupon][content.js] Mesaj alındı:', message);
    checkUberUpdateNamePage(message.firstName, message.lastName);
    sendResponse({ success: true });
  }
});

function isMigrosDomain() {
  const host = window.location.hostname;
  return host === 'migros.com.tr' || host === 'www.migros.com.tr' || host.endsWith('.migros.com.tr');
}

function isGeneralDomain() {
  const allowedDomains = [
    'yemeksepeti.com', 'www.yemeksepeti.com',
    'tgoyemek.com','www.tgoyemek.com',
    'yekupon.com', 'www.yekupon.com'
  ];
  const host = window.location.hostname;
  return allowedDomains.some(domain => host === domain || host.endsWith('.' + domain));
}

async function injectAllScripts() {
  // Migros domain'inde HİÇBİR ŞEY inject etme - sadece cookie ile çalışıyoruz
  if (isMigrosDomain()) {
    return;
  }

  if (isGeneralDomain()) {
    injectStyles();
    const scriptsToInject = [
      'src/core/endpoints.js',
      'src/core/helpers.js',
      'inject.js'
    ];

    try {
      for (const scriptFile of scriptsToInject) {
        await injectScript(scriptFile);
      }
    } catch (error) {
      console.error('Script enjeksiyonu sırasında hata oluştu:', error);
    }
  }
}

injectAllScripts();

// Migros proxy mesajları KALDIRILDI - artık sadece remember-me cookie kullanıyoruz

window.addEventListener('message', function(event) {
  // Validate origin
  if (!isTrustedOrigin(event.origin)) {
    return;
  }

  if (event.data && event.data.type === 'payment_success') {
    setTimeout(() => {
      window.location.href = '/hesabim/siparislerim';
    }, 3000);
  } else if (event.data && event.data.type === 'payment_error') {
  }

  if (event.data && event.data.type === 'GET_SAVED_ADDRESSES_REQUEST_FROM_PAGE') {
    if (chrome.runtime && chrome.runtime.sendMessage) {
        chrome.runtime.sendMessage({ action: 'GET_ADDRESS_LIST_FROM_CONTENT' }, (response) => {
            if (chrome.runtime.lastError) {
                console.error('Content.js: Background.js\'den adres alınırken hata:', chrome.runtime.lastError.message);
                window.postMessage({ type: 'SAVED_ADDRESSES_RESPONSE_FROM_EXTENSION', payload: [], error: chrome.runtime.lastError.message }, '*');
                return;
            }
            window.postMessage({ type: 'SAVED_ADDRESSES_RESPONSE_FROM_EXTENSION', payload: response && response.success ? response.addresses : [], error: response && !response.success ? response.error : null }, '*');
        });
    } else {
         window.postMessage({ type: 'SAVED_ADDRESSES_RESPONSE_FROM_EXTENSION', payload: [], error: "chrome.runtime.sendMessage not available" }, '*');
    }
    return;
  }

  // Voucher map relay: inject.js -> content.js -> background.js
  if (event.data && event.data.type === 'updateVoucherMap') {
    if (chrome.runtime && chrome.runtime.sendMessage) {
      chrome.runtime.sendMessage({
        action: 'updateVoucherMap',
        voucherMap: event.data.voucherMap || {}
      });
    }
    return;
  }

  // Checkout state relay: inject.js -> content.js -> background.js
  if (event.data && event.data.type === 'updateCheckoutState') {
    if (chrome.runtime && chrome.runtime.sendMessage) {
      chrome.runtime.sendMessage({
        action: 'updateCheckoutState',
        inProgress: !!event.data.inProgress
      });
    }
    return;
  }

  // Voucher map relay (source/action format): inject.js -> content.js -> background.js
  if (event.data && event.data.source === 'YEMEKSEPETI_EXTENSION' && event.data.action === 'updateVoucherMap') {
    if (chrome.runtime && chrome.runtime.sendMessage) {
      chrome.runtime.sendMessage({
        action: 'updateVoucherMap',
        data: event.data.voucherMap || {}
      });
    }
    return;
  }

  // YemekSepeti proxy - Migros proxy KALDIRILDI
  if (event.data && event.data.source === 'YEMEKSEPETI_EXTENSION' && event.data.action === 'ysProxyRequest') {
    const { requestId, url, method, headers, body, action } = event.data;

    if (!url) {
      console.error(`Content: URL eksik! Eylem: ${action}, RequestID: ${requestId}`);
      return;
    }


    chrome.runtime.sendMessage({
      action: action,
      url: url,
      method: method,
      headers: headers,
      body: body
    }, (response) => {
      if (chrome.runtime.lastError) {
  console.error(`Content: Mesaj gönderilirken hata oluştu (${action}).`, chrome.runtime.lastError.message);
        response = { success: false, error: chrome.runtime.lastError.message, headers: {} };
      }
      
      if (!response) {
  console.error(`Content: Background'den boş yanıt alındı! Eylem: ${action}, RequestID: ${requestId}`);
  response = { success: false, error: 'Background scriptinden yanıt alınamadı.', headers: {} };
      }

      
      window.postMessage({
        source: 'YEMEKSEPETI_EXTENSION_CONTENT',
        action: 'proxyResponse',
        requestId: requestId,
        response: response
      }, '*');
    });
  }
});

async function checkForExtensionUpdates() {
  
  return {
    needsUpdate: false,
    updateData: null
  };
}

function showUpdatePopupOverlay(updateData) {

  const overlay = document.createElement('div');
  overlay.id = 'update-overlay';
  overlay.style.cssText = `
    position: fixed; inset: 0; z-index: 9999999;
    display: flex; justify-content: center; align-items: center;
    background: rgba(0,0,0,.7); backdrop-filter: blur(4px);
    font-family: Inter, system-ui, -apple-system, sans-serif; color: #f1f5f9;
  `;

  overlay.innerHTML = `
    <style>
      @keyframes ykc-fadeUp{from{opacity:0;transform:translateY(14px) scale(.97)}to{opacity:1;transform:translateY(0) scale(1)}}
      @keyframes ykc-glow{0%,100%{opacity:.6}50%{opacity:1}}
      #ykc-card{max-width:440px;width:90%;padding:32px 28px;background:linear-gradient(165deg,rgba(26,31,46,.96),rgba(15,20,35,.98));border:1px solid rgba(148,163,184,.1);border-radius:22px;box-shadow:0 30px 60px rgba(0,0,0,.5),0 0 0 1px rgba(255,255,255,.03);position:relative;overflow:hidden;animation:ykc-fadeUp .35s cubic-bezier(.16,1,.3,1)}
      #ykc-card::before{content:'';position:absolute;top:0;left:0;right:0;height:2px;background:linear-gradient(90deg,transparent,#ff4757,#ff6b81,transparent);animation:ykc-glow 3s ease-in-out infinite}
      .ykc-badge{display:inline-flex;align-items:center;gap:6px;padding:5px 12px;border-radius:8px;background:rgba(255,71,87,.1);border:1px solid rgba(255,71,87,.15);color:#ff6b81;font-size:11px;font-weight:700;letter-spacing:.05em;text-transform:uppercase;margin-bottom:14px}
      .ykc-badge::before{content:'';width:6px;height:6px;border-radius:50%;background:#ff4757;animation:ykc-glow 2s ease infinite}
      .ykc-title{font-size:20px;font-weight:800;letter-spacing:-.02em;margin:0 0 6px;background:linear-gradient(135deg,#fff,#ff4757);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}
      .ykc-ver{font-size:14px;color:#94a3b8;margin:0 0 20px;font-weight:500}
      .ykc-desc{font-size:13.5px;color:#94a3b8;line-height:1.6;margin:0 0 22px;padding:14px 16px;background:rgba(255,255,255,.02);border:1px solid rgba(148,163,184,.08);border-radius:12px}
      .ykc-btns{display:flex;gap:10px;flex-wrap:wrap}
      .ykc-dl{display:inline-flex;align-items:center;gap:8px;padding:12px 22px;border-radius:12px;background:#ff4757;color:#fff;text-decoration:none;font-weight:700;font-size:14px;box-shadow:0 4px 18px rgba(255,71,87,.3),inset 0 1px 0 rgba(255,255,255,.15);transition:all .2s ease;border:none;cursor:pointer}
      .ykc-dl:hover{background:#ff6b81;transform:translateY(-1px);box-shadow:0 6px 24px rgba(255,71,87,.4)}
      .ykc-later{display:inline-flex;align-items:center;gap:8px;padding:12px 20px;border-radius:12px;background:rgba(255,255,255,.04);color:#cbd5e1;border:1px solid rgba(148,163,184,.12);font-weight:600;font-size:14px;cursor:pointer;transition:all .2s ease}
      .ykc-later:hover{background:rgba(255,255,255,.08);border-color:rgba(148,163,184,.2)}
    </style>
    <div id="ykc-card">
      <div class="ykc-badge">Güncelleme Mevcut</div>
      <h2 class="ykc-title">Yeni Sürüm Hazır</h2>
      <p class="ykc-ver">Versiyon: ${updateData.version}</p>
      <div class="ykc-desc">${updateData.description || ''}</div>
      <div class="ykc-btns">
        ${updateData.update_url ? `
          <a href="${updateData.update_url}" class="ykc-dl">
            <span style="font-size:18px;">⬇</span> Güncelle
          </a>
        ` : ''}
        ${!updateData.is_mandatory ? `
          <button id="update-later-button" class="ykc-later">
            <span style="font-size:16px;">⏭</span> Sonra
          </button>
        ` : ''}
      </div>
    </div>
  `;

  document.body.appendChild(overlay);

  if (!updateData.is_mandatory) {
    const laterButton = overlay.querySelector('#update-later-button');
    laterButton.addEventListener('click', () => {
      overlay.remove();
      proceedWithTokenProcessing();
    });
  }
}

function proceedWithTokenProcessing() {
  const urlParams = new URLSearchParams(window.location.search);
  const token = urlParams.get('token');
  
  if (token && token.length > 5) {
    chrome.runtime.sendMessage({
      action: 'startExternalTokenProcess',
      token: token
    });
    
    showTokenProcessingOverlay();
  }
}

async function checkForTokenInUrl() {
  const url = window.location.href;
  const urlParams = new URLSearchParams(window.location.search);
  const token = urlParams.get('token');
  

  const allowedDomains = ['yekupon.com', 'localhost'];
  const currentDomain = window.location.hostname;
  const isDomainAllowed = allowedDomains.some(domain => currentDomain.endsWith(domain));
  
  if (token && token.length > 5 && isDomainAllowed) {
    const updateCheck = await checkForExtensionUpdates();
    
    if (updateCheck.needsUpdate) {

      showUpdatePopupOverlay(updateCheck.updateData);

    } else {

      proceedWithTokenProcessing();
    }
  }
}


function showTokenProcessingOverlay() {

  if (document.getElementById('token-processing-overlay')) {
    return;
  }

  const overlay = document.createElement('div');
  overlay.id = 'token-processing-overlay';
  overlay.style.cssText = `
    position: fixed; inset: 0; z-index: 9999999;
    display: flex; justify-content: center; align-items: center;
    background: rgba(0,0,0,.7); backdrop-filter: blur(4px);
    font-family: Inter, system-ui, -apple-system, sans-serif; color: #f1f5f9;
  `;

  overlay.innerHTML = `
    <style>
      @keyframes ykt-fadeUp{from{opacity:0;transform:translateY(12px) scale(.97)}to{opacity:1;transform:translateY(0) scale(1)}}
      @keyframes ykt-spin{to{transform:rotate(360deg)}}
      @keyframes ykt-glow{0%,100%{opacity:.5}50%{opacity:1}}
      #ykt-card{max-width:440px;width:90%;padding:32px 28px;background:linear-gradient(165deg,rgba(26,31,46,.96),rgba(15,20,35,.98));border:1px solid rgba(148,163,184,.1);border-radius:22px;box-shadow:0 30px 60px rgba(0,0,0,.5);position:relative;overflow:hidden;animation:ykt-fadeUp .35s cubic-bezier(.16,1,.3,1);text-align:center}
      #ykt-card::before{content:'';position:absolute;top:0;left:0;right:0;height:2px;background:linear-gradient(90deg,transparent,#ff4757,#ff6b81,transparent);animation:ykt-glow 3s ease-in-out infinite}
      .ykt-title{font-size:18px;font-weight:700;margin:0 0 20px;color:#f1f5f9}
      .ykt-spinner{width:40px;height:40px;border:3px solid rgba(255,71,87,.15);border-top-color:#ff4757;border-radius:50%;animation:ykt-spin .8s linear infinite;margin:0 auto 20px}
      #log-container{max-height:180px;overflow-y:auto;text-align:left;background:rgba(0,0,0,.25);padding:12px 14px;border-radius:12px;border:1px solid rgba(148,163,184,.08);font-family:'Consolas',monospace;font-size:12px;line-height:1.6}
      #log-container p{margin:4px 0;color:#94a3b8}
      #log-container p:first-child{color:#3b82f6}
    </style>
    <div id="ykt-card">
      <h2 class="ykt-title">Token İşleniyor</h2>
      <div class="ykt-spinner"></div>
      <div id="log-container">
        <p>İşlem başlatılıyor...</p>
      </div>
    </div>
  `;

  document.body.appendChild(overlay);
}


// (onMessage listener consolidated above)

// Alt kısımda şeffaf uyarı gösterme fonksiyonu (content.js için)
function showBottomWarningInContent(message) {
  // Mevcut uyarıyı kaldır
  const existingWarning = document.querySelector('.yekupon-bottom-warning');
  if (existingWarning) {
    existingWarning.remove();
  }
  
  // Style ekle
  if (!document.getElementById('yekupon-bottom-warning-styles')) {
    const style = document.createElement('style');
    style.id = 'yekupon-bottom-warning-styles';
    style.textContent = `
      .yekupon-bottom-warning {
        position: fixed;
        bottom: 24px;
        left: 50%;
        transform: translateX(-50%) translateY(100px);
        z-index: 2147483647;
        padding: 14px 20px;
        background: linear-gradient(135deg, rgba(26, 31, 46, .95), rgba(15, 20, 35, .97));
        backdrop-filter: blur(12px);
        -webkit-backdrop-filter: blur(12px);
        color: #e2e8f0;
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
        font-size: 14px;
        font-weight: 500;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 16px;
        max-width: 600px;
        width: calc(100% - 48px);
        border-radius: 14px;
        border: 1px solid rgba(255, 71, 87, .15);
        transition: transform 0.4s cubic-bezier(.16, 1, .3, 1), opacity 0.3s ease;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4), 0 0 0 1px rgba(255, 255, 255, .03);
        opacity: 0;
      }
      .yekupon-bottom-warning::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 2px;
        background: linear-gradient(90deg, transparent, #ff4757, #ff6b81, transparent);
        border-radius: 14px 14px 0 0;
      }
      .yekupon-bottom-warning.show {
        transform: translateX(-50%) translateY(0);
        opacity: 1;
      }
      .yekupon-bottom-warning-content {
        display: flex;
        align-items: center;
        gap: 12px;
        flex: 1;
      }
      .yekupon-bottom-warning-icon {
        font-size: 22px;
        color: #ff4757;
      }
      .yekupon-bottom-warning-message {
        flex: 1;
        line-height: 1.4;
        color: #94a3b8;
      }
      .yekupon-bottom-warning-close {
        background: rgba(255, 255, 255, .05);
        border: 1px solid rgba(148, 163, 184, .1);
        color: #64748b;
        width: 32px;
        height: 32px;
        border-radius: 10px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.2s ease;
        flex-shrink: 0;
        font-size: 20px;
        font-weight: bold;
      }
      .yekupon-bottom-warning-close:hover {
        background: rgba(255, 71, 87, .1);
        color: #ff4757;
        border-color: rgba(255, 71, 87, .2);
      }
    `;
    document.head.appendChild(style);
  }
  
  // Yeni uyarı oluştur
  const warning = document.createElement('div');
  warning.className = 'yekupon-bottom-warning';
  warning.innerHTML = `
    <div class="yekupon-bottom-warning-content">
      <span class="yekupon-bottom-warning-icon">⚠️</span>
      <span class="yekupon-bottom-warning-message">${message}</span>
    </div>
    <button class="yekupon-bottom-warning-close" title="Kapat">×</button>
  `;
  
  document.body.appendChild(warning);
  
  // Animasyonla göster
  requestAnimationFrame(() => {
    warning.classList.add('show');
  });
  
  // Kapatma butonu
  const closeBtn = warning.querySelector('.yekupon-bottom-warning-close');
  closeBtn.addEventListener('click', () => {
    warning.classList.remove('show');
    setTimeout(() => {
      if (document.body.contains(warning)) {
        warning.remove();
      }
    }, 400);
  });
  
  // 10 saniye sonra otomatik kapat
  setTimeout(() => {
    if (document.body.contains(warning)) {
      warning.classList.remove('show');
      setTimeout(() => {
        if (document.body.contains(warning)) {
          warning.remove();
        }
      }, 400);
    }
  }, 10000);
  
}


function updateLogInOverlay(message, type = 'info') {
  const logContainer = document.getElementById('log-container');
  if (!logContainer) return;

  const logEntry = document.createElement('p');
  logEntry.style.margin = '5px 0';
  

  switch(type) {
    case 'success':
      logEntry.style.color = '#2ecc71';
      break;
    case 'error':
      logEntry.style.color = '#e74c3c';
      break;
    case 'warning':
      logEntry.style.color = '#f39c12';
      break;
    default:
      logEntry.style.color = '#3498db';
  }
  
  logEntry.textContent = message;
  logContainer.appendChild(logEntry);
  

  logContainer.scrollTop = logContainer.scrollHeight;
}


function closeTokenProcessingOverlay() {
  const overlay = document.getElementById('token-processing-overlay');
  if (overlay) {

    setTimeout(() => {
      overlay.style.opacity = '0';
      overlay.style.transition = 'opacity 0.5s ease';
      
      setTimeout(() => {
        overlay.remove();
      }, 500);
    }, 1000);
  }
}


function showMigrosLoginWarning() {

  if (document.getElementById('migros-login-warning-overlay')) {
    return;
  }

  const overlay = document.createElement('div');
  overlay.id = 'migros-login-warning-overlay';
  

  const warningStyles = `
    #migros-login-warning-overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(17, 17, 17, 0.95);
      backdrop-filter: blur(15px);
      -webkit-backdrop-filter: blur(15px);
      z-index: 2147483647;
      display: flex;
      justify-content: center;
      align-items: center;
      opacity: 0;
      transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
      pointer-events: all;
      padding: 16px;
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
      animation: fadeIn 0.5s ease forwards;
    }

    .migros-warning-container {
      background: linear-gradient(145deg, #dc2626, #b91c1c);
      border-radius: 24px;
      padding: 32px;
      width: 100%;
      max-width: 600px;
      box-shadow: 0 24px 48px rgba(220, 38, 38, 0.4);
      transform: translateY(20px) scale(0.98);
      transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
      border: 2px solid rgba(255, 255, 255, 0.2);
      position: relative;
      overflow: hidden;
      margin: 0 auto;
      text-align: center;
      animation: slideUp 0.6s ease forwards;
    }

    .migros-warning-icon {
      width: 80px;
      height: 80px;
      background: rgba(255, 255, 255, 0.2);
      border-radius: 50%;
      margin: 0 auto 24px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 40px;
      animation: pulse 2s infinite;
    }

    .migros-warning-title {
      color: #ffffff;
      font-size: 28px;
      font-weight: 700;
      margin-bottom: 20px;
      letter-spacing: -0.5px;
      text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
    }

    .migros-warning-message {
      color: #fee2e2;
      font-size: 18px;
      line-height: 1.6;
      margin-bottom: 24px;
      font-weight: 500;
      text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
    }

         .migros-warning-note {
       background: rgba(255, 255, 255, 0.1);
       border-radius: 16px;
       padding: 20px;
       margin-top: 20px;
       border: 1px solid rgba(255, 255, 255, 0.2);
       backdrop-filter: blur(4px);
       -webkit-backdrop-filter: blur(4px);
       display: flex;
       align-items: center;
       justify-content: center;
     }

    .migros-warning-note-text {
      color: #fecaca;
      font-size: 16px;
      font-weight: 600;
      margin: 0;
    }

    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }

    @keyframes slideUp {
      from {
        transform: translateY(40px) scale(0.95);
        opacity: 0;
      }
      to {
        transform: translateY(0) scale(1);
        opacity: 1;
      }
    }

    @keyframes pulse {
      0% {
        transform: scale(0.95);
        box-shadow: 0 0 0 0 rgba(255, 255, 255, 0.7);
      }
      70% {
        transform: scale(1);
        box-shadow: 0 0 0 10px rgba(255, 255, 255, 0);
      }
      100% {
        transform: scale(0.95);
        box-shadow: 0 0 0 0 rgba(255, 255, 255, 0);
      }
    }

    /* Mobil uyumluluk */
    @media (max-width: 768px) {
      #migros-login-warning-overlay {
        padding: 12px;
      }

      .migros-warning-container {
        border-radius: 20px;
        padding: 24px;
        max-width: 95%;
      }

      .migros-warning-icon {
        width: 60px;
        height: 60px;
        font-size: 30px;
        margin-bottom: 20px;
      }

      .migros-warning-title {
        font-size: 22px;
        margin-bottom: 16px;
      }

      .migros-warning-message {
        font-size: 16px;
        margin-bottom: 20px;
      }

      .migros-warning-note {
        padding: 16px;
        margin-top: 16px;
      }

      .migros-warning-note-text {
        font-size: 14px;
      }
    }

    @media (max-width: 480px) {
      .migros-warning-container {
        padding: 20px;
      }

      .migros-warning-title {
        font-size: 20px;
      }

      .migros-warning-message {
        font-size: 15px;
      }

      .migros-warning-note-text {
        font-size: 13px;
      }
    }
  `;


  const style = document.createElement('style');
  style.textContent = warningStyles;
  document.head.appendChild(style);

  overlay.innerHTML = `
    <div class="migros-warning-container">
  <div class="migros-warning-icon">⚠️</div>
  <h2 class="migros-warning-title">ÖNEMLİ UYARI</h2>
      <p class="migros-warning-message">
  Kendi hesabınıza girmek istiyorsanız eklentinin yüklü olmadığı bir tarayıcıdan giriniz veya gizli sekmeden eklenti aktif değilken giriniz, eklentinin yüklü olduğu tarayıcıdan girerseniz hesabınız kapanabilir.
      </p>
      <div class="migros-warning-note">
        <p class="migros-warning-note-text">
          Bu uyarı güvenliğiniz için gösterilmektedir
        </p>
      </div>
    </div>
  `;

  document.body.appendChild(overlay);
}


function checkMigrosLoginPage() {
  const currentUrl = window.location.href;
  const currentDomain = window.location.hostname;
  

  if ((currentDomain === 'www.migros.com.tr' || currentDomain === 'migros.com.tr') && 
      currentUrl.includes('/giris')) {
    showMigrosLoginWarning();
  }
}




(function setupStateChangeMonitoring() {
  let debounceTimer;
  let lastUrl = window.location.href;

  console.log('[YeKupon][content.js] setupStateChangeMonitoring başlatıldı, URL:', window.location.href);

  function performChecks() {
    console.log('[YeKupon][content.js] performChecks çalışıyor, URL:', window.location.href);
    checkForTokenInUrl();
    checkMigrosLoginPage();
    checkUberUpdateNamePage();
    checkUberFingerprintSpoofer();
  }


  function handleStateChange() {

    if (window.location.href !== lastUrl) {
      console.log('[YeKupon][content.js] URL değişti:', lastUrl, '->', window.location.href);
      lastUrl = window.location.href;
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(performChecks, 100);
    } else {

      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(performChecks, 300);
    }
  }


  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      console.log('[YeKupon][content.js] DOMContentLoaded fired, URL:', window.location.href);
      performChecks();
    });
  } else {
    performChecks();
  }

  // Also run checks when document becomes interactive/complete (covers document_start timing)
  document.addEventListener('readystatechange', () => {
    console.log('[YeKupon][content.js] readystatechange:', document.readyState, 'URL:', window.location.href);
    if (document.readyState === 'interactive' || document.readyState === 'complete') {
      performChecks();
    }
  });

  window.addEventListener('popstate', handleStateChange);


  const originalPushState = history.pushState;
  history.pushState = function() {
    originalPushState.apply(history, arguments);
    handleStateChange();
  };

  const originalReplaceState = history.replaceState;
  history.replaceState = function() {
    originalReplaceState.apply(history, arguments);
    handleStateChange();
  };


  if (typeof MutationObserver !== 'undefined') {
    const observer = new MutationObserver((mutations) => {

      const hasMeaningfulChanges = mutations.some(m => m.type === 'childList' && m.addedNodes.length > 0);
      if (hasMeaningfulChanges) {
        handleStateChange();
      }
    });


    const startObserving = () => {
      if (document.body) {
        observer.observe(document.body, { childList: true, subtree: true });
      } else {

        document.addEventListener('DOMContentLoaded', () => {
           observer.observe(document.body, { childList: true, subtree: true });
        }, { once: true });
      }
    };
    startObserving();
  }

})();


(function() {

    if (location.hostname.includes('migros.com.tr')) {
        const api = typeof chrome !== 'undefined' ? chrome : (typeof browser !== 'undefined' ? browser : null);
        if (!api || !api.runtime || !api.runtime.getURL) return;

        const script = document.createElement('script');
        script.setAttribute('type', 'text/javascript');
        script.setAttribute('src', api.runtime.getURL('migros-coupon-inject.js'));
        script.onload = () => {
            script.remove();
        };
        script.onerror = (e) => {
            console.error('YeKupon: Migros kupon sistemi yüklenemedi:', e);
        };
        (document.head || document.documentElement).appendChild(script);
    }
})();
(function() {
  'use strict';
  

  if (!window.location.hostname.includes('yemeksepeti.com')) {
    return;
  }
  
  injectScript('inject.js');
  

})();


// (updateYemekSepetiLocalStorage handler consolidated into main onMessage listener above)

// ===== MIGROS KUPON PROXY BRIDGE =====
// migros-coupon.js ile background.js arasında köprü görevi görür

if (isMigrosDomain()) {
  
  const MIGROS_PAGE_SOURCE = 'YK_MIGROS_COUPON_PAGE';
  const MIGROS_CONTENT_SOURCE = 'YK_MIGROS_COUPON_CONTENT';

  window.addEventListener('message', (event) => {
    if (event.source !== window || !event.data || event.data.source !== MIGROS_PAGE_SOURCE) {
      return;
    }

    if (event.data.action !== 'proxyRequest') {
      return;
    }

    const { requestId, url, method, headers, body } = event.data;

    chrome.runtime.sendMessage({
      action: 'fetchMigrosAPI',
      url,
      method,
      headers,
      body
    }, (response) => {
      let payload = response;

      if (chrome.runtime.lastError || !payload) {
        payload = {
          success: false,
          error: chrome.runtime.lastError ? chrome.runtime.lastError.message : 'Background yanıtı alınamadı',
          headers: {}
        };
      }

      window.postMessage({
        source: MIGROS_CONTENT_SOURCE,
        action: 'proxyResponse',
        requestId,
        response: payload
      }, '*');
    });
  });
}

// ===== TGOYEMEK/TRENDYOL PROXY BRIDGE =====
// inject.js ile background.js arasında köprü görevi görür

function isTgoYemekDomain() {
  const hostname = window.location.hostname;
  return hostname === 'tgoyemek.com' || hostname.endsWith('.tgoyemek.com');
}

if (isTgoYemekDomain()) {
  
  // inject.js'i yükle
  function injectTyScript(file) {
    const script = document.createElement('script');
    script.src = chrome.runtime.getURL(file);
    script.onload = function() {
      this.remove();
    };
    (document.head || document.documentElement).appendChild(script);
  }
  
  injectTyScript('inject.js');

  // Page -> Content -> Background mesaj köprüsü
  window.addEventListener('message', (event) => {
    if (event.source !== window || !event.data) return;
    
    // inject.js'ten gelen proxy istekleri
    if (event.data.source === 'YEKUPON_TY_PROXY_REQUEST') {
      const { action, url, method, body, requestId } = event.data;
      
      
      chrome.runtime.sendMessage({
        action: action,
        url: url,
        method: method,
        body: body,
        requestId: requestId
      }, (response) => {
        let payload = response;
        
        if (chrome.runtime.lastError || !payload) {
          payload = {
            success: false,
            error: chrome.runtime.lastError ? chrome.runtime.lastError.message : 'Background yanıtı alınamadı',
            headers: {}
          };
        }
        
        // Yanıtı inject.js'e geri gönder
        window.postMessage({
          source: 'YEKUPON_TY_PROXY_RESPONSE',
          requestId: requestId,
          response: payload
        }, '*');
      });
    }
  });
}

// ===== UBER İSİM GÜNCELLEME =====
// account.uber.com/update-display-name sayfasındaysa otomatik isim doldur

// (CHECK_UBER_NAME_PAGE handler consolidated into main onMessage listener above)

async function checkUberUpdateNamePage(msgFirstName, msgLastName) {
  const currentUrl = window.location.href;
  console.log('[YeKupon][content.js] checkUberUpdateNamePage çağrıldı, URL:', currentUrl);
  if (!currentUrl.includes('account.uber.com/update-display-name')) {
    console.log('[YeKupon][content.js] URL eşleşmedi, atlanıyor.');
    return;
  }

  console.log('[YeKupon][content.js] ✅ Uber isim güncelleme sayfası algılandı!');

  let firstName = msgFirstName || '';
  let lastName = msgLastName || '';

  // Mesajdan isim gelmediyse adres listesinden almayı dene
  if (!firstName) {
    try {
      const response = await new Promise((resolve) => {
        chrome.runtime.sendMessage({ action: 'GET_ADDRESS_LIST_FROM_CONTENT' }, resolve);
      });
      if (response && response.success && response.addresses && response.addresses.length > 0) {
        const address = response.addresses.find(addr => addr.autoAddAddress === true || addr.autoFillAddress === true) || response.addresses[0];
        const name = address.fullName || address.fullname || '';
        if (name) {
          const parts = name.trim().split(' ');
          firstName = parts[0];
          lastName = parts.length > 1 ? parts.slice(1).join(' ') : '-';
        }
      }
    } catch (e) {
      console.error('[YeKupon][content.js] Adres listesi alınamadı:', e);
    }
  }

  if (!firstName) {
    console.error('[YeKupon][content.js] İsim bilgisi bulunamadı, isim güncelleme atlanıyor. Direkt m.uber.com\'a gidiliyor.');
    setTimeout(() => { window.location.href = "https://m.uber.com"; }, 2000);
    return;
  }

  console.log(`[YeKupon][content.js] İsim: ${firstName} ${lastName}`);

  // Elementlerin yüklenmesini bekle
  const waitForElement = (selector, timeout = 10000) => {
    return new Promise((resolve, reject) => {
      const startTime = Date.now();
      const check = () => {
        const el = document.querySelector(selector);
        if (el) resolve(el);
        else if (Date.now() - startTime > timeout) reject(new Error('Timeout: ' + selector));
        else setTimeout(check, 500);
      };
      check();
    });
  };

  try {
    console.log('[YeKupon][content.js] Form elemanları bekleniyor...');
    const firstNameInput = await waitForElement('#update\\.display\\.name\\.firstname');
    const lastNameInput = await waitForElement('#update\\.display\\.name\\.lastname');
    console.log('[YeKupon][content.js] Form elemanları bulundu!');

    // Güncelle butonunu bul
    let updateButton = document.querySelector('button[type="submit"]');
    if (!updateButton) {
      const btns = document.querySelectorAll('button');
      for (const b of btns) {
        const t = (b.textContent || '').toLowerCase();
        if (t.includes('güncelle') || t.includes('update') || t.includes('kaydet') || t.includes('save')) {
          updateButton = b;
          break;
        }
      }
    }

    // React uyumlu değer setleme
    const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
    nativeInputValueSetter.call(firstNameInput, firstName);
    firstNameInput.dispatchEvent(new Event('input', { bubbles: true }));
    firstNameInput.dispatchEvent(new Event('change', { bubbles: true }));

    nativeInputValueSetter.call(lastNameInput, lastName);
    lastNameInput.dispatchEvent(new Event('input', { bubbles: true }));
    lastNameInput.dispatchEvent(new Event('change', { bubbles: true }));

    console.log(`[YeKupon][content.js] ✅ Uber isimleri dolduruldu: ${firstName} ${lastName}`);

    // Kısa bekleme ve tıkla
    setTimeout(() => {
      if (updateButton) {
        console.log('[YeKupon][content.js] Güncelle butonuna tıklanıyor...');
        updateButton.click();
      }
      setTimeout(() => {
        window.location.href = "https://m.uber.com";
      }, 2000);
    }, 1000);

  } catch (err) {
    console.error('[YeKupon][content.js] Uber form elemanları bulunamadı:', err);
    // Form bulunamazsa yine de m.uber.com'a git
    setTimeout(() => { window.location.href = "https://m.uber.com"; }, 2000);
  }
}

// ===== UBER FINGERPRINT SPOOFER =====
// udi-fingerprint cookie'sini her saniye rastgele değerle setler (ban koruması)

let uberFingerprintInterval = null;

function checkUberFingerprintSpoofer() {
  const isUber = window.location.href.includes('uber');
  if (isUber && !uberFingerprintInterval) {
    const generateRandomBase64 = (byteLength) => {
      const bytes = new Uint8Array(byteLength);
      crypto.getRandomValues(bytes);
      return btoa(String.fromCharCode(...bytes));
    };
    const setUdiFingerprintCookie = () => {
      const value = generateRandomBase64(64) + generateRandomBase64(32);
      chrome.runtime.sendMessage({ action: 'setUdiFingerprintCookie', value });
    };
    setUdiFingerprintCookie();
    uberFingerprintInterval = setInterval(setUdiFingerprintCookie, 1000);
  } else if (!isUber && uberFingerprintInterval) {
    clearInterval(uberFingerprintInterval);
    uberFingerprintInterval = null;
  }
}

// Uber sayfasındaysa fingerprint spoofer'ı başlat
if (window.location.href.includes('uber')) {
  checkUberFingerprintSpoofer();
}
