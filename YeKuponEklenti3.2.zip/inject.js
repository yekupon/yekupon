// YemekSepeti API isteklerini yakalayıp background.js üzerinden Android proxy olarak yönlendirir.
// Vouchers, cart/calculate, cart/checkout, purchase/intent endpoint'leri proxy'lenir.
// Checkout body'sinde platform ve source Android'e çevrilir.

(function () {
  const TARGET_PATH_FRAGMENT = 'incentives-wallet/vouchers';
  const CHECKOUT_PATH_FRAGMENT = '/api/v5/cart/checkout';

  // === KUPON KORUMA SİSTEMİ ===
  let lastCalculateResponse = null;
  let lastProductsFingerprint = null;
  let checkoutInProgress = false;
  window.__ysVoucherMap = window.__ysVoucherMap || {};
  window.__ysLastCalculateResponse = null;
  window.__ysCheckoutInProgress = false;

  // Sepet ürünlerinin parmak izi - değişiklik tespiti için
  function calcProductsFingerprint(products) {
    if (!products || !Array.isArray(products)) return '';
    return products.map(p => {
      const toppings = (p.toppings || []).map(t => t.id + ':' + t.quantity).sort().join(',');
      return p.id + '_' + (p.variation_id || '') + '_' + p.quantity + '_' + toppings;
    }).sort().join('|');
  }

  // Kuponlu calculate isteği için sahte response üretimi
  function generateFakeCalculateResponse(cachedResponse, voucherCode) {
    if (!cachedResponse || !voucherCode) return null;
    try {
      const cached = typeof cachedResponse === 'string' ? JSON.parse(cachedResponse) : JSON.parse(JSON.stringify(cachedResponse));
      const vInfo = window.__ysVoucherMap ? window.__ysVoucherMap[voucherCode.toLowerCase()] : null;
      if (!vInfo || !vInfo.discount) return null;

      const discount = vInfo.discount;
      const currentTotal = cached.payment ? cached.payment.payable_total : 0;
      const appliedDiscount = Math.min(discount, currentTotal);

      if (cached.payment) {
        cached.payment.payable_total_without_voucher = cached.payment.payable_total;
        cached.payment.payable_total = parseFloat((cached.payment.payable_total - appliedDiscount).toFixed(2));
      }

      cached.voucher = {
        percentage: null,
        construct_id: vInfo.constructId || null,
        voucher_type: 'amount',
        type: 'amount',
        description: appliedDiscount + ' TL indirim kazandınız!',
        code: voucherCode,
        banned_products: [],
        amount: discount,
        value: discount,
        is_pro_voucher: false,
        applied: appliedDiscount > 0
      };

      return cached;
    } catch (e) {
      console.error('[KuponKoruma] Fake calculate error:', e);
      return null;
    }
  }

  // Sadece yemeksepeti.com'da çalış
  const isYemeksepeti = window.location.hostname.includes('yemeksepeti.com');

  // Proxy'lenecek YS endpoint'leri
  function isYsProxyEndpoint(url) {
    if (!url || typeof url !== 'string') return false;
    return (
      url.includes('tr.fd-api.com/api/v5/purchase/intent') ||
      url.includes('tr.fd-api.com/api/v5/cart/checkout') ||
      url.includes('tr.fd-api.com/api/v5/cart/calculate') ||
      url.includes('tr.fd-api.com/api/v6/incentives-wallet/vouchers')
    );
  }

  // GraphQL kupon operasyonu kontrolü (body'den)
  function isGraphqlIncentivesRequest(url, body) {
    if (!url || !url.includes('tr.fd-api.com/graphql')) return false;
    if (!body) return false;
    try {
      const str = typeof body === 'string' ? body : '';
      return str.includes('GetIncentivesCartWallet');
    } catch (_) { return false; }
  }

  // Proxy callback storage
  window.yekuponYs = window.yekuponYs || {};
  window.yekuponYs.xhrCallbacks = {};
  window.yekuponYs.fetchCallbacks = {};

  // Proxy yanıtları için message listener
  window.addEventListener('message', (event) => {
    if (event.data && event.data.source === 'YEMEKSEPETI_EXTENSION_CONTENT' && event.data.action === 'proxyResponse') {
      const { requestId, response } = event.data;

      if (window.yekuponYs.xhrCallbacks[requestId]) {
        window.yekuponYs.xhrCallbacks[requestId](response);
        delete window.yekuponYs.xhrCallbacks[requestId];
      }

      if (window.yekuponYs.fetchCallbacks[requestId]) {
        window.yekuponYs.fetchCallbacks[requestId](response);
        delete window.yekuponYs.fetchCallbacks[requestId];
      }
    }
  });

  // Cart body manipülasyonu (checkout + calculate)
  function manipulateCartBody(url, body) {
    if (!body) return body;
    if (!url.includes('cart/checkout') && !url.includes('cart/calculate')) return body;
    try {
      const requestBody = JSON.parse(body);
      if (requestBody.platform === 'b2c') {
        requestBody.platform = 'android_native_app';
      }
      requestBody.source = 'android';

      // Kupon otomatik ekleme YAPMA — background.js'de Kuppo modeli ile yönetiliyor
      // Kuponsuz sunucuya git → cache'le → kuponlu fake response üret

      return JSON.stringify(requestBody);
    } catch (e) {
      return body;
    }
  }

  function normalizePlatformParam(url) {
    if (!url || typeof url !== 'string') return url;
    if (!url.includes(TARGET_PATH_FRAGMENT)) return url;
    let newUrl = url;
    if (newUrl.includes('platform=web_frontend')) {
      newUrl = newUrl.replace('platform=web_frontend', 'platform=android_native_app');
    } else if (!/([?&])platform=/.test(newUrl)) {
      newUrl += (newUrl.includes('?') ? '&' : '?') + 'platform=android_native_app';
    }
    return newUrl;
  }

  // perseus id üretimi (client & session)
  function generatePerseusIds() {
    const ts = Date.now();
    const randDigits = (len) => {
      const min = Math.pow(10, len - 1);
      const max = Math.pow(10, len) - 1;
      return Math.floor(Math.random() * (max - min + 1)) + min;
    };
    const randAlphaNum = (len) => {
      const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
      let out = '';
      for (let i = 0; i < len; i++) out += chars.charAt(Math.floor(Math.random() * chars.length));
      return out;
    };
    const clientMiddle = randDigits(18);
    const clientId = `${ts}.${clientMiddle}.${randAlphaNum(10)}`;
    const sessionLen = Math.random() < 0.5 ? 16 : 18;
    const sessionMiddle = randDigits(sessionLen);
    const sessionId = `${ts + 1000}.${sessionMiddle}.${randAlphaNum(10)}`;
    return { clientId, sessionId };
  }

  function attachPerseusToXhr(xhr) {
    const ids = generatePerseusIds();
    xhr._yk_perseus_client_id = ids.clientId;
    xhr._yk_perseus_session_id = ids.sessionId;
  }

  // XHR intercept (URL değiştirme + checkout flag + proxy flag)
  const originalOpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    try {
      const urlStr = String(url);
      this._requestUrl = urlStr;
      this._requestMethod = method;
      url = normalizePlatformParam(urlStr);
      this._yk_checkout = urlStr.includes(CHECKOUT_PATH_FRAGMENT);
      if (this._yk_checkout) {
        attachPerseusToXhr(this);
      }
      // YS proxy flag
      if (isYemeksepeti && isYsProxyEndpoint(urlStr)) {
        this._isYsProxy = true;
      }
      // GraphQL: send'de body kontrol edilecek
      if (isYemeksepeti && urlStr.includes('tr.fd-api.com/graphql')) {
        this._isGraphqlCandidate = true;
      }
    } catch (_) { /* ignore */ }
    return originalOpen.call(this, method, url, ...rest);
  };

  // fetch intercept (URL değiştirme + checkout header + YS proxy)
  const originalFetch = window.fetch;
  window.fetch = function (resource, init) {
    try {
      const isString = typeof resource === 'string';
      const origUrl = isString ? resource : resource.url;

      // YS Proxy: İsteği background.js üzerinden gönder
      const bodyStr = init?.body;
      const isGraphqlIncentives = isGraphqlIncentivesRequest(origUrl, bodyStr);
      if (isYemeksepeti && (isYsProxyEndpoint(origUrl) || isGraphqlIncentives)) {
        if (isGraphqlIncentives) console.log('[YeKupon] GraphQL kupon proxy yakalandı');

        // === FETCH: FAKE CALCULATE ===
        if (origUrl.includes('cart/calculate') && bodyStr) {
          try {
            // Önce body manipülasyonu yap (kupon ekleme dahil)
            const manipulatedBody = manipulateCartBody(origUrl, bodyStr);
            const calcBody = typeof manipulatedBody === 'string' ? JSON.parse(manipulatedBody) : manipulatedBody;
            const voucherCode = (calcBody.voucher || '').trim();
            const hasVoucher = voucherCode !== '';

            if (hasVoucher && lastCalculateResponse) {
              const fakeResp = generateFakeCalculateResponse(lastCalculateResponse, voucherCode);
              if (fakeResp) {
                console.log('[KuponKoruma] Fetch fake calculate for voucher:', voucherCode);
                return Promise.resolve(new Response(JSON.stringify(fakeResp), {
                  status: 200, statusText: 'OK', headers: { 'content-type': 'application/json' }
                }));
              }
            }
          } catch(e) { console.error('[KuponKoruma] Fetch calculate parse error:', e); }
        }

        // === FETCH: CHECKOUT KORUMA ===
        if (origUrl.includes('/api/v5/cart/checkout')) {
          checkoutInProgress = true;
          window.__ysCheckoutInProgress = true;
        }
        if (checkoutInProgress && origUrl.includes('cart/calculate') && lastCalculateResponse) {
          const cachedData = typeof lastCalculateResponse === 'string' ? lastCalculateResponse : JSON.stringify(lastCalculateResponse);
          return Promise.resolve(new Response(cachedData, {
            status: 200, statusText: 'OK', headers: { 'content-type': 'application/json' }
          }));
        }

        return new Promise((resolve, reject) => {
          const finalBody = isGraphqlIncentives ? bodyStr : manipulateCartBody(origUrl, bodyStr);
          const requestId = Date.now() + Math.random().toString().substring(2, 8);

          // 15s fetch proxy timeout
          const fetchProxyTimeout = setTimeout(() => {
            if (window.yekuponYs.fetchCallbacks[requestId]) {
              console.warn('[KuponKoruma] Fetch proxy timeout (15s):', origUrl);
              window.yekuponYs.fetchCallbacks[requestId]({ success: false, error: 'Proxy timeout (15s)' });
            }
          }, 15000);

          window.yekuponYs.fetchCallbacks[requestId] = (response) => {
            clearTimeout(fetchProxyTimeout);
            if (response && response.success) {
              // Cache calculate response
              if (origUrl.includes('cart/calculate') && response.data) {
                lastCalculateResponse = response.data;
                window.__ysLastCalculateResponse = response.data;
              }
              // Reset checkout state
              if (origUrl.includes('/api/v5/cart/checkout')) {
                checkoutInProgress = false;
                window.__ysCheckoutInProgress = false;
              }
              // Extract voucher map from GraphQL
              if (isGraphqlIncentives && response.data) {
                try {
                  const respData = typeof response.data === 'string' ? JSON.parse(response.data) : response.data;
                  const incentives = respData?.data?.incentivesCartWallet?.incentives || [];
                  const voucherMap = {};
                  incentives.forEach(inc => {
                    const code = inc?.voucherMetaData?.code?.toLowerCase();
                    if (code) {
                      voucherMap[code] = {
                        discount: inc.value || inc.voucherMetaData.value || inc.voucherMetaData.amount || 0,
                        minOrder: inc.minimumOrderValue || inc.voucherMetaData.minimumOrderValue || 0,
                        constructId: inc.voucherMetaData.constructID || ''
                      };
                    }
                    // Status'u APPLICABLE'a zorla
                    if (inc?.voucherMetaData) {
                      if (inc.voucherMetaData.status && inc.voucherMetaData.status !== 'APPLICABLE') {
                        inc.voucherMetaData.status = 'APPLICABLE';
                      }
                      if (inc.voucherMetaData.quantity === 0) inc.voucherMetaData.quantity = 1;
                      if (inc.voucherMetaData.platforms) inc.voucherMetaData.platforms = null;
                    }
                  });
                  if (Object.keys(voucherMap).length > 0) {
                    window.__ysVoucherMap = voucherMap;
                    console.log('[KuponKoruma] Voucher map updated:', Object.keys(voucherMap));
                  }
                } catch(e) {}
              }
              resolve(new Response(response.data, {
                status: response.status,
                statusText: response.statusText || '',
                headers: response.headers || {}
              }));
            } else {
              reject(new Error(response?.error || 'YS Proxy failed'));
            }
          };

          // Sayfa header'larını al (Kuppo.net gibi)
          let pageHeaders = {};
          if (init?.headers) {
            if (init.headers instanceof Headers) {
              init.headers.forEach((v, k) => { pageHeaders[k] = v; });
            } else if (typeof init.headers === 'object') {
              pageHeaders = { ...init.headers };
            }
          }
          window.postMessage({
            source: 'YEMEKSEPETI_EXTENSION',
            action: 'ysProxyRequest',
            requestId: requestId,
            url: origUrl,
            method: init?.method || 'GET',
            headers: pageHeaders,
            body: finalBody
          }, '*');
        });
      }

      const newUrl = normalizePlatformParam(origUrl);
      const isCheckout = origUrl.includes(CHECKOUT_PATH_FRAGMENT);

      // Checkout için perseus header'ları ekle
      if (isCheckout) {
        const { clientId, sessionId } = generatePerseusIds();
        let headersObj = {};
        if (init && init.headers) {
          if (init.headers instanceof Headers) {
            init.headers.forEach((v, k) => { headersObj[k] = v; });
          } else if (Array.isArray(init.headers)) {
            init.headers.forEach(([k, v]) => { headersObj[k] = v; });
          } else {
            headersObj = { ...init.headers };
          }
        }
        headersObj['perseus-client-id'] = clientId;
        headersObj['perseus-session-id'] = sessionId;
        const newInit = { ...(init || {}), headers: headersObj };
        if (isString) {
          return originalFetch.call(this, newUrl, newInit);
        } else {
          const req = new Request(newUrl, resource);
          return originalFetch.call(this, req, newInit);
        }
      }

      // Sadece URL değişikliği (vouchers için)
      if (newUrl !== origUrl) {
        if (isString) {
          return originalFetch.call(this, newUrl, init);
        } else {
          const newRequest = new Request(newUrl, resource);
          return originalFetch.call(this, newRequest, init);
        }
      }
    } catch (e) { /* ignore */ }
    return originalFetch.call(this, resource, init);
  };

  // XHR send - YS proxy + checkout perseus header'ları
  const originalSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.send = function (body) {
    // GraphQL: body'den kupon operasyonu mu kontrol et
    if (this._isGraphqlCandidate && !this._isYsProxy) {
      if (isGraphqlIncentivesRequest(this._requestUrl, body)) {
        this._isYsProxy = true;
        this._isGraphqlIncentives = true;
        console.log('[YeKupon] GraphQL kupon XHR proxy yakalandı');
      }
    }
    // YS Proxy: İsteği abort edip background.js üzerinden gönder
    if (this._isYsProxy) {
      // === FAKE CALCULATE: Kuponlu istekleri API'ye göndermeden sahte yanıt döndür ===
      if (this._requestUrl && this._requestUrl.includes('cart/calculate') && body) {
        try {
          // Önce body manipülasyonu yap (kupon ekleme dahil)
          const manipulatedBody = manipulateCartBody(this._requestUrl, body);
          const calcBody = typeof manipulatedBody === 'string' ? JSON.parse(manipulatedBody) : manipulatedBody;
          const voucherCode = (calcBody.voucher || '').trim();
          const hasVoucher = voucherCode !== '';
          const currentFingerprint = calcProductsFingerprint(calcBody.products);

          if (hasVoucher && lastCalculateResponse) {
            const fakeResp = generateFakeCalculateResponse(lastCalculateResponse, voucherCode);
            if (fakeResp) {
              const fakeData = JSON.stringify(fakeResp);
              const xhr = this;
              Object.defineProperty(xhr, 'readyState', { value: 4, configurable: true });
              Object.defineProperty(xhr, 'status', { value: 200, configurable: true });
              Object.defineProperty(xhr, 'statusText', { value: 'OK', configurable: true });
              Object.defineProperty(xhr, 'responseText', { value: fakeData, configurable: true });
              Object.defineProperty(xhr, 'response', { value: fakeData, configurable: true });
              setTimeout(() => {
                if (typeof xhr.onreadystatechange === 'function') xhr.onreadystatechange();
                if (typeof xhr.onload === 'function') xhr.onload();
                xhr.dispatchEvent(new Event('readystatechange'));
                xhr.dispatchEvent(new Event('load'));
                xhr.dispatchEvent(new Event('loadend'));
              }, 50);
              console.log('[KuponKoruma] Fake calculate returned for voucher:', voucherCode);
              return;
            }
          }

          if (hasVoucher) {
            delete calcBody.voucher;
            delete calcBody.voucher_context;
            body = JSON.stringify(calcBody);
          }
          lastProductsFingerprint = currentFingerprint;
        } catch(e) { console.error('[KuponKoruma] Calculate parse error:', e); }
      }

      // === CHECKOUT KORUMA ===
      if (this._requestUrl && this._requestUrl.includes('/api/v5/cart/checkout')) {
        checkoutInProgress = true;
        window.__ysCheckoutInProgress = true;
      }

      // === Checkout sırasında calculate isteklerini cache'ten döndür ===
      if (checkoutInProgress && this._requestUrl && this._requestUrl.includes('cart/calculate') && lastCalculateResponse) {
        const xhr = this;
        const cachedData = typeof lastCalculateResponse === 'string' ? lastCalculateResponse : JSON.stringify(lastCalculateResponse);
        Object.defineProperty(xhr, 'readyState', { value: 4, configurable: true });
        Object.defineProperty(xhr, 'status', { value: 200, configurable: true });
        Object.defineProperty(xhr, 'statusText', { value: 'OK', configurable: true });
        Object.defineProperty(xhr, 'responseText', { value: cachedData, configurable: true });
        Object.defineProperty(xhr, 'response', { value: cachedData, configurable: true });
        setTimeout(() => {
          if (typeof xhr.onreadystatechange === 'function') xhr.onreadystatechange();
          if (typeof xhr.onload === 'function') xhr.onload();
          xhr.dispatchEvent(new Event('readystatechange'));
          xhr.dispatchEvent(new Event('load'));
          xhr.dispatchEvent(new Event('loadend'));
        }, 50);
        return;
      }
      const originalXhr = this;
      this.abort();

      const finalBody = manipulateCartBody(this._requestUrl, body);
      const requestId = Date.now() + Math.random().toString().substring(2, 8);

      // 15s proxy timeout
      const proxyTimeout = setTimeout(() => {
        if (window.yekuponYs.xhrCallbacks[requestId]) {
          console.warn('[KuponKoruma] XHR proxy timeout (15s):', originalXhr._requestUrl);
          window.yekuponYs.xhrCallbacks[requestId]({ success: false, error: 'Proxy timeout (15s)' });
        }
      }, 15000);

      window.yekuponYs.xhrCallbacks[requestId] = (response) => {
        clearTimeout(proxyTimeout);
        if (response && response.success) {
          const mockHeaders = response.headers || {};

          Object.defineProperty(originalXhr, 'readyState', { value: 4, configurable: true });
          Object.defineProperty(originalXhr, 'status', { value: response.status, configurable: true });
          Object.defineProperty(originalXhr, 'statusText', { value: response.statusText || '', configurable: true });
          Object.defineProperty(originalXhr, 'response', { value: response.data, configurable: true });
          Object.defineProperty(originalXhr, 'responseText', { value: response.data, configurable: true });

          // Kuppo.net modeli: header helper fonksiyonları
          originalXhr.getAllResponseHeaders = function() {
            if (!mockHeaders || typeof mockHeaders !== 'object') return '';
            return Object.entries(mockHeaders).map(([key, value]) => `${key}: ${value}`).join('\r\n');
          };
          originalXhr.getResponseHeader = function(name) {
            if (!mockHeaders || typeof mockHeaders !== 'object') return null;
            return mockHeaders[name.toLowerCase()] || null;
          };

          // Cache calculate response
          if (originalXhr._requestUrl && originalXhr._requestUrl.includes('cart/calculate') && response.data) {
            lastCalculateResponse = response.data;
            window.__ysLastCalculateResponse = response.data;
          }
          // Reset checkout state on checkout completion
          if (originalXhr._requestUrl && originalXhr._requestUrl.includes('/api/v5/cart/checkout')) {
            checkoutInProgress = false;
            window.__ysCheckoutInProgress = false;
          }

          try {
            if (typeof originalXhr.onreadystatechange === 'function') originalXhr.onreadystatechange();
            if (response.status >= 200 && response.status < 300) {
              if (typeof originalXhr.onload === 'function') originalXhr.onload();
              originalXhr.dispatchEvent(new Event('load'));
            } else {
              if (typeof originalXhr.onerror === 'function') originalXhr.onerror();
              originalXhr.dispatchEvent(new Event('error'));
            }
            if (typeof originalXhr.onloadend === 'function') originalXhr.onloadend();
            originalXhr.dispatchEvent(new Event('loadend'));
          } catch (e) {
            console.error('XHR mock event error:', e);
          }
        } else {
          Object.defineProperty(originalXhr, 'readyState', { value: 4, configurable: true });
          Object.defineProperty(originalXhr, 'status', { value: 0, configurable: true });
          Object.defineProperty(originalXhr, 'statusText', { value: 'Proxy Error', configurable: true });

          try {
            if (typeof originalXhr.onerror === 'function') originalXhr.onerror();
            if (typeof originalXhr.onloadend === 'function') originalXhr.onloadend();
            originalXhr.dispatchEvent(new Event('error'));
            originalXhr.dispatchEvent(new Event('loadend'));
          } catch (e) {
            console.error('XHR mock error event error:', e);
          }
        }
        delete window.yekuponYs.xhrCallbacks[requestId];
      };

      window.postMessage({
        source: 'YEMEKSEPETI_EXTENSION',
        action: 'ysProxyRequest',
        requestId: requestId,
        url: this._requestUrl,
        method: this._requestMethod || 'POST',
        headers: {},
        body: finalBody
      }, '*');

      return;
    }

    try {
      if (this._yk_checkout) {
        if (!this._yk_perseus_client_id || !this._yk_perseus_session_id) {
          attachPerseusToXhr(this);
        }
        this.setRequestHeader('perseus-client-id', this._yk_perseus_client_id);
        this.setRequestHeader('perseus-session-id', this._yk_perseus_session_id);
      }
    } catch (e) { /* ignore */ }
    return originalSend.call(this, body);
  };

})();

// =====================================================
// TRENDYOL/TGOYEMEK MOBİL API İNTERCEPT
// =====================================================
(function() {
  // Sadece tgoyemek.com'da çalış
  if (!window.location.hostname.includes('tgoyemek.com')) {
    return;
  }


  // Trendyol proxy endpoint kontrolü - RAKİP GİBİ TÜM İLGİLİ ENDPOINT'LER
  // /carts, /carts/coupons, /carts/code-promotions hepsini yakala
  function isTyProxyEndpoint(url) {
    if (!url || typeof url !== 'string' || !url.includes('api.tgoapis.com')) return false;
    
    // Tüm cart endpoint'lerini yakala (rakip gibi)
    return (
      url.includes('/meal-mmcheckout-sfxcarts-santral/carts/code-promotions') ||
      url.includes('/web-checkout-apicheckout-santral/carts/code-promotions') ||
      url.includes('/web-checkout-apicheckout-santral/carts/coupons') ||
      url.includes('/web-checkout-apicheckout-santral/carts')
    );
  }

  // Global callback storage
  window.yekuponTy = window.yekuponTy || {};
  window.yekuponTy.xhrCallbacks = {};
  window.yekuponTy.fetchCallbacks = {};

  // Proxy yanıtları için message listener
  window.addEventListener('message', (event) => {
    if (event.data && event.data.source === 'YEKUPON_TY_PROXY_RESPONSE') {
      const { requestId, response } = event.data;
      
      if (window.yekuponTy.xhrCallbacks[requestId]) {
        window.yekuponTy.xhrCallbacks[requestId](response);
        delete window.yekuponTy.xhrCallbacks[requestId];
      }
      
      if (window.yekuponTy.fetchCallbacks[requestId]) {
        window.yekuponTy.fetchCallbacks[requestId](response);
        delete window.yekuponTy.fetchCallbacks[requestId];
      }
    }
  });

  // XHR Intercept for Trendyol
  const tyOriginalXhrOpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function(method, url, ...args) {
    this._tyRequestUrl = url;
    this._tyRequestMethod = method;
    
    if (typeof url === 'string' && isTyProxyEndpoint(url)) {
      this._isTyProxyEndpoint = true;
    }
    
    return tyOriginalXhrOpen.apply(this, [method, url, ...args]);
  };

  const tyOriginalXhrSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.send = function(body) {
    if (this._isTyProxyEndpoint) {
      const originalXhr = this;
      
      this.abort();

      const requestId = Date.now() + Math.random().toString().substring(2, 8);
      
      window.yekuponTy.xhrCallbacks[requestId] = (response) => {
        if (response && response.success) {
          
          Object.defineProperty(originalXhr, 'readyState', { configurable: true, get: () => 4 });
          Object.defineProperty(originalXhr, 'status', { configurable: true, get: () => response.status });
          Object.defineProperty(originalXhr, 'statusText', { configurable: true, get: () => response.statusText || '' });
          Object.defineProperty(originalXhr, 'responseText', { configurable: true, get: () => response.data });
          Object.defineProperty(originalXhr, 'response', { configurable: true, get: () => response.data });
          
          setTimeout(() => {
            if (typeof originalXhr.onreadystatechange === 'function') originalXhr.onreadystatechange();
            if (typeof originalXhr.onload === 'function') originalXhr.onload();
            originalXhr.dispatchEvent(new Event('readystatechange'));
            originalXhr.dispatchEvent(new Event('load'));
            originalXhr.dispatchEvent(new Event('loadend'));
          }, 0);
        } else {
          console.error('[YKupon] TY Proxy hatası:', response?.error);
          Object.defineProperty(originalXhr, 'readyState', { configurable: true, get: () => 4 });
          Object.defineProperty(originalXhr, 'status', { configurable: true, get: () => 0 });
          
          setTimeout(() => {
            if (typeof originalXhr.onerror === 'function') originalXhr.onerror();
            originalXhr.dispatchEvent(new Event('error'));
          }, 50);
        }
      };

      window.postMessage({
        source: 'YEKUPON_TY_PROXY_REQUEST',
        action: 'tyProxyRequest',
        url: this._tyRequestUrl,
        method: this._tyRequestMethod || 'POST',
        body: body,
        requestId: requestId
      }, '*');
      
      return;
    }
    
    return tyOriginalXhrSend.call(this, body);
  };

  // Fetch Intercept for Trendyol
  const tyOriginalFetch = window.fetch;
  window.fetch = async function(resource, init) {
    let url;
    try {
      url = typeof resource === 'string' ? resource : (resource && resource.url ? resource.url : null);
    } catch (e) {
      url = null;
    }
    
    if (url && isTyProxyEndpoint(url)) {
      
      return new Promise((resolve, reject) => {
        const requestId = Date.now() + Math.random().toString().substring(2, 8);
        
        window.yekuponTy.fetchCallbacks[requestId] = (response) => {
          if (response && response.success) {
            
            const mockResponse = new Response(response.data, {
              status: response.status,
              statusText: response.statusText || '',
              headers: response.headers || {}
            });
            resolve(mockResponse);
          } else {
            reject(new Error(response?.error || 'TY Proxy failed'));
          }
        };

        window.postMessage({
          source: 'YEKUPON_TY_PROXY_REQUEST',
          action: 'tyProxyRequest',
          url: url,
          method: init?.method || 'GET',
          body: init?.body,
          requestId: requestId
        }, '*');
      });
    }
    
    return tyOriginalFetch.apply(this, arguments);
  };

})();
